export class EmpresaTrans {
  cempti: string;
  dnombre: string;
  cjurisdicc: number;
  tipoconv: string;
  ddireccion: string;
  tautoriz: string;
  ddistrito: string;
  ctelefono1: string;
  ctelefono2: string;
  cestado: string;
  cresautori: string;
  fcambio: number;
  cusuario: string;
  codcsur: string;
  codganc: string;
  codganp: string;
  fresoluc: number;
  fmod: number;
  finicio: number;
  ffin: number;
  cpais: string;
  ctipodoc: string;
  cnrodoc: string;
  codRegfiscal: string;
}