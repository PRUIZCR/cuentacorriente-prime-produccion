package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.util;

import java.io.ByteArrayOutputStream;
import java.util.EnumMap;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;



public class CodigoQR {
	/**
	 * Formato en el que se va generar la imagen del c&oacute;digo QR 
	 */
	public static final String FORMATO_IMAGEN = "PNG";
	
	private CodigoQR() {
		throw new IllegalAccessError("No se puede instanciar una clase utilitaria");
	}
	
   /** Genera un c&oacute;digo QR como una imagen expresada en un array de bytes. 
    * 
    * @param contenido Contenido a colocar en el c&oacute;digo QR
    * @param ancho Ancho de la imagen en pixeles
    * @param alto Alto de la imagen  en pixeles
    * @exception SalidaException Si ocurre un error al generar el c&oacute;digo QR
    * @author rcontreras
    * @return
    * Imagen PNG como un array de bytes que ser&iacute;a  la imagen del c&oacute;digo QR */
   public static byte[] generar(String contenido, int ancho, int alto) throws TransaccionDpmnException {
	   
	   byte[] codigoQR = null;
	   
	   try {
		   EnumMap<EncodeHintType, Object> hintMap = new EnumMap<>(EncodeHintType.class);
		   hintMap.put(EncodeHintType.MARGIN, 1);
		   QRCodeWriter qrCodeWriter = new QRCodeWriter();
		   BitMatrix bitMatrix = qrCodeWriter.encode(contenido, BarcodeFormat.QR_CODE, ancho, alto, hintMap);
		   ByteArrayOutputStream pngOutputStream = new ByteArrayOutputStream();
		   MatrixToImageWriter.writeToStream(bitMatrix, FORMATO_IMAGEN, pngOutputStream);
		   codigoQR = pngOutputStream.toByteArray(); 
	   } catch(java.lang.Exception ex ) {
		   throw new TransaccionDpmnException(ex);
	   }
      return codigoQR;
   }
}
