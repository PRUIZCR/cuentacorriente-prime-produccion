package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.main.config;

import javax.enterprise.inject.Produces;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;

public class EntityManagerInit {
	
	@PersistenceContext(unitName = "dsprad1")
	private EntityManager dsprad1;
	
	@PersistenceContext(unitName = "dcbdsigad")
	private EntityManager dcbdsigad;
	
	@PersistenceContext(unitName = "dgbdsigad")
	private EntityManager dgbdsigad;
	
	@Produces
	@Named("dsprad1")
	public EntityManager createEntityManagerDsprad1() {
		if (dsprad1 == null) {
			return getEntityManager("dsbddpr6");
		}
		return dsprad1;
	}
	
	@Produces
	@Named("dcbdsigad")
	public EntityManager createEntityManagerDcbdsigad() {
		return dcbdsigad;
	}
	
	@Produces
	@Named("dgbdsigad")
	public EntityManager createEntityManagerDgbdsigad() {
		return dgbdsigad;
	}
	private EntityManager getEntityManager(String unitName) {
		return Persistence.createEntityManagerFactory(unitName).createEntityManager();
	}
}
