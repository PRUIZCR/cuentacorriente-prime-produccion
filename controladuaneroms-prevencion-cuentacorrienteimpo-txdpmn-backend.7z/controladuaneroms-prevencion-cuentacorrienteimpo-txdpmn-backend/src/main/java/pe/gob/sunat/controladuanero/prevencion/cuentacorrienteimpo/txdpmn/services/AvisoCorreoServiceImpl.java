/***********************************************************************
 * Module:  AvisoCorreoServiceImpl.java
 * Author:  rcontreras
 * Purpose: Defines the Class AvisoCorreoServiceImpl
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.services;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import javax.inject.Inject;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.bean.ArchivoAdjunto;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.bean.AvisoCorreo;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.dao.ArchivoAdjuntoDAO;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.dao.AvisosDAO;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.dao.DatacatalogoDAO;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.util.TransaccionDpmnException;

public class AvisoCorreoServiceImpl implements AvisoCorreoService {

	
	@Inject private AvisosDAO avisosDAO;
	@Inject private ArchivoAdjuntoDAO archivoAdjuntoDAO;
	@Inject private DatacatalogoDAO datacatalogoDAO;
	
	private Log log = LogFactory.getLog(this.getClass());

	/**
	 * {@inheritDoc}
	 * @author msancheza
	 */
	@Override
	public void generarAviso(AvisoCorreo avisoCorreo) throws TransaccionDpmnException {
		
		try {
			
			this.log.info("==================================================================");
			this.log.info("Validando generaci\u00f3n aviso de correo gen\u00e9rico ...");
			
			if ( this.faltaCompletarInformacion(avisoCorreo) ) {
				return;
			}
			this.completarDefaultVigencia(avisoCorreo);
			this.completarDefaultRutaPlantilla(avisoCorreo);
			
			Long idAviso = this.grabarAviso(avisoCorreo);
			this.grabarAdjuntos(idAviso, avisoCorreo);
			
			this.log.info("Se ha generado el aviso con secuencia " + idAviso);
			
			this.log.info("==================================================================");
			
			return;
			
		} catch( java.lang.Exception ex ) {
			this.log.error("No se pudo generar el aviso de correo generico", ex);

		}
	}

	public AvisosDAO getAvisosDAO() {
		return avisosDAO;
	}

	public void setAvisosDAO(AvisosDAO avisosDAO) {
		this.avisosDAO = avisosDAO;
	}

	public ArchivoAdjuntoDAO getArchivoAdjuntoDAO() {
		return archivoAdjuntoDAO;
	}

	public void setArchivoAdjuntoDAO(ArchivoAdjuntoDAO archivoAdjuntoDAO) {
		this.archivoAdjuntoDAO = archivoAdjuntoDAO;
	}
	
	public DatacatalogoDAO getDatacatalogoDAO() {
		return datacatalogoDAO;
	}

	public void setDatacatalogoDAO(DatacatalogoDAO datacatalogoDAO) {
		this.datacatalogoDAO = datacatalogoDAO;
	}

	private Long grabarAviso(AvisoCorreo avisoCorreo) throws JsonProcessingException {
		Long numId = avisosDAO.getSecuencia().longValue();
		Date date = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        int dateYear = calendar.get(Calendar.YEAR);
        Long idAviso = new Long(String.valueOf(dateYear).concat(String.valueOf(numId)));
		
		StringBuilder dataAviso = this.buildDataDelAviso(avisoCorreo);
		String tipoAviso = "0";
		
		java.util.Calendar cal = java.util.Calendar.getInstance();
		cal.setTime(avisoCorreo.getFechaPublicacion());
		cal.add(java.util.Calendar.DAY_OF_YEAR, avisoCorreo.getNumDiasVigencia());
		
		Timestamp fechaPublicacion = new Timestamp(avisoCorreo.getFechaPublicacion().getTime());
		Timestamp fechaVigencia = new Timestamp(cal.getTime().getTime());
		Timestamp fechaCreacion = new Timestamp(cal.getTime().getTime());
		this.avisosDAO.insert(idAviso, avisoCorreo.getPlantilla().getNumeroServicio(), new StringBuffer(dataAviso),
				tipoAviso, fechaPublicacion, fechaVigencia, fechaCreacion, "1");
		
		return idAviso;
	}
	
	private void grabarAdjuntos(Long idAviso, AvisoCorreo avisoCorreo) {
		boolean noHayAdjuntos = avisoCorreo.getAdjuntos() == null || avisoCorreo.getAdjuntos().isEmpty();
		
		if (noHayAdjuntos) {
			return;
		}
		Integer secuencia = 0;
		for ( ArchivoAdjunto adjunto : avisoCorreo.getAdjuntos() ) {
			if ( this.datosCompletosEnAdjunto(adjunto) ) {
				secuencia = secuencia + 1; 
				this.grabarAdjunto(idAviso, secuencia, adjunto);
			}
		}
		
	}
	
	private void grabarAdjunto(Long idAviso, Integer secuencia,  ArchivoAdjunto adjunto) {
		Map<String, Object> mapArchivo = new HashMap<String, Object>();
		
		mapArchivo.put("numSecAviso", idAviso);
		mapArchivo.put("numSecAdj", secuencia);
		mapArchivo.put("nomAdjunto", adjunto.getNombre());
		mapArchivo.put("arcAdjunto", adjunto.getContenido());
		
		archivoAdjuntoDAO.insert(mapArchivo);
	}
	
	private boolean datosCompletosEnAdjunto(ArchivoAdjunto adjunto) {
		
		boolean noExisteAdjunto = adjunto == null; 
		
		if (noExisteAdjunto) {
			return false;
		}
		
		boolean faltaNombre = adjunto.getNombre() == null || adjunto.getNombre().trim().isEmpty();
		
		if (faltaNombre) {
			return false;
		}
		
		boolean faltaContenido = adjunto.getContenido() == null || adjunto.getContenido().length == 0;
		
		return !faltaContenido;
	}
	
	private StringBuilder buildDataDelAviso(AvisoCorreo avisoCorreo) throws JsonProcessingException {
		
		Map<String, String> dataMapAviso = new HashMap<String, String>();
		
		ObjectMapper mapper = new ObjectMapper(); 
		mapper.setSerializationInclusion(Include.NON_NULL);
		
		dataMapAviso.put("TIPO_DE_MENSAJE", "CORREO_GENERICO");
		
		StringBuilder dataAviso = new StringBuilder();
		
		AvisoCorreo objDataAviso = new AvisoCorreo();
		objDataAviso.setAsunto(avisoCorreo.getAsunto());
		objDataAviso.setConCopia(avisoCorreo.getConCopia());
		objDataAviso.setDestinatario(avisoCorreo.getDestinatario());
		objDataAviso.setPlantilla(avisoCorreo.getPlantilla());
		objDataAviso.setRemitente(avisoCorreo.getRemitente());
		this.setDataDeAdjuntos(objDataAviso, avisoCorreo);
		
		dataMapAviso.put("DATA_AVISO", mapper.writeValueAsString(objDataAviso));
		
		dataAviso.append(mapper.writeValueAsString(dataMapAviso));
		
		return dataAviso;
	}
	
	private void setDataDeAdjuntos(AvisoCorreo objDataAviso, AvisoCorreo avisoCorreo) {
		
		boolean noHayAdjuntos = avisoCorreo.getAdjuntos() == null || avisoCorreo.getAdjuntos().isEmpty();
		
		if ( noHayAdjuntos ) {
			return;
		}
		
		for ( ArchivoAdjunto adjunto : avisoCorreo.getAdjuntos()) {
			boolean tieneTipoContent = adjunto.getTipoContenido() != null && !adjunto.getTipoContenido().trim().isEmpty();
			
			if ( tieneTipoContent ) {
				ArchivoAdjunto newArchivoAdjunto = new ArchivoAdjunto();
				newArchivoAdjunto.setNombre(adjunto.getNombre());
				newArchivoAdjunto.setTipoContenido(adjunto.getTipoContenido());
				objDataAviso.addAdjuntos(newArchivoAdjunto);
			}
		}
	}
	
	private boolean faltaCompletarInformacion(AvisoCorreo avisoCorreo) {
		
		boolean faltaAviso = avisoCorreo == null; 
		
		if ( faltaAviso ) {
			this.log.info("Falta indicar el aviso");
			return true;
		}
		
		boolean faltaRemitente = avisoCorreo.getRemitente() == null || avisoCorreo.getRemitente().trim().isEmpty();
		
		if ( faltaRemitente ) {
			this.log.info("Falta indicar el remitente");
			return true;
		}
		
		boolean faltaDestinatario = avisoCorreo.getDestinatario() == null || avisoCorreo.getDestinatario().trim().isEmpty();
		
		if ( faltaDestinatario ) {
			this.log.info("Falta indicar el destinatario");
			return true;
		}
		
		boolean faltaAsunto = avisoCorreo.getAsunto() == null || avisoCorreo.getAsunto().trim().isEmpty();
		
		if ( faltaAsunto ) {
			this.log.info("Falta indicar el asunto");
			return true;
		}
		
		return this.faltaCompletarPlantilla(avisoCorreo);
	}
	
	private boolean faltaCompletarPlantilla(AvisoCorreo avisoCorreo) {

		boolean noHayInfoPlantilla = avisoCorreo.getPlantilla() == null;
		
		if ( noHayInfoPlantilla ) {
			this.log.info("Falta indicar el destinatario");
			return true;
		}
		
		boolean faltaNumServicio = avisoCorreo.getPlantilla().getNumeroServicio() == null
				|| avisoCorreo.getPlantilla().getNumeroServicio() <= 0;
		
		if ( faltaNumServicio ) {
			this.log.info("Falta indicar el servicio de la plantilla");
			return true;
		}
		
		return false;
	}
	
	private void completarDefaultVigencia(AvisoCorreo avisoCorreo) {
		
		if ( avisoCorreo.getFechaPublicacion() == null ) {
			avisoCorreo.setFechaPublicacion(new java.util.Date());
		}
		
		if ( avisoCorreo.getNumDiasVigencia() == null ) {
			avisoCorreo.setNumDiasVigencia(3);
		}
		
	}
	private void completarDefaultRutaPlantilla(AvisoCorreo avisoCorreo) {
		
		boolean tieneRutaPlantilla = avisoCorreo.getPlantilla() != null && avisoCorreo.getPlantilla().getArchivo() != null && 
										!avisoCorreo.getPlantilla().getArchivo().trim().isEmpty();
		
		if (tieneRutaPlantilla) {
			return;
		}
		
		
		  Integer numeroServicio = avisoCorreo.getPlantilla().getNumeroServicio();
		  
		  String resultadoPlantilla = datacatalogoDAO.obtenerDataCatalogoAsoc("001", String.valueOf(numeroServicio));
		 
		  boolean noExisteResultados = resultadoPlantilla == null ||
		  resultadoPlantilla.isEmpty();
		  
		  if ( noExisteResultados ) { return; }
			
		String ruta = "PLANTILLA".concat(resultadoPlantilla).concat(".html");
		avisoCorreo.getPlantilla().setArchivo(ruta);
	}

}