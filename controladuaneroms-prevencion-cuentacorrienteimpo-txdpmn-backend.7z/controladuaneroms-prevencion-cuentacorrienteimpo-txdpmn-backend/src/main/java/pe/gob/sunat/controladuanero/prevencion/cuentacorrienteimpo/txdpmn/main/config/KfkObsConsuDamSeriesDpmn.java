package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.main.config;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.kafka.consumer.KafkaConsumerDamSeriesDpmn;
import pe.gob.sunat.tecnologia3.arquitectura.framework.kafka.Consumer;

public class KfkObsConsuDamSeriesDpmn {
	
	public KfkObsConsuDamSeriesDpmn() {
		Consumer obsConsumerDamSeriesDpmn = new Consumer(TransaccionDpmnConfig.getConfig().getCfgKafkaConsumerDamSeriesDpmn());
        KafkaConsumerDamSeriesDpmn kafkaConsumerDamSeriesDpmn = new KafkaConsumerDamSeriesDpmn(obsConsumerDamSeriesDpmn);
        obsConsumerDamSeriesDpmn.addObserver(kafkaConsumerDamSeriesDpmn);
        obsConsumerDamSeriesDpmn.subscribe();
	}
}
