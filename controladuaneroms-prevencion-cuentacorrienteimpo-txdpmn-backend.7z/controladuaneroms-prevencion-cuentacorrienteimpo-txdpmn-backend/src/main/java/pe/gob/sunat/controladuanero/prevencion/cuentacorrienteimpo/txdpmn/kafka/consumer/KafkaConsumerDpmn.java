/***********************************************************************
 * Module:  KafkaConsumerDpmn.java
 * Author:  rcontreras
 * Purpose: Defines the Class KafkaConsumerDpmn
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.kafka.consumer;


import java.io.IOException;
import java.util.Observable;
import java.util.Observer;

import javax.enterprise.context.spi.CreationalContext;
import javax.enterprise.inject.spi.Bean;
import javax.enterprise.inject.spi.BeanManager;
import javax.enterprise.inject.spi.CDI;
import javax.persistence.PersistenceException;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.eclipse.persistence.exceptions.DatabaseException;

import com.fasterxml.jackson.databind.ObjectMapper;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.bean.KafkaMsgDpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.services.RegistroDpmnService;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.util.Constantes;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.util.ManageExceptionUtil;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.util.TxDpmObjMapper;
import pe.gob.sunat.tecnologia3.arquitectura.framework.kafka.Consumer;
import pe.gob.sunat.tecnologia3.arquitectura.framework.kafka.exception.ErrorException;
import pe.gob.sunat.tecnologiams.arquitectura.framework.microservices.util.ConstantesUtils;
import pe.gob.sunat.tecnologiams.arquitectura.framework.microservices.util.UtilLog;

public class KafkaConsumerDpmn implements Observer {

	private Consumer observable = null;
	
	private UtilLog utilLog;
	private RegistroDpmnService registroDpmnService;
	
	public KafkaConsumerDpmn(Consumer newObservable) {
	      this.observable = newObservable;
	      this.incializarBeans();
	}
	
	private void incializarBeans() {
		BeanManager bm = CDI.current().getBeanManager();
		
		Bean<?> bean = bm.getBeans(UtilLog.class).iterator().next();
		CreationalContext<?> ctx = bm.createCreationalContext(bean);
		this.utilLog = (UtilLog) bm.getReference(bean, UtilLog.class, ctx);
		
		Bean<?> beanService = bm.getBeans(RegistroDpmnService.class).iterator().next();
		CreationalContext<?> ctxService = bm.createCreationalContext(beanService);
		this.registroDpmnService = (RegistroDpmnService) bm.getReference(beanService, RegistroDpmnService.class, ctxService);
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public void update(Observable o, Object obj) {
		
		ConsumerRecord<String , Object> record = (ConsumerRecord <String , Object>) obj;
		
		try {
			
			KafkaMsgDpmn  kafkaMsg = this.getKafkaMsg(record);
			
			if ( kafkaMsg == null ) {
				return;
			}			
			
			Constantes.TipoOperacion tipoOperacion = Constantes.TipoOperacion.getInstancia(kafkaMsg.getTipoOperacion());
			
			if ( Constantes.TipoOperacion.REGISTRO.equals(tipoOperacion) ) {
				this.registroDpmnService.grabar(kafkaMsg.getData());
			}
			
			
		}  catch (DatabaseException de) {
			ManageExceptionUtil.manageDatabaseException(this.utilLog, de);
		} catch (PersistenceException qe) {
			ManageExceptionUtil.managePersistenceException(this.utilLog, qe);
		} catch (Exception e) {
			if (this.utilLog != null) {
				this.utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR,
						"Excepcion posible envio a topico para reproceso " + UtilLog.getStackTraceFromException(e));
			}
			throw new ErrorException(e);
		}   
        
	}
	
	private KafkaMsgDpmn getKafkaMsg(ConsumerRecord<String , Object> record) throws IOException {
		boolean noTieneData = record == null || record.value() == null;
		
		if ( noTieneData ) {
			return null;
		}
		
		ObjectMapper objectMapper = new TxDpmObjMapper();
		
		String dataJson = record.value().toString();
		
		return objectMapper.readValue(dataJson, KafkaMsgDpmn.class);
	}
	
	

}
