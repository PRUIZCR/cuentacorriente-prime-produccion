/***********************************************************************
 * Module:  TxDpmnKafkaProducerImpl.java
 * Author:  rcontreras
 * Purpose: Defines the Class TxDpmnKafkaProducerImpl
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.kafka.producer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.bean.KafkaMsgDpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.domain.Dpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.main.config.TransaccionDpmnConfig;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.util.Constantes;
import pe.gob.sunat.tecnologia3.arquitectura.framework.kafka.Producer;

public class KafkaProducerDpmnImpl implements KafkaProducerDpmn {
	
	private Producer producer;
	
	public KafkaProducerDpmnImpl() {
		this.producer = new Producer(TransaccionDpmnConfig.getConfig().getCfgKafkaProducerDpmn());
	}

	/**
	 * {@inheritDoc}
	 * @author rcontreras
	 * @throws JsonProcessingException 
	 */
	@Override
	public void enviarMsgGuardar(Dpmn dpmn) throws JsonProcessingException {
		KafkaMsgDpmn kafkaMsgDpmn = new KafkaMsgDpmn();
		kafkaMsgDpmn.setTipoOperacion(Constantes.TipoOperacion.REGISTRO.getCodigo());
		kafkaMsgDpmn.setData(dpmn);
		
		ObjectMapper objectMapper = new ObjectMapper();
		String dataJson = objectMapper.writeValueAsString(kafkaMsgDpmn);
		this.producer.send(dataJson);
	}

	/**
	 * {@inheritDoc}
	 * @author rcontreras
	 */	
	@Override
	public void enviarMsgActualizar(Dpmn dpmn) throws JsonProcessingException {
		KafkaMsgDpmn kafkaMsgDpmn = new KafkaMsgDpmn();
		kafkaMsgDpmn.setTipoOperacion(Constantes.TipoOperacion.MODIFICACION.getCodigo());
		kafkaMsgDpmn.setData(dpmn);
		
		ObjectMapper objectMapper = new ObjectMapper();
		String dataJson = objectMapper.writeValueAsString(kafkaMsgDpmn);
		this.producer.send(dataJson);
	}

	/**
	 * {@inheritDoc}
	 * @author rcontreras
	 */
	@Override
	public void enviarMsgEliminar(Long correlativoDpmn) throws JsonProcessingException {
		KafkaMsgDpmn kafkaMsgDpmn = new KafkaMsgDpmn();
		kafkaMsgDpmn.setTipoOperacion(Constantes.TipoOperacion.MODIFICACION.getCodigo());
		kafkaMsgDpmn.setCorrelativoDpmnEliminar(correlativoDpmn);
		ObjectMapper objectMapper = new ObjectMapper();
		String dataJson = objectMapper.writeValueAsString(kafkaMsgDpmn);
		this.producer.send(dataJson);
	}
	
}