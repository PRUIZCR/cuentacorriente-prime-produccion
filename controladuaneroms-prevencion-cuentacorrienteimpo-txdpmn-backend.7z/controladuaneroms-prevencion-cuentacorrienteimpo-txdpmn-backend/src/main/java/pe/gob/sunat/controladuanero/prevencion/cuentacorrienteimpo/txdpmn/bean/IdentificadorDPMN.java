/***********************************************************************
 * Module:  IdentificadorDPMN.java
 * Author:  rcontreras
 * Purpose: Defines the Class IdentificadorDPMN
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.bean;

public class IdentificadorDPMN implements java.io.Serializable {
   /**
	 * 
	 */
	private static final long serialVersionUID = 4809084484535546307L;
	private Long correlativo;
   private String codAduana;
   private Integer anio;
   private Integer numero;
   
   public Long getCorrelativo() {
      return correlativo;
   }
   
   /** @param newCorrelativo */
   public void setCorrelativo(Long newCorrelativo) {
      correlativo = newCorrelativo;
   }
   
   public String getCodAduana() {
      return codAduana;
   }
   
   /** @param newCodAduana */
   public void setCodAduana(String newCodAduana) {
      codAduana = newCodAduana;
   }
   
   public Integer getAnio() {
      return anio;
   }
   
   /** @param newAnio */
   public void setAnio(Integer newAnio) {
      anio = newAnio;
   }
   
   public Integer getNumero() {
      return numero;
   }
   
   /** @param newNumero */
   public void setNumero(Integer newNumero) {
      numero = newNumero;
   }

}