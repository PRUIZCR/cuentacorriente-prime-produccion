/***********************************************************************
 * Module:  TransaccionDpmnApplication.java
 * Author:  rcontreras
 * Purpose: Defines the Class TransaccionDpmnApplication
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.main;

import org.eclipse.jetty.server.Server;

import io.dropwizard.setup.Bootstrap;
import io.dropwizard.setup.Environment;
import io.dropwizard.views.ViewBundle;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.main.config.KfkObsConsuDamSeriesDpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.main.config.KfkObsConsuDpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.main.config.TransaccionDpmnConfig;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.ws.rest.RegistroDpmnRestService;
import pe.gob.sunat.tecnologia3.arquitectura.framework.kafka.healtcheck.KafkaConsumerHealthCheck;
import pe.gob.sunat.tecnologiams.arquitectura.framework.microservices.SunatApplication;
import pe.gob.sunat.tecnologiams.arquitectura.framework.microservices.exception.ConstraintViolationExceptionMapper;
import pe.gob.sunat.tecnologiams.arquitectura.framework.microservices.exception.GenericExceptionMapper;
import pe.gob.sunat.tecnologiams.arquitectura.framework.microservices.exception.ObjectNotFoundExceptionMapper;

public class TransaccionDpmnApplication  extends SunatApplication<TransaccionDpmnConfig> {	
	
	@Override
	public void onRun(TransaccionDpmnConfig configuration, Environment environment) throws Exception {
		environment.jersey().register(ConstraintViolationExceptionMapper.class);
		environment.jersey().register(ObjectNotFoundExceptionMapper.class);
		environment.jersey().register(GenericExceptionMapper.class);
		environment.jersey().register(RegistroDpmnRestService.class);
		TransaccionDpmnConfig.loadConfig(configuration);
		configuration.getMongodb().loadConfig();
		configureKafka(configuration, environment);
	}
	
	 @Override
     public  void onInitialize (Bootstrap<TransaccionDpmnConfig> bootstrap) {
       bootstrap.addBundle(new ViewBundle<>());
     }
     
     public static void main(String... params) throws Exception {
        new TransaccionDpmnApplication().run(params);
     }
     
     private void configureKafka(TransaccionDpmnConfig configuration, Environment environment) {
 		environment.lifecycle().addServerLifecycleListener((Server server) -> 
 			new Thread(() -> new KfkObsConsuDpmn(), configuration.getCfgKafkaConsumerDpmn().getTopic()).start()
 		);
 		
 		environment.lifecycle().addServerLifecycleListener((Server server) -> 
			new Thread(() -> new KfkObsConsuDamSeriesDpmn(), configuration.getCfgKafkaConsumerDamSeriesDpmn().getTopic()).start()
		);
 		
 		if (configuration.getCfgKafkaConsumerDpmn().isKafkaHealthCheck()) {
 			environment.healthChecks().register("healthCheck",
 					new KafkaConsumerHealthCheck(configuration.getCfgKafkaConsumerDpmn().getTopic()));
 		}
 		
 		if (configuration.getCfgKafkaConsumerDamSeriesDpmn().isKafkaHealthCheck()) {
 			environment.healthChecks().register("healthCheck",
 					new KafkaConsumerHealthCheck(configuration.getCfgKafkaConsumerDamSeriesDpmn().getTopic()));
 		}
 	}
}