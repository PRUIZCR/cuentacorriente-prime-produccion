package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.util;

import javax.persistence.PersistenceException;

import org.eclipse.persistence.exceptions.DatabaseException;

import com.atomikos.datasource.pool.CreateConnectionException;

import pe.gob.sunat.tecnologia3.arquitectura.framework.kafka.exception.ErrorException;
import pe.gob.sunat.tecnologia3.arquitectura.framework.kafka.exception.LoopException;
import pe.gob.sunat.tecnologiams.arquitectura.framework.microservices.util.ConstantesUtils;
import pe.gob.sunat.tecnologiams.arquitectura.framework.microservices.util.UtilLog;

public class ManageExceptionUtil {
	
	private ManageExceptionUtil() {
	      throw new IllegalAccessError("No se puede instanciar clase util");
	}
	
	
	public static void manageDatabaseException(UtilLog utilLog, DatabaseException de) {
		
		if (de.getCause() == null) {
			if (utilLog != null) {
				utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, Constantes.MSG_PERSISTENCE_EXCEPTION,
						de.getStackTrace());
			}
			throw new ErrorException(de);
		}

		if (de.getCause().getCause() instanceof CreateConnectionException) {
			utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, "Excepcion CreateConnectionException {}",
					de.getStackTrace());
			throw new LoopException(de);
		} else {
			if (utilLog != null) {
				utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, Constantes.MSG_PERSISTENCE_EXCEPTION,
						de.getStackTrace());
			}
			throw new ErrorException(de);
		}
		
	}
	
	
	public static void managePersistenceException(UtilLog utilLog, PersistenceException qe) {
		if (qe.getCause() == null || qe.getCause().getCause() == null) {
			if (utilLog != null) {
				utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, Constantes.MSG_PERSISTENCE_EXCEPTION,
						qe.getStackTrace());
			}
			throw new ErrorException(qe);
		}

		if (qe.getCause().getCause().getCause() instanceof CreateConnectionException) {
			utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, "Excepcion CreateConnectionException {}",
					qe.getStackTrace());
			throw new LoopException(qe);
		} else {
			if (utilLog != null) {
				utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, Constantes.MSG_PERSISTENCE_EXCEPTION,
						qe.getStackTrace());
			}
			throw new ErrorException(qe);
		}
	}
	
	
	

}
