/***********************************************************************
 * Module:  KafkaProducerDamSeriesDpmn.java
 * Author:  rcontreras
 * Purpose: Defines the Interface KafkaProducerDamSeriesDpmn
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.kafka.producer;

import java.util.*;

import com.fasterxml.jackson.core.JsonProcessingException;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.domain.DamSerieDpmn;

/** <p>Permite producir mensajes relacionados con el mantenimiento de la informaci&oacute;n de la colecci&oacute;n damSeriesDpmn. Esta colecci&oacute;n se encuentra en la base&nbsp; de datos mongodb de cuenta corriente de importaciones (bdCteCorrienteImpo)</p> */
public interface KafkaProducerDamSeriesDpmn {
   /** <p>Env&iacute;a un mensaje que indica que se desea registrar informaci&oacute;n</p>
    * 
    * @param damSeriesDpmn Informaci&oacute;n de las series de la DAM que se vinculan a la DPMN */
   void enviarMsgGuardar(List<DamSerieDpmn> damSeriesDpmn) throws JsonProcessingException;

}