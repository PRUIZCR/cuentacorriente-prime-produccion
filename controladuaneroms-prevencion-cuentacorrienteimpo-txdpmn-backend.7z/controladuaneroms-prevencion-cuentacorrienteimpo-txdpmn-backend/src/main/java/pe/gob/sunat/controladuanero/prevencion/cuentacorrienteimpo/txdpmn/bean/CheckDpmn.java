package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.bean;

public class CheckDpmn implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4644213816683555619L;
	private Long correlativoDpmn;
	private Integer cntSeriesDcl;
	private Integer cntArchivosAdjuntos;
	
	public Long getCorrelativoDpmn() {
		return correlativoDpmn;
	}
	public void setCorrelativoDpmn(Long correlativoDpmn) {
		this.correlativoDpmn = correlativoDpmn;
	}
	public Integer getCntSeriesDcl() {
		return cntSeriesDcl;
	}
	public void setCntSeriesDcl(Integer cntSeriesDcl) {
		this.cntSeriesDcl = cntSeriesDcl;
	}
	public Integer getCntArchivosAdjuntos() {
		return cntArchivosAdjuntos;
	}
	public void setCntArchivosAdjuntos(Integer cntArchivosAdjuntos) {
		this.cntArchivosAdjuntos = cntArchivosAdjuntos;
	}
	
	
	
}
