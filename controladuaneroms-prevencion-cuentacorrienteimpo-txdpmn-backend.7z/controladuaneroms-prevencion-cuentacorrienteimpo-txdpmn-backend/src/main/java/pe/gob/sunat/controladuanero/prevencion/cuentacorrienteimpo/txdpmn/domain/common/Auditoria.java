/***********************************************************************
 * Module:  Auditoria.java
 * Author:  rcontreras
 * Purpose: Defines the Class Auditoria
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.domain.common;

import java.util.Date;

public class Auditoria implements java.io.Serializable {
   /**
	 * 
	 */
	private static final long serialVersionUID = 1822553387388172049L;
	private Date fecRegis;
   private java.lang.String codUsuRegis;
   private Date fecModif;
   private java.lang.String codUsumodif;
   
   public Date getFecRegis() {
      return fecRegis;
   }
   
   /** @param newFecRegis */
   public void setFecRegis(Date newFecRegis) {
      fecRegis = newFecRegis;
   }
   
   public java.lang.String getCodUsuRegis() {
      return codUsuRegis;
   }
   
   /** @param newCodUsuRegis */
   public void setCodUsuRegis(java.lang.String newCodUsuRegis) {
      codUsuRegis = newCodUsuRegis;
   }
   
   public Date getFecModif() {
      return fecModif;
   }
   
   /** @param newFecModif */
   public void setFecModif(Date newFecModif) {
      fecModif = newFecModif;
   }
   
   public java.lang.String getCodUsumodif() {
      return codUsumodif;
   }
   
   /** @param newCodUsumodif */
   public void setCodUsumodif(java.lang.String newCodUsumodif) {
      codUsumodif = newCodUsumodif;
   }

}