/***********************************************************************
 * Module:  NotificacionRegistroDpmn.java
 * Author:  rcontreras
 * Purpose: Defines the Class NotificacionRegistroDpmn
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.services;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.bean.ArchivoAdjunto;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.bean.AvisoCorreo;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.bean.CorreoRegistroDpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.bean.PlantillaAviso;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.util.CodigoQR;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.util.TransaccionDpmnException;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.util.TxDpmnUtils;
import pe.gob.sunat.tecnologiams.arquitectura.framework.microservices.util.UtilLog;


public class NotificacionRegistroDpmn {
	@Inject private AvisoCorreoService avisoCorreoService;
	@Inject private AvisoCorreo avisoCorreo;
	@Inject private AvisoBuzonSolService avisoBuzonSolService;
	@Inject private UtilLog utilLog;
   private static final Integer COD_SERVICIO_PLANTILLA_TRANSPORTISTA = 658;
   private static final Integer COD_SERVICIO_PLANTILLA_IMPORTADOR = 659;
   private static final String NOMBRE_IMAGEN_QR = "ficha-qr-dpmn.png";
	public final static String COD_TIPOAVISO_MENSAJE = "2";
   /**
    * Mensaje simple en buzon SOL
    */
   public static final String TIPO_AVISO_BUZON_SOL = "2";/**
    * Mensaje simple en buzon SOL
    */
   public static final String CATALOGO_ADUANAS = "00";
   /** @pdGenerated default parent getter */
   public static final String  TIPO_USUARIO_CONTRIBUYENTE ="1";
   
   public AvisoCorreoService getAvisoCorreoService() {
      return avisoCorreoService;
   }
   
   /** @pdGenerated default parent setter
     * @param newAvisoCorreoService */
   public void setAvisoCorreoService(AvisoCorreoService newAvisoCorreoService) {
      this.avisoCorreoService = newAvisoCorreoService;
   }
   
   /** @param param 
 * @throws Exception */
   public void notificarTransportista(CorreoRegistroDpmn param) {
	  // completarPlantillaAviso() 
		   java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		   PlantillaAviso plantilla = new PlantillaAviso();
		   plantilla.setNumeroServicio(COD_SERVICIO_PLANTILLA_TRANSPORTISTA);
		   
		   java.util.Map<String, String> dataPlantilla = new java.util.HashMap<>();
		   dataPlantilla.put("nombre", param.getDestinatario().getNombre());
		   dataPlantilla.put("puestoControl", param.getPuestoControl());
		   dataPlantilla.put("aduanaDescarga", param.getAduanaDescarga());
		   dataPlantilla.put("numeroDpmn", param.getNumeroDpmn());
		   dataPlantilla.put("fechaDpmn", param.getFechaDpmn());
		   dataPlantilla.put("fechaEmision", sdf.format(new java.util.Date()));
		   dataPlantilla.put("codigoQR", NOMBRE_IMAGEN_QR);
		   //FALTA AGREGAR DATOS DEL TRANSPORTISTA
		   plantilla.setData(dataPlantilla);
		   avisoCorreo.setPlantilla(plantilla);
		 
		   //addArchivosAdjuntos()
		   try {
			   avisoCorreo.getAdjuntos().clear();
			   ArchivoAdjunto archivoAdjunto = new ArchivoAdjunto();
			   archivoAdjunto.setContenido(CodigoQR.generar(param.getCorrelativoDpmn().toString(), 250, 250));
			   archivoAdjunto.setNombre(NOMBRE_IMAGEN_QR);
			   archivoAdjunto.setTipoContenido("image/png");
			   this.avisoCorreo.addAdjuntos(archivoAdjunto);
			   //datos generales
			  this.avisoCorreo.setRemitente("webmaster@sunat.gob.pe");
			  this.avisoCorreo.setAsunto("Notificaci\u00f3n Transportista por numeraci\u00f3n DPMN");
			  this.avisoCorreo.setDestinatario(param.getDestinatario().getCorreo());
			  this.avisoCorreoService.generarAviso(avisoCorreo);
		   } catch(java.lang.Exception ex) {
			 ex.getMessage();
		   }
	   
   }
   
   /** @param param */
   public void notificarImportador(CorreoRegistroDpmn param,  String rucImportador, String aduanaDAM) {
	   Map<String, Object> mapMsg = new HashMap<String, Object>();
	   Long numeroSecuenciaAviso = null;
	   java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
	   PlantillaAviso plantilla = new PlantillaAviso();
	   plantilla.setNumeroServicio(COD_SERVICIO_PLANTILLA_IMPORTADOR);
	 //Fecha actual
		Date fechaActual = new Date();
		String fechaActualFormat = sdf.format(fechaActual);
		Date date = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        Timestamp fechaCreacion = new Timestamp(calendar.getTime().getTime());
	 //Fecha vigencia limitada
		Date fechaActualCalendar =  new Date();
		Calendar c = Calendar.getInstance(); 
		c.setTime(fechaActualCalendar); 
		c.add(Calendar.DATE, 30);
		Timestamp fechaVigenciaLimitada = new Timestamp(c.getTime().getTime());	
		mapMsg.put("tip_usuario", TIPO_USUARIO_CONTRIBUYENTE); 
		mapMsg.put("cod_usuario", new String[] {rucImportador});
		mapMsg.put("des_asunto", "Notificaci\\u00f3n Importador por numeraci\\u00f3n DPMN");
		mapMsg.put("fechahoy",fechaActualFormat);
		String URL_WS_CONSULTA_CATALOGO="http://api.sunat.peru/v1/estrategico/aduanero/mantmodulo/e/catalogos/00/datoscatalogos/"+aduanaDAM;
		ArrayList<HashMap<String, Object>> datosIntendencia = (ArrayList<HashMap<String, Object>>) TxDpmnUtils.consumirREST(URL_WS_CONSULTA_CATALOGO);
	   String endpointCatalogoDni="";
	   if(datosIntendencia==null || datosIntendencia.get(0).containsKey("cod")) {
			return;
	   }else {
		   endpointCatalogoDni= (String) datosIntendencia.get(0).get("desDatoCatalogo");
		   mapMsg.put("des_intendencia", endpointCatalogoDni);
			
	   }
				
	   mapMsg.put("puestoControl", param.getPuestoControl());
	   mapMsg.put("aduanaDescarga", param.getAduanaDescarga());
	   mapMsg.put("numeroDpmn", param.getNumeroDpmn());
	   mapMsg.put("fechaDpmn", param.getFechaDpmn());
	   mapMsg.put("fechaEmision", fechaActualFormat);
	   ObjectMapper mapper = new ObjectMapper(); 
		mapper.setSerializationInclusion(Include.NON_NULL);
	    StringBuilder dataAviso = new StringBuilder();
		try {
			dataAviso.append(mapper.writeValueAsString(mapMsg));
		} catch (JsonProcessingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	   /** 0 : Aviso electr�nico, 1 : Notificaci�n, 2 : Mensaje simple en el buz�n */
	  try {
		numeroSecuenciaAviso =  this.avisoBuzonSolService.insert(COD_SERVICIO_PLANTILLA_IMPORTADOR,  new StringBuffer(dataAviso), TIPO_AVISO_BUZON_SOL, fechaCreacion, fechaVigenciaLimitada);
	} catch (TransaccionDpmnException ex) {
		this.utilLog.imprimirLog("enviarAviso() : [Numero Secuencia Aviso] : " + numeroSecuenciaAviso, endpointCatalogoDni);
		ex.getMessage();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.getMessage();
	}

   }   
}