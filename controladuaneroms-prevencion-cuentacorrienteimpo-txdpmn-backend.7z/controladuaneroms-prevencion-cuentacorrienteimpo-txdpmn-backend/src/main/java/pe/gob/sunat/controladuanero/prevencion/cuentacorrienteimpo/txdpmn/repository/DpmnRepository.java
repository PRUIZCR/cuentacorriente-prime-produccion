/***********************************************************************
 * Module:  DpmnRepository.java
 * Author:  rcontreras
 * Purpose: Defines the Interface DpmnRepository
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.repository;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.bean.CheckDpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.domain.Dpmn;

/** <p>Permite trabajar con la colecci&oacute;n "dpmns"</p> */
public interface DpmnRepository {
   /** <p>Graba la informaci&oacute;n de la DPMN.</p>
    * <p>Esta informaci&oacute;n la guarda en la colecci&oacute;n "dpmns"</p>
    * 
    * @param dpmn Informaci&oacute;n de la DPMN */
   void grabar(Dpmn dpmn);
   
   boolean seTerminoDeRegistrar(CheckDpmn chkDpmn);
   
   
   /**
    * Busca una DPMN por su correlativo
    * @param correlativoDpmn Correlativo DPMN
    * @return
    * <ul>
    * 	<li>Si existe la DPMN, esta es retornada</li>
    * 	<li>Si no existe la DPMN, se retorna NULL</li>
    * </ul> 
    */
   Dpmn buscar(Long correlativoDpmn);
}