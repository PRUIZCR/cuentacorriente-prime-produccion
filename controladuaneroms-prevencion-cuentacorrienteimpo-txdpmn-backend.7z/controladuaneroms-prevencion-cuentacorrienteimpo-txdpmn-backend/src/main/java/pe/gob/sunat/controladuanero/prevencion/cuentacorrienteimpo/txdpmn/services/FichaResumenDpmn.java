package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.services;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.List;

import javax.inject.Inject;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.bean.DataFichaDpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.domain.CartaPorte;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.domain.ComprobantePago;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.domain.DamSerieDpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.domain.Dpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.domain.GuiaRemision;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.repository.DamSerieDpmnRepository;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.repository.DpmnRepository;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.util.CodigoQR;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.util.TxDpmnUtils;

/**
 * 
 * @author rcontreras
 */
public class FichaResumenDpmn {
	
	@Inject private DpmnRepository dpmnRepository;
	@Inject private DamSerieDpmnRepository damSerieDpmnRepository;
	
	public byte[] generarFichaResumenQR(long correlativoDpmn) {
		
		try {
			
			byte[] codigoQR = CodigoQR.generar(String.valueOf(correlativoDpmn), 80, 80);
			
			Dpmn dpmn = this.dpmnRepository.buscar(correlativoDpmn);
			
			List<DamSerieDpmn> lstDamSeriesDpmn = this.damSerieDpmnRepository.buscar(correlativoDpmn, false);
			
			InputStream isCodigoQR = new ByteArrayInputStream(codigoQR);
			
			java.util.Map<String, Object> parametros = new java.util.HashMap<>();
			parametros.put("CODIGO_QR", isCodigoQR);
			
			List<DataFichaDpmn> dataReporte = this.buildDataFichaResumenQR(dpmn, lstDamSeriesDpmn);
			JRDataSource dsComprobantes = new JRBeanCollectionDataSource(dataReporte.get(0).getComprobantes());
			JRDataSource dsDeclaraciones = new JRBeanCollectionDataSource(dataReporte.get(0).getDeclaraciones());
			
			parametros.put("DS_COMPROBANTES", dsComprobantes);
			parametros.put("DS_DECLARACIONES", dsDeclaraciones);
			
			ReporteJasper reporte = new ReporteJasper(parametros, dataReporte, "ficha-qr-dpmn.jasper");
			
			return reporte.generarReportePDF();
		} catch ( java.lang.Exception ex ) {
			return new byte[0];
		}		
	}
	
	private List<DataFichaDpmn> buildDataFichaResumenQR(Dpmn dpmn, List<DamSerieDpmn> lstDamSeriesDpmn) {
		List<DataFichaDpmn> resultado = new java.util.ArrayList<>();
		
		DataFichaDpmn dataFichaDpmn = new DataFichaDpmn();
		
		String numeroDpmn = TxDpmnUtils.getNumeroDpmn(dpmn);
		String aduanaDpmn = TxDpmnUtils.getCodDesCatalogo(dpmn.getAduana());
		String puestoControl = TxDpmnUtils.getCodDesCatalogo(dpmn.getPuestoControlDescarga());
		String fechaRegistro = TxDpmnUtils.getFechaFormateada(dpmn.getFecDpmn(), "dd/MM/yyyy HH:mm");
		String nacionalidadEmpTrans = TxDpmnUtils.obtenerValorPropiedad("empresaTransporte.tipoNacionalidad.desDataCat", dpmn, String.class);
		String rucEmpTrans = TxDpmnUtils.obtenerValorPropiedad("empresaTransporte.numDocIdentidad", dpmn, String.class);
		String razSocialEmpTrans = TxDpmnUtils.obtenerValorPropiedad("empresaTransporte.nomEmpresa", dpmn, String.class);
		String paisPlaca = TxDpmnUtils.obtenerValorPropiedad("empresaTransporte.paisPlaca.desDataCat", dpmn, String.class);
		String placa = TxDpmnUtils.obtenerValorPropiedad("empresaTransporte.nomPlaca", dpmn, String.class);
		String paisPlacaRemolque = TxDpmnUtils.obtenerValorPropiedad("empresaTransporte.paisPlacaCarreta.desDataCat", dpmn, String.class);
		String placaRemolque = TxDpmnUtils.obtenerValorPropiedad("empresaTransporte.nomPlacaCarreta", dpmn, String.class);
		String paisConductor = TxDpmnUtils.obtenerValorPropiedad("conductor.pais.desDataCat", dpmn, String.class);
		String nombreConductor = TxDpmnUtils.obtenerValorPropiedad("conductor.nomConductor", dpmn, String.class) + " " + 
									TxDpmnUtils.obtenerValorPropiedad("conductor.apeConductor", dpmn, String.class);
		String tipoDocConductor = TxDpmnUtils.obtenerValorPropiedad("conductor.tipoDocIdentidad.desDataCat", dpmn, String.class);
		String numDocConductor = TxDpmnUtils.obtenerValorPropiedad("conductor.numDocIdentidad", dpmn, String.class);
		String licenciaConductor = TxDpmnUtils.obtenerValorPropiedad("conductor.numLicencia", dpmn, String.class);
		
		String observaciones = TxDpmnUtils.obtenerValorPropiedad("datoComplementario.desObservacion", dpmn, String.class);
		
		String separador = "/";
		java.lang.StringBuilder sb = new java.lang.StringBuilder();
		sb.append(TxDpmnUtils.obtenerValorPropiedad("datoComplementario.ubigeoOrigen.codUbigeo", dpmn, String.class));
		sb.append(" ");
		sb.append(TxDpmnUtils.obtenerValorPropiedad("datoComplementario.ubigeoOrigen.nomDepartamento", dpmn, String.class));
		sb.append(separador);
		sb.append(TxDpmnUtils.obtenerValorPropiedad("datoComplementario.ubigeoOrigen.nomProvincia", dpmn, String.class));
		sb.append(separador);
		sb.append(TxDpmnUtils.obtenerValorPropiedad("datoComplementario.ubigeoOrigen.nomDistrito", dpmn, String.class));
		
		String ubigeo = sb.toString();
		
		
		dataFichaDpmn.setNumeroDpmn(numeroDpmn);
		dataFichaDpmn.setAduanaDpmn(aduanaDpmn);
		dataFichaDpmn.setPuestoControl(puestoControl);
		dataFichaDpmn.setFechaRegistro(fechaRegistro);
		dataFichaDpmn.setNacionalidadEmpTrans(nacionalidadEmpTrans);
		
		dataFichaDpmn.setRucEmpTrans(rucEmpTrans);
		dataFichaDpmn.setRazSocialEmpTrans(razSocialEmpTrans);
		dataFichaDpmn.setPaisPlaca(paisPlaca);
		dataFichaDpmn.setPlaca(placa);
		dataFichaDpmn.setPaisPlacaRemolque(paisPlacaRemolque);
		dataFichaDpmn.setPlacaRemolque(placaRemolque);
		
		dataFichaDpmn.setNacionalidadConductor(paisConductor);
		dataFichaDpmn.setNombreConductor(nombreConductor);
		dataFichaDpmn.setTipoDocConductor(tipoDocConductor);
		dataFichaDpmn.setNumDocConductor(numDocConductor);
		dataFichaDpmn.setLicenciaConductor(licenciaConductor);
		
		dataFichaDpmn.setOrigen(ubigeo);
		dataFichaDpmn.setObservacion(observaciones);
		
		dpmn.getComprobantePago().forEach(itemComp -> dataFichaDpmn.addComprobante(this.buildCompDeFichaDpmn(itemComp)));
		
		lstDamSeriesDpmn.forEach(itemDclDpmn -> dataFichaDpmn.addDeclaracion(this.buildDclDeFichaDpmn(itemDclDpmn, dataFichaDpmn.getComprobantes())));
		
		resultado.add(dataFichaDpmn);
		
		return resultado;
	}
	
	private DataFichaDpmn.Comprobante buildCompDeFichaDpmn(ComprobantePago itemComp) {
		
		DataFichaDpmn.Comprobante resultado = new DataFichaDpmn.Comprobante();
		
		if ( itemComp instanceof GuiaRemision  ) {
			GuiaRemision guia = (GuiaRemision)itemComp;
			resultado.setNumero(guia.getNumGuia() + "-" + guia.getNumSerie());
			resultado.setRucRemitente(guia.getNumRucRemitente());
			resultado.setRazonRemitente(guia.getDesRazonSocialRemitente());			
		} else if ( itemComp instanceof CartaPorte ) {
			CartaPorte cartaPorte = (CartaPorte)itemComp;
			resultado.setNumero(cartaPorte.getNumCartaPorte());
			resultado.setEmpresa(cartaPorte.getNomEmpresa());
		}
		
		resultado.setNumCorrelativo(itemComp.getNumCorrelativo());
		
		resultado.setMotivo(itemComp.getMotivoDeTraslado().getDesDataCat());
		
		resultado.setRucDestinatario(itemComp.getNumRucDestinatario());
		resultado.setRazonDestinatario(itemComp.getDesRazonSocialDestinatario());
		resultado.setDestino(itemComp.getUbigeoDestino().getCodUbigeo());	
		
		return resultado;
	}
	
	
	
	private DataFichaDpmn.Declaracion buildDclDeFichaDpmn(DamSerieDpmn damSerieDpmn, List<DataFichaDpmn.Comprobante> lstCompFichaDpmn) {
		
		DataFichaDpmn.Declaracion dclFichaDpmn = new DataFichaDpmn.Declaracion();		
		
		dclFichaDpmn.setCntdeclarada(damSerieDpmn.getCntUnidadFisica());
		dclFichaDpmn.setCntretirada(damSerieDpmn.getCntRetirada());
		dclFichaDpmn.setDam(TxDpmnUtils.obtenerNumeroDam(damSerieDpmn));
		dclFichaDpmn.setDescripcion(damSerieDpmn.getDesComercial());
		dclFichaDpmn.setSerie(damSerieDpmn.getNumSerie());
		
		String codUnidad = TxDpmnUtils.obtenerValorPropiedad("unidadFisica.codDatacat", damSerieDpmn, String.class);
		
		dclFichaDpmn.setUnidad(codUnidad);
		
		
		DataFichaDpmn.Comprobante compFichaDpmn = lstCompFichaDpmn.stream()
				.filter(itCmp -> itCmp.getNumCorrelativo().equals(damSerieDpmn.getNumCorreCompDpmn())).findFirst()
				.orElse(null);
		
		if ( compFichaDpmn != null ) {
			dclFichaDpmn.setComprobante(compFichaDpmn.getNumero());
		}
		
		return dclFichaDpmn;
	}	
	
}
 