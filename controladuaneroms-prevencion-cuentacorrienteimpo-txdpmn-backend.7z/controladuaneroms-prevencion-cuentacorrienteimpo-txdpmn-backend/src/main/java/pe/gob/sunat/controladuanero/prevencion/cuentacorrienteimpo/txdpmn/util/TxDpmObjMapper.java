package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.util;

import java.text.SimpleDateFormat;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * 
 * @author rcontreras
 *
 */
public class TxDpmObjMapper extends ObjectMapper {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5164333214173018122L;

	public TxDpmObjMapper() {
	
		super();
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");        
        this.setSerializationInclusion(Include.NON_NULL);
        this.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        this.disable(DeserializationFeature.FAIL_ON_NULL_FOR_PRIMITIVES);
        this.disable(DeserializationFeature.FAIL_ON_INVALID_SUBTYPE);
        this.setDateFormat(dateFormat);
	}

}
