/***********************************************************************
 * Module:  AvisoCorreoService.java
 * Author:  rcontreras
 * Purpose: Defines the Interface AvisoCorreoService
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.services;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.bean.AvisoCorreo;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.util.TransaccionDpmnException;

public interface AvisoCorreoService {
   /** @param avisoCorreo 
 * @throws TransaccionDpmnException */
   void generarAviso(AvisoCorreo avisoCorreo) throws TransaccionDpmnException;

}