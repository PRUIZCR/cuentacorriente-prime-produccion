/***********************************************************************
 * Module:  DamSeriesDpmnServiceImpl.java
 * Author:  rcontreras
 * Purpose: Defines the Class DamSeriesDpmnServiceImpl
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.services;

import java.util.*;

import javax.inject.Inject;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.domain.DamSerieDpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.repository.DamSerieDpmnRepository;

public class DamSeriesDpmnServiceImpl implements DamSeriesDpmnService {
	@Inject
	private DamSerieDpmnRepository damSerieDpmnRepository;
	@Override
	public void grabar(List<DamSerieDpmn> damSeriesDpmn) {
		//1. Invocar el siguiente m�todo:		
		this.damSerieDpmnRepository.grabar(damSeriesDpmn);
		
	}
}