/***********************************************************************
 * Module:  AvisosDAO.java
 * Author:  msancheza
 * Purpose: Defines the Interface AvisosDAO
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.dao;

import java.math.BigDecimal;
import java.sql.Timestamp;

import org.eclipse.persistence.exceptions.DatabaseException;

public interface AvisosDAO {
	 public void insert(Long numId,Integer servicioId,StringBuffer data,String tipoAviso,Timestamp fechaPublicacion,Timestamp fechaVigencia,Timestamp fechaCreacion,String tipoProcUsu) throws DatabaseException;

	 public BigDecimal getSecuencia();

}