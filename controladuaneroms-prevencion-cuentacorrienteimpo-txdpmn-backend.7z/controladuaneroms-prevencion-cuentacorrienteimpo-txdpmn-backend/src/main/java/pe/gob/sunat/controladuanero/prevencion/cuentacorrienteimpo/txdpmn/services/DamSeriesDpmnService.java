/***********************************************************************
 * Module:  DamSeriesDpmnService.java
 * Author:  rcontreras
 * Purpose: Defines the Interface DamSeriesDpmnService
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.services;

import java.util.*;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.domain.DamSerieDpmn;

public interface DamSeriesDpmnService {
   /** @param damSeriesDpmn */
   void grabar(List<DamSerieDpmn> damSeriesDpmn);

}