/***********************************************************************
 * Module:  KafkaMsgDpmn.java
 * Author:  rcontreras
 * Purpose: Defines the Class KafkaMsgDpmn
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.bean;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.domain.Dpmn;

/**
 * <p>
 * Representa un mensaje relacionado con el mantenimiento de la
 * informaci&oacute;n de la DPMN
 * </p>
 */
public class KafkaMsgDpmn implements java.io.Serializable {
   /**
	 * 
	 */
	private static final long serialVersionUID = -8606170056014353663L;
/** <p>Representa el tipo de operaci&oacute;n de mantenimiento de informaci&oacute;n. Por ejemplo: Actualizar, modificar, eliminar. etc</p> */
   private String tipoOperacion;
   /** <p>Informaci&oacute;n de la DPMN</p> */
   private Dpmn data;
   /** <p>Correlativo de la DPMN que se desear&iacute;a eliminar. Este valor es tomado en cuenta s&oacute;lo en caso se trate de una operaci&oacute;n de eliminaci&oacute;n de informaci&oacute;n</p> */
   private Long correlativoDpmnEliminar;
   
   public String getTipoOperacion() {
      return tipoOperacion;
   }
   
   /** @param newOperacion */
   public void setTipoOperacion(String newOperacion) {
      tipoOperacion = newOperacion;
   }
   
   public Dpmn getData() {
      return data;
   }
   
   /** @param newData */
   public void setData(Dpmn newData) {
      data = newData;
   }
   
   public Long getCorrelativoDpmnEliminar() {
      return correlativoDpmnEliminar;
   }
   
   /** @param newCorrelativoDpmnEliminar */
   public void setCorrelativoDpmnEliminar(Long newCorrelativoDpmnEliminar) {
      correlativoDpmnEliminar = newCorrelativoDpmnEliminar;
   }

}