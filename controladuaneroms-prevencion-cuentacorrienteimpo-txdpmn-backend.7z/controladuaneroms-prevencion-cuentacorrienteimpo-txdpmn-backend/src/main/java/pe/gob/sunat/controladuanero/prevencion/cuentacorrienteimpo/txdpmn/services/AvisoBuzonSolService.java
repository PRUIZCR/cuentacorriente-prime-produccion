package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.services;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.Date;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.util.TransaccionDpmnException;

public interface AvisoBuzonSolService {


	Long insert(Integer servicioId, StringBuffer data, String tipoAviso, Timestamp fechaPublicacion,	Timestamp fechaVigencia) throws TransaccionDpmnException, IOException;

}
