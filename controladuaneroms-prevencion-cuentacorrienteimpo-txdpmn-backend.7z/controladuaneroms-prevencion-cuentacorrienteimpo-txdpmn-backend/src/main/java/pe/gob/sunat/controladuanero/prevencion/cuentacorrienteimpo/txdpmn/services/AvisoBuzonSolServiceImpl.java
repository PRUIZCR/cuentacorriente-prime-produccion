package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.services;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.dao.AvisosDAO;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.util.Constantes;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.util.TransaccionDpmnException;

public class AvisoBuzonSolServiceImpl implements AvisoBuzonSolService {
	@Inject private AvisosDAO avisosDAO;
	private String dirAvisos;
	private List tiposAviso;

	public String getDirAvisos() {
		return dirAvisos;
	}

	public void setDirAvisos(String dirAvisos) {
		this.dirAvisos = dirAvisos;
	}

	public List getTiposAviso() {
		return tiposAviso;
	}

	public void setTiposAviso(List tiposAviso) {
		this.tiposAviso = tiposAviso;
	}

	private Log log = LogFactory.getLog(this.getClass());
	/**
	 * Metodo que permite registrar un aviso electronico al buzon sol
	 * 
	 * @param servicioId Integer n�mero que identifica la plantilla a utilizar y el servicio al cual se ha suscrito para obtener informaci�n. Estos servicios deben estar registrados en DataCatalogo
	 * @param data StringBuffer datos en formato json, -Campos fijos:cod_usuario = arreglo ruc/codigo de operador de comercio, des_asunto = sirve para el envio de correo electronico o envio al buzon sunat
	 *     tip_usuario = para identificar si es contribuyente, operador de comercio y funcionario SUNAT codigos 1, 2 y 3 respectivamente,
	 *    - Campos obligatorios para el env�o de documentos adjuntos.
			path_name: ruta del archivo del siguiente formato: /data1/sigad/avisos/<nombre-carpeta-de-negocio>/<nombre-archivo.ext>
			file_name: nombre del archivo(<nombre-archivo.ext>) 
	 *    -Datos adicionales que se utilizaran en la plantilla 
	 * @param tipoAviso String 0:aviso electr�nico, 1:notificaci�n, 2:mensaje simple en el buz�n
	 * @param fechaPublicacion Timestamp fecha y hora que se env�a al buz�n electr�nico
	 * @param fechaVigencia Timestamp
	 * @return Long retorna la secuencia del aviso
	 * @throws IOException 
	 * 
	 */
	@Override
	public Long insert(Integer servicioId, StringBuffer data, String tipoAviso, Timestamp fechaPublicacion,	Timestamp fechaVigencia) throws TransaccionDpmnException, IOException {
		Long numId = avisosDAO.getSecuencia().longValue();
		
		Date date = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        int dateYear = calendar.get(Calendar.YEAR);
       
        Long idAviso = new Long(String.valueOf(dateYear).concat(String.valueOf(numId)));
		if (validaDatosBuzonSol(servicioId,data,tipoAviso,fechaPublicacion,fechaVigencia,"1")){
			
			/*
			 * Object[] conversion = evaluarConversion(servicioId); if (conversion != null)
			 * { tipoAviso = (String) conversion[0]; fechaVigencia = (Timestamp)
			 * conversion[1]; }
			 */
			Timestamp fechaCreacion = new Timestamp(calendar.getTime().getTime());
			this.avisosDAO.insert(idAviso, servicioId, data, tipoAviso, fechaPublicacion, fechaVigencia, fechaCreacion, "1");
			
		} 
		return idAviso;	
	}

	/**
	 * Metodo que evalua si el servicioId corresponde a un MENSAJE, de ser asi entonces se modifica la fecha de vigencia y el tipo de aviso.
	 * @param servicioId identificador del servicio
	 * @return tipo de aviso y fecha de vigencia modificadas
	 * @author glazaror
	 * 
	 */
	private Object[] evaluarConversion(int servicioId) {
		String servicioIdAsString = "" + servicioId;
		//DataGrupoCat elementoMensajeEncontrado = catalogoAyudaService.getDataGrupoCat(Constantes.COD_GRUPO_MENSAJES, servicioIdAsString);
		//if (elementoMensajeEncontrado != null) {
			//entonces sobreescribimos los atributos tipoAviso (forzamos que sea MENSAJE) y fechaVigencia (buscamos la cantidad de dias de vigencia configurado para el servicioId)
			String tipoAviso = Constantes.COD_TIPOAVISO_MENSAJE;
			//obtenemos la cantidad de dias de vigencia configurado para el servicioId
			int diasVigencia = obtenerCantidadDiasVigencia(servicioIdAsString);
			
			//entonces la fecha de vigencia sera la fecha actual mas los dias configurados como vigencia
			//Date fechaVigenciaAsDate = DateUtils.addDays(new Date(), diasVigencia);
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(new Date());
			calendar.add(Calendar.DAY_OF_MONTH, diasVigencia);
			
			Timestamp fechaVigencia = (Timestamp) new Timestamp(calendar.getTime().getTime());
			return new Object[] {tipoAviso, fechaVigencia};
		//}
		//return null;
	}
	/**
	 * Obtiene la cantidad de dias de vigencia que se debe aplicar al servicioId especificado.
	 * @param servicioId identificador del servicio
	 * @return dias de vigencia del servicioId
	 * @author glazaror
	 */
	private int obtenerCantidadDiasVigencia(String servicioId) {
		String ayudaId = "DataAtributo";
	    Map<String, Object> params = new HashMap<String, Object>();
	    params.put("ayudaID", ayudaId);
	    params.put("codAtributo", Constantes.COD_ATRIBUTO_MENSAJE_DIASVIGENCIA);
	    params.put("codGrupo", Constantes.COD_GRUPO_MENSAJES);
	    params.put("codCatalogo", Constantes.COD_CATALOGO_AVISOSELECTRONICOS);
	    params.put("codDatacat", servicioId);
	    
	    //buscamos los dias de vigencia configurados
	    //se tiene que implementar ka conuslta al catalogo
	    //List<Map<String, Object>> registros = ayudaService.buscar(params);
	    
	    int diasVigencia = 0;
		/*
		 * if (!registros.isEmpty()) { //si es que encontramos configuracion de dias de
		 * vigencia para el servicioId entonces asignamos este valor Map<String, Object>
		 * registro = (Map<String, Object>) registros.get(0); String valorAtributo =
		 * (String) registro.get("val_atributo"); diasVigencia =
		 * Integer.parseInt(valorAtributo); } else {
		 */
	    	//si es que no se cuenta con configuracion de dias de vigencia entonces se asigna la cantidad de dias de vigencia por default
	    	diasVigencia = 30;//se debe de poner en catalogo
	    //}
	    return diasVigencia;
	}
	/**
	 * 
	 * @param servicioId
	 * @param data
	 * @param tipoAviso
	 * @param fechaPublicacion
	 * @param fechaVigencia
	 * @param tipoData
	 * @return
	 */
	private boolean validaDatosBuzonSol(Integer servicioId, StringBuffer data,	String tipoAviso, Timestamp fechaPublicacion, Timestamp fechaVigencia,String tipoData) throws TransaccionDpmnException {
		if (servicioId == null || servicioId.intValue()==0){
			this.log.info("El codigo del servicio es nulo o cero");
			
		}
		//JsonSerializer jsonSerializer = new JsonSerializer();
		Map dataPlantilla = null;
		ObjectMapper mapper = new ObjectMapper();
 		Map lstObjetoDeserializado;
		try {
			dataPlantilla = mapper.readValue(data.toString(), Map.class);
			this.log.info("Objeto deserializado: " + dataPlantilla);
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
 		
		if ("1".equals(tipoData)){
			if (dataPlantilla.get("cod_usuario")==null || dataPlantilla.get("des_asunto")==null
					|| dataPlantilla.get("tip_usuario")==null){
				this.log.info("Los datos no tienen alguna de las llaves fijas cod_usuario, des_asunto o tip_usuario");
			}
			List listaUsuarios = null;
			listaUsuarios = (List)dataPlantilla.get("cod_usuario");
			if (listaUsuarios.size()==0){
				this.log.info("La lista de usuarios esta vacia");
			}
			if (listaUsuarios.contains("")){
				this.log.info("La lista usuarios tiene una cadena vacia");
			}
			if ("2".equals(dataPlantilla.get("tip_usuario")) && ("1".equals(tipoAviso) || "2".equals(tipoAviso))){// si es operador y tipo aviso es notificacion o mensaje simple al buzon
				this.log.info("El operador de comercio solo puede publicar un aviso del tipo aviso electr�nico (correo electr�nico y celulares)");
			}
			if ("3".equals(dataPlantilla.get("tip_usuario")) && ("1".equals(tipoAviso) || "2".equals(tipoAviso))){// si es usuario interno y tipo aviso es notificacion o mensaje simple al buzon
				this.log.info("El funcionario SUNAT solo puede publicar un aviso del tipo aviso electr�nico (correo electr�nico y celulares)");
			}
		}
		if (tipoAviso == null || "".equals(tipoAviso)){
			this.log.info("El tipo de aviso es nulo o vacio");
		}
		if (fechaPublicacion == null || fechaVigencia == null){
			this.log.info("Fecha de publicacion o vigencia es nulo");
		}
		if (fechaPublicacion.after(fechaVigencia)){
			this.log.info("Fecha de publicacion debe ser menor a la fecha de vigencia");
			}
		return true;
	}
	
}
