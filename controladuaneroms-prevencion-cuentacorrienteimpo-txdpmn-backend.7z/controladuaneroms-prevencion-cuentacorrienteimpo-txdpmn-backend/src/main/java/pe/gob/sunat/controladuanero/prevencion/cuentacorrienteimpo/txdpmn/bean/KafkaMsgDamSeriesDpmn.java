/***********************************************************************
 * Module:  KafkaMsgDamSeriesDpmn.java
 * Author:  rcontreras
 * Purpose: Defines the Class KafkaMsgDamSeriesDpmn
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.bean;

import java.util.*;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.domain.DamSerieDpmn;

/**
 * <p>
 * Representa un mensaje relacionado con el mantenimiento de la
 * informaci&oacute;n de la Series de la DAM vinculadas a la DPMN
 * </p>
 */
public class KafkaMsgDamSeriesDpmn implements java.io.Serializable {
   /**
	 * 
	 */
	private static final long serialVersionUID = -664628841345102267L;
/** <p>Representa el tipo de operaci&oacute;n de mantenimiento de informaci&oacute;n. Por ejemplo: Actualizar, modificar, eliminar. etc</p> */
   private String tipoOperacion;
   /** <p>Informaci&oacute;n de las series de la DAM vinculadas a la DPMN</p> */
   private List<DamSerieDpmn> damSeriesDpmn;
   
   public String getTipoOperacion() {
      return tipoOperacion;
   }
   
   /** @param newTipoOperacion */
   public void setTipoOperacion(String newTipoOperacion) {
      tipoOperacion = newTipoOperacion;
   }
   
   public List<DamSerieDpmn> getDamSeriesDpmn() {
      return damSeriesDpmn;
   }
   
   /** @param newDamSeriesDpmn */
   public void setDamSeriesDpmn(List<DamSerieDpmn> newDamSeriesDpmn) {
      damSeriesDpmn = newDamSeriesDpmn;
   }

}