/***********************************************************************
 * Module:  EventMantenimientoDpmn.java
 * Author:  rcontreras
 * Purpose: Defines the Class EventMantenimientoDpmn
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.services;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.bean.IdentificadorDPMN;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.domain.DamSerieDpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.domain.Dpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.kafka.producer.KafkaProducerDamSeriesDpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.kafka.producer.KafkaProducerDpmn;

import java.util.*;

import javax.inject.Inject;

import com.fasterxml.jackson.core.JsonProcessingException;

/** <p>Se encarga de inicializar eventos referentes al mantenimiento de la informaci&oacute;n de la DPMN.&nbsp;</p>
 * <p>Estos eventos se enviaran como mensajes en Kafka a trav&eacute;s de un producer, con el fin de que estas luego
 *  puedan ser procesadas de forma as&iacute;ncrona por un determinado consumer kafka.&nbsp;</p> */
public class EventMantenimientoDpmn {
	
	@Inject private KafkaProducerDpmn kafkaProdDpmn;
	
	@Inject private KafkaProducerDamSeriesDpmn kafkaProdDamSeriesDpmn;
	
	@Inject private RegistroDpmnService registroDpmnService;
	
	
   /** <p>Permite inciar un evento relacionado al proceso de grabado de informaci&oacute;n de la DPMN</p>
    * 
    * @author rcontreras
    * @param dpmn Informaci&oacute;n de la DPMN
    * @return
    * Un identificador para la DPMN que luego se va registrar 
 * @throws JsonProcessingException */
   public IdentificadorDPMN grabarDpmn(Dpmn dpmn) throws JsonProcessingException {
	   String codAduana = dpmn.getAduana().getCodDatacat();
	   Integer annio = dpmn.getAnnDpmn();
	   
	   IdentificadorDPMN  identificadorDPMN = this.registroDpmnService.generarIdentificador(codAduana, annio);
	   dpmn.setNumCorrelativo(identificadorDPMN.getCorrelativo());
	   dpmn.setNumDpmn(identificadorDPMN.getNumero());
	   
	   this.kafkaProdDpmn.enviarMsgGuardar(dpmn);
	   
      return identificadorDPMN;
   }
   
   /** <p>Permite inciar un evento relacionado al proceso de grabado de informaci&oacute;n de las series de la DAM vinculadas a la DPMN</p>
    * 
    * @author rcontreras
    * @param damSeriesDpmn Series de la declaraci&oacute;n vinculadas a la DPMN 
 * @throws JsonProcessingException */
   public void grabarSeriesDamDpmn(List<DamSerieDpmn> damSeriesDpmn) throws JsonProcessingException {
	   this.kafkaProdDamSeriesDpmn.enviarMsgGuardar(damSeriesDpmn);
   }

}