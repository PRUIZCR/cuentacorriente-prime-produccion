/***********************************************************************
 * Module:  RegistroDpmnRestService.java
 * Author:  rcontreras
 * Purpose: Defines the Class RegistroDpmnRestService
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.ws.rest;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.container.AsyncResponse;
import javax.ws.rs.container.CompletionCallback;
import javax.ws.rs.container.Suspended;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.bean.CheckDpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.bean.CorreoRegistroDpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.bean.IdentificadorDPMN;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.domain.DamSerieDpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.domain.Dpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.services.EventMantenimientoDpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.services.FichaResumenDpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.services.NotificacionRegistroDpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.services.RegistroDpmnService;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.util.Constantes;
import pe.gob.sunat.tecnologiams.arquitectura.framework.microservices.model.bean.MensajeBean;
import pe.gob.sunat.tecnologiams.arquitectura.framework.microservices.util.ConstantesUtils;
import pe.gob.sunat.tecnologiams.arquitectura.framework.microservices.util.UtilLog;

@Path("/v1/controladuanero/prevencion/cuentacorrienteimpo")
public class RegistroDpmnRestService {
   @Inject private UtilLog utilLog;
   
   @Inject private EventMantenimientoDpmn evtMantenimientoDpmn;
   @Inject private NotificacionRegistroDpmn notiregistroDpmn;
   @Inject private RegistroDpmnService registroDpmnService;
   @Inject private FichaResumenDpmn fichaResumen;
   
   private static final String UTF_8 = "utf-8";
   
    @POST
	@Path("/t/dpmn/grabar")
	@Consumes({ MediaType.APPLICATION_JSON })
	@Produces({ MediaType.APPLICATION_JSON })
   public Response grabarDpmn(Dpmn dpmn) {
    
    	List<MensajeBean> lstMensajesValidacion = new java.util.ArrayList<>();
    	
	    try {
	    	IdentificadorDPMN identificador = this.evtMantenimientoDpmn.grabarDpmn(dpmn);
	    	return Response.ok(identificador).build();
	    } catch( java.lang.Exception ex ) {
	    	String msgError = "Ha ocurrido un error al registrar la DPMN";
	    	
	    	this.utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, msgError, ex.getStackTrace());
	    	MensajeBean mensaje = new MensajeBean();
			mensaje.setCod(1);
			mensaje.setMsg(msgError);
			
			lstMensajesValidacion.clear();
			lstMensajesValidacion.add(mensaje);		
			
				return Response.status(Constantes.COD_ESTADO_HTTP_ERROR_VALIDACION).entity(lstMensajesValidacion)
						.type(MediaType.APPLICATION_JSON_TYPE.withCharset(UTF_8)).build();
	    }
    
   }
    
    /**
     * <p>Verifica si la informaci&oacute;n de la DPMN se ha terminado de registrar</p>
     * @author rcontreras
     * @param chkDpmn Informaci&oacute;n de la DPMN a verificar
     * @param asyncResponse Respuesta as&iacute;ncrona
     */
    @POST
	@Path("/t/dpmn/verificargrabacion")
	@Consumes({ MediaType.APPLICATION_JSON })
	@Produces({ MediaType.APPLICATION_JSON })
    public void verificarGrabacion(CheckDpmn chkDpmn, @Suspended final AsyncResponse asyncResponse) {
    	
    	asyncResponse.setTimeout(30, TimeUnit.SECONDS);
    	
    	Timer timer = new Timer();
    	int begin = 0;
    	int timeInterval = 1000;
    	
    	final RegistroDpmnService refRegDpmnServ =  this.registroDpmnService;
    	
    	timer.schedule(new TimerTask() {
    	  int intento = 0;
    	  static final int  MAX_INTENTOS = 20;
    	  
    	   @Override
    	   public void run() {
    		   try {

        	       intento++;
        	       
        	       boolean seTerminoDeRegistrar = refRegDpmnServ.seTerminoDeRegistrar(chkDpmn);
        	       
        	       if ( seTerminoDeRegistrar ) {
        	    	   Response jaxrs = Response.ok(true).build();
        	           asyncResponse.resume(jaxrs);
        	       }        	       
        	       
        	       if ( intento >= MAX_INTENTOS ) {
        	    	   List<MensajeBean> lstMsgError = new java.util.ArrayList<>();    		
        	    	   MensajeBean mensaje = new MensajeBean();
        	    	   mensaje.setCod(1);
        	    	   mensaje.setMsg("Info de la DPMN aun no termina de registrarse");
        	    	   lstMsgError.add(mensaje);
        	           asyncResponse.resume(Response.status(Constantes.COD_ESTADO_HTTP_ERROR_VALIDACION).entity(lstMsgError).build());
        	       }
    			   
    		   } catch( java.lang.Exception ex ) {
    			   asyncResponse.resume(ex);
    		   }
    	   }
    	}, begin, timeInterval);
    	
    	asyncResponse.setTimeoutHandler(response -> {
    		List<MensajeBean> lstMsgError = new java.util.ArrayList<>();    		
    		MensajeBean mensaje = new MensajeBean();
			mensaje.setCod(1);
			mensaje.setMsg("TIMEOUT Alcanzado");
			lstMsgError.add(mensaje);
    		response.resume(Response.status(Constantes.COD_ESTADO_HTTP_ERROR_VALIDACION).entity(lstMsgError).build());
    	});
    	
    	CompletionCallback completionCallBack = (Throwable throwable) -> timer.cancel();
    	asyncResponse.register(completionCallBack);
   }
    
    @POST
	@Path("/t/damseriesdpmn/grabar")
	@Consumes({ MediaType.APPLICATION_JSON })
	@Produces({ MediaType.APPLICATION_JSON })
   public Response grabarDamSeriesDpm(List<DamSerieDpmn> damSerieDpmn) {
    	
    	List<MensajeBean> lstMensajesValidacion = new java.util.ArrayList<>();
    	
    	try {
    		this.evtMantenimientoDpmn.grabarSeriesDamDpmn(damSerieDpmn);
    		return Response.ok(true).build();
    	} catch( java.lang.Exception ex ) {
    		String msgError = "Ha ocurrido un error al registrar las series de la DAM vinculadas a la DPMN";
	    	
	    	this.utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, msgError, ex.getStackTrace());
	    	MensajeBean mensaje = new MensajeBean();
			mensaje.setCod(1);
			mensaje.setMsg(msgError);
			
			lstMensajesValidacion.clear();
			lstMensajesValidacion.add(mensaje);
			
				return Response.status(Constantes.COD_ESTADO_HTTP_ERROR_VALIDACION).entity(lstMensajesValidacion)
						.type(MediaType.APPLICATION_JSON_TYPE.withCharset(UTF_8)).build();
    	}
   }
    
    //pruebas para grabar aviso
    @POST
	@Path("/t/notificacionTransportista/grabar")
	@Consumes({ MediaType.APPLICATION_JSON })
	@Produces({ MediaType.APPLICATION_JSON })
   public Response grabarNotificacionTranspotista(CorreoRegistroDpmn correoRegistroDpmn) {
    	
    	List<MensajeBean> lstMensajesValidacion = new java.util.ArrayList<>();
    
    	try {
    		this.notiregistroDpmn.notificarTransportista(correoRegistroDpmn);
    		return Response.ok(true).build();
    	} catch( java.lang.Exception ex ) {
    		String msgError = "Ha ocurrido un error al registrar la notificacion al transportista de la DPMN";
	    	
	    	this.utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, msgError, ex.getStackTrace());
	    	MensajeBean mensaje = new MensajeBean();
			mensaje.setCod(1);
			mensaje.setMsg(msgError);
			
			lstMensajesValidacion.clear();
			lstMensajesValidacion.add(mensaje);
			
				return Response.status(Constantes.COD_ESTADO_HTTP_ERROR_VALIDACION).entity(lstMensajesValidacion)
						.type(MediaType.APPLICATION_JSON_TYPE.withCharset(UTF_8)).build();
    	}
   }
    
    @POST
  	@Path("/t/notificacionImportador/grabar")
  	@Consumes({ MediaType.APPLICATION_JSON })
  	@Produces({ MediaType.APPLICATION_JSON })
    public Response grabarNotificacionImportador(Dpmn dpmn) {
      	
      	List<MensajeBean> lstMensajesValidacion = new java.util.ArrayList<>();
      	
      	try {
      		this.registroDpmnService.grabarNotificacionImportador(dpmn);
      		return Response.ok(true).build();
      	} catch( java.lang.Exception ex ) {
      		String msgError = "Ha ocurrido un error al registrar la notificacion al transportista de la DPMN";
  	    	
  	    	this.utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, msgError, ex.getStackTrace());
  	    	MensajeBean mensaje = new MensajeBean();
  			mensaje.setCod(1);
  			mensaje.setMsg(msgError);
  			
  			lstMensajesValidacion.clear();
  			lstMensajesValidacion.add(mensaje);
  			
  				return Response.status(Constantes.COD_ESTADO_HTTP_ERROR_VALIDACION).entity(lstMensajesValidacion)
  						.type(MediaType.APPLICATION_JSON_TYPE.withCharset(UTF_8)).build();
      	}
     }
    
    /**
     * Genera una ficha PDF con la info de la DPMN y su codigo QR
     * @author rcontreras
     * @param correlativoDpmn Correlativo de la DPMN
     * @return 
     * Ficha resumen de la DPMN con su codigo QR
     */
    @GET
    @Path("/e/dpmns/{numCorrelativo}/ficharesumenqr")
    @Produces({ MediaType.APPLICATION_OCTET_STREAM })
    public Response obtenerFichaResumenQR(@PathParam("numCorrelativo") Long correlativoDpmn) {
    	
    	try {
    		
    		byte[] reportePdfFichaResumen = this.fichaResumen.generarFichaResumenQR(correlativoDpmn);
    		
    		boolean noHayData = reportePdfFichaResumen == null || reportePdfFichaResumen.length <= 0;
    		
    		if ( noHayData ) {    			
    			MensajeBean msjBean = new MensajeBean();    		
    			msjBean.setCod(1);
    			msjBean.setMsg("No hay ficha codigo QR para la DPMN");
    			
    			List<MensajeBean> lstMsgErrorBean = new java.util.ArrayList<>();
    			lstMsgErrorBean.add(msjBean);
    			
    			return Response.status(Constantes.COD_ESTADO_HTTP_ERROR_VALIDACION).entity(lstMsgErrorBean)
    					.type(MediaType.APPLICATION_JSON_TYPE.withCharset(UTF_8)).build();
    		}
    		
    		InputStream inputStream = new ByteArrayInputStream(reportePdfFichaResumen);
    		
    		return Response.ok(inputStream, MediaType.APPLICATION_OCTET_STREAM)
					.header("Content-Disposition", "attachment; filename=\"" + "reporteDpmns.pdf" + "\"").build();
    		
    	} catch( java.lang.Exception ex ) {
    		String mmsgError = "Error al generar la ficha codigo QR de la DPMN";
    		utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, mmsgError, ex.getStackTrace());
    		
    		MensajeBean msjBean = new MensajeBean();    		
			msjBean.setCod(1);
			msjBean.setMsg(mmsgError);
			
			List<MensajeBean> lstMsgErrorBean = new java.util.ArrayList<>();
			lstMsgErrorBean.add(msjBean);

			return Response.status(Constantes.COD_ESTADO_HTTP_ERROR_VALIDACION).entity(lstMsgErrorBean)
					.type(MediaType.APPLICATION_JSON_TYPE.withCharset(UTF_8)).build();
    	}
    	
    }
    
    
    
    
    
}