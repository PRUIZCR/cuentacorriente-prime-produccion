/***********************************************************************
 * Module:  DpmnMongoDBImpl.java
 * Author:  rcontreras
 * Purpose: Defines the Class DpmnMongoDBImpl
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.repository.mongodb;

import java.util.Calendar;
import java.util.Date;

import org.bson.Document;

import com.mongodb.BasicDBObject;
import com.mongodb.client.MongoCollection;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.bean.CheckDpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.domain.AdjuntoDpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.domain.CartaPorte;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.domain.ComprobantePago;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.domain.DamSerieDpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.domain.Dpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.domain.GuiaRemision;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.repository.DpmnRepository;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.util.TxDpmnUtils;
import pe.gob.sunat.tecnologia.arquitectura.framework.mongodb.client.MongoDBClient;


public class DpmnMongoDBImpl implements DpmnRepository {
	private static final String DPMNS = "dpmns";
	private static final String DAMSERIEDPMNS = "damSeriesDpmn";
	private static final String ADJUNTOSDPMN = "adjuntosDpmn";
	private static final String DS_ESCRITURA = "dgctecorrienteimpo";
	/**
	 * {@inheritDoc}
	 * 
	 */
	@Override
	public void grabar(Dpmn dpmn){
		//1. Grabar el objeto dpmn en la colecci�n "dpmns"
		Calendar cal2 = Calendar.getInstance();
	    long ms = cal2.getTimeInMillis();
	    Date sqlDate = new Date(ms);
	    dpmn.setFecDpmn(sqlDate);
		dpmn.getAuditoria().setFecRegis(sqlDate);
		dpmn.getAuditoria().setFecModif(sqlDate);
	
		MongoCollection<Dpmn> colleccion = MongoDBClient.getCollection(DS_ESCRITURA,DPMNS,Dpmn.class);
		colleccion.insertOne(dpmn);
	}
	
	@Override
	public boolean seTerminoDeRegistrar(CheckDpmn chkDpmn) {
		MongoCollection<Dpmn> colectDpmn = MongoDBClient.getCollection(DS_ESCRITURA, DPMNS, Dpmn.class);
		
		long numDpmn = colectDpmn.countDocuments(new Document("numCorrelativo", chkDpmn.getCorrelativoDpmn()));
		
		boolean noHayDpmn = numDpmn <= 0;
		
		if ( noHayDpmn ) {
			return false;
		}
		
		MongoCollection<DamSerieDpmn> colectDamSeriesDpmn = MongoDBClient.getCollection(DS_ESCRITURA, DAMSERIEDPMNS, DamSerieDpmn.class);		
		long numDamSeriesDpmn = colectDamSeriesDpmn.countDocuments(new Document("numCorreDpmn", chkDpmn.getCorrelativoDpmn()));
		
		if ( numDamSeriesDpmn != chkDpmn.getCntSeriesDcl().longValue() ) {
			return false;
		}
		
		MongoCollection<AdjuntoDpmn> colectAdjuntosDpmn = MongoDBClient.getCollection(DS_ESCRITURA, ADJUNTOSDPMN, AdjuntoDpmn.class);
		long numAdjuntosDpmn = colectAdjuntosDpmn.countDocuments(new Document("numCorrelativoDpmn", chkDpmn.getCorrelativoDpmn()));
		
		return numAdjuntosDpmn == chkDpmn.getCntArchivosAdjuntos().longValue();
	}

	/**
	 * @author rcontreras
	 * {@inheritDoc}
	 */
	@Override
	public Dpmn buscar(Long correlativoDpmn) {
		
		MongoCollection<Dpmn> colectDpmn = MongoDBClient.getCollection(DS_ESCRITURA, DPMNS, Dpmn.class);
		Dpmn dpmn = colectDpmn.find(new Document("numCorrelativo", correlativoDpmn)).first();		
		
		MongoCollection<BasicDBObject> documento = MongoDBClient.getCollection(DS_ESCRITURA, DPMNS, BasicDBObject.class);
		
		BasicDBObject document =  documento.find(new Document("numCorrelativo", correlativoDpmn)).first();
		
		java.util.List<ComprobantePago> lstUpdateComp = new java.util.ArrayList<>();
		
		dpmn.getComprobantePago().forEach( itComPago -> {
			String codTipoComp = itComPago.getTipoComprobante().getCodDatacat();
			
			BasicDBObject basicDBObject = this.buscarObjComPago(itComPago, document);
			
			if ( codTipoComp.equals("01") ) {
				GuiaRemision gr = new GuiaRemision();
				
				TxDpmnUtils.copyPropsComproPago(itComPago, gr);
				
				String numSerie = basicDBObject.getString("numSerie");
				String numGuia = basicDBObject.getString("numGuia");
				String numRucRemitente = basicDBObject.getString("numRucRemitente");
				String desRazonSocialRemitente = basicDBObject.getString("desRazonSocialRemitente");
				
				gr.setNumSerie(numSerie);
				gr.setNumGuia(numGuia);
				gr.setNumRucRemitente(numRucRemitente);
				gr.setDesRazonSocialRemitente(desRazonSocialRemitente);
				
				lstUpdateComp.add(gr);
				
			} else if ( codTipoComp.equals("02") ) {
				CartaPorte cp = new CartaPorte();
				
				TxDpmnUtils.copyPropsComproPago(itComPago, cp);
				
				String numCartaPorte = basicDBObject.getString("numCartaPorte");
				String nomEmpresa = basicDBObject.getString("nomEmpresa");
				
				cp.setNumCartaPorte(numCartaPorte);
				cp.setNomEmpresa(nomEmpresa);
				
				lstUpdateComp.add(cp);
			} else {
				lstUpdateComp.add(itComPago);
			}
			
		});
		
		
		dpmn.setComprobantePago(lstUpdateComp);
		
		return dpmn;
	}
	
	@SuppressWarnings("unchecked")
	private BasicDBObject buscarObjComPago(ComprobantePago itComPago, BasicDBObject document) {
		java.util.List<BasicDBObject> lstBdoComprPago =  (java.util.List<BasicDBObject>)document.get("comprobantePago");
		return lstBdoComprPago.stream().filter(itBdoComPago -> 
			itBdoComPago.getLong("numCorrelativo") == itComPago.getNumCorrelativo()
		).findFirst().orElse(null);		
	}
}