/***********************************************************************
 * Module:  TransaccionDpmnConfig.java
 * Author:  rcontreras
 * Purpose: Defines the Class TransaccionDpmnConfig
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.main.config;

import pe.gob.sunat.tecnologia.arquitectura.framework.mongodb.config.MongoDBConfig;
import pe.gob.sunat.tecnologia3.arquitectura.framework.kafka.config.KafkaConsumerConfig;
import pe.gob.sunat.tecnologia3.arquitectura.framework.kafka.config.KafkaProducerConfig;
import pe.gob.sunat.tecnologiams.arquitectura.framework.microservices.config.MicroserviceConfig;

public class TransaccionDpmnConfig extends MicroserviceConfig {
	
   private static TransaccionDpmnConfig config;
   private MongoDBConfig mongodb;
   
   private KafkaProducerConfig cfgKafkaProducerDpmn;
   private KafkaProducerConfig cfgKafkaProducerDamSeriesDpmn;
   
   private KafkaConsumerConfig cfgKafkaConsumerDpmn;
   private KafkaConsumerConfig cfgKafkaConsumerDamSeriesDpmn;
   
   
	public static TransaccionDpmnConfig getConfig() {
		return config;
	}
	
	public static void  loadConfig(TransaccionDpmnConfig newInstance) {
		TransaccionDpmnConfig.config = newInstance;
	}
	
	public MongoDBConfig getMongodb() {
		return mongodb;
	}
	
	public void setMongodb(MongoDBConfig mongodb) {
		this.mongodb = mongodb;
	}

	public KafkaProducerConfig getCfgKafkaProducerDpmn() {
		return cfgKafkaProducerDpmn;
	}

	public void setCfgKafkaProducerDpmn(KafkaProducerConfig cfgKafkaProducerDpmn) {
		this.cfgKafkaProducerDpmn = cfgKafkaProducerDpmn;
	}

	public KafkaProducerConfig getCfgKafkaProducerDamSeriesDpmn() {
		return cfgKafkaProducerDamSeriesDpmn;
	}

	public void setCfgKafkaProducerDamSeriesDpmn(KafkaProducerConfig cfgKafkaProducerDamSeriesDpmn) {
		this.cfgKafkaProducerDamSeriesDpmn = cfgKafkaProducerDamSeriesDpmn;
	}

	public KafkaConsumerConfig getCfgKafkaConsumerDpmn() {
		return cfgKafkaConsumerDpmn;
	}

	public void setCfgKafkaConsumerDpmn(KafkaConsumerConfig cfgKafkaConsumerDpmn) {
		this.cfgKafkaConsumerDpmn = cfgKafkaConsumerDpmn;
	}

	public KafkaConsumerConfig getCfgKafkaConsumerDamSeriesDpmn() {
		return cfgKafkaConsumerDamSeriesDpmn;
	}

	public void setCfgKafkaConsumerDamSeriesDpmn(KafkaConsumerConfig cfgKafkaConsumerDamSeriesDpmn) {
		this.cfgKafkaConsumerDamSeriesDpmn = cfgKafkaConsumerDamSeriesDpmn;
	}
	
}