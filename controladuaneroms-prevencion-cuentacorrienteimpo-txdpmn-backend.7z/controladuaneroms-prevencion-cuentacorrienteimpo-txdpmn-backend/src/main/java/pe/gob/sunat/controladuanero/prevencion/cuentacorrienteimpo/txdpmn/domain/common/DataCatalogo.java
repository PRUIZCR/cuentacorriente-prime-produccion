/***********************************************************************
 * Module:  DataCatalogo.java
 * Author:  rcontreras
 * Purpose: Defines the Class DataCatalogo
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.domain.common;

public class DataCatalogo implements java.io.Serializable {
   /**
	 * 
	 */
	private static final long serialVersionUID = 7427462226640113004L;
	private String codDatacat;
   private String desDataCat;
   
   public String getCodDatacat() {
      return codDatacat;
   }
   
   /** @param newCodDatacat */
   public void setCodDatacat(String newCodDatacat) {
      codDatacat = newCodDatacat;
   }
   
   public String getDesDataCat() {
      return desDataCat;
   }
   
   /** @param newDesDataCat */
   public void setDesDataCat(String newDesDataCat) {
      desDataCat = newDesDataCat;
   }

}