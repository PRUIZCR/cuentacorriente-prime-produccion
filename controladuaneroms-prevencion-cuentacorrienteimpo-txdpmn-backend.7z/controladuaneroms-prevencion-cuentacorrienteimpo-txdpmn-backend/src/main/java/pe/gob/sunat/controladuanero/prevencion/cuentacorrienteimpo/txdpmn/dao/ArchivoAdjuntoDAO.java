/***********************************************************************
 * Module:  ArchivoAdjuntoDAO.java
 * Author:  msancheza
 * Purpose: Defines the Interface ArchivoAdjuntoDAO
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.dao;
import java.util.Map;


public interface ArchivoAdjuntoDAO {
	public void insert(Map datos);

}