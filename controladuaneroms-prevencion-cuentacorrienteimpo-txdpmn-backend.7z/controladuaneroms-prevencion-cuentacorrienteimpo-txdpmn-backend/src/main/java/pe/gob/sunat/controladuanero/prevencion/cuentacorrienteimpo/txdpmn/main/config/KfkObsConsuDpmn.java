/***********************************************************************
 * Module:  KafkaObsv.java
 * Author:  rcontreras
 * Purpose: Defines the Class KafkaObsv
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.main.config;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.kafka.consumer.KafkaConsumerDpmn;
import pe.gob.sunat.tecnologia3.arquitectura.framework.kafka.Consumer;

public class KfkObsConsuDpmn {
	
	public KfkObsConsuDpmn() {
        Consumer obsConsumerDpmn = new Consumer(TransaccionDpmnConfig.getConfig().getCfgKafkaConsumerDpmn());
        KafkaConsumerDpmn kafkaConsumerDpmn = new KafkaConsumerDpmn(obsConsumerDpmn);
        obsConsumerDpmn.addObserver(kafkaConsumerDpmn);
        obsConsumerDpmn.subscribe();
    }
	
}