/***********************************************************************
 * Module:  Ubigeo.java
 * Author:  rcontreras
 * Purpose: Defines the Class Ubigeo
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.domain.common;

public class Ubigeo implements java.io.Serializable {
   /**
	 * 
	 */
	private static final long serialVersionUID = 8023818582889341673L;
	private String codUbigeo;
   private String nomDepartamento;
   private String nomProvincia;
   private String nomDistrito;
   
   public String getCodUbigeo() {
      return codUbigeo;
   }
   
   /** @param newCodUbigeo */
   public void setCodUbigeo(String newCodUbigeo) {
      codUbigeo = newCodUbigeo;
   }
   
   public String getNomDepartamento() {
      return nomDepartamento;
   }
   
   /** @param newNomDepartamento */
   public void setNomDepartamento(String newNomDepartamento) {
      nomDepartamento = newNomDepartamento;
   }
   
   public String getNomProvincia() {
      return nomProvincia;
   }
   
   /** @param newNomProvincia */
   public void setNomProvincia(String newNomProvincia) {
      nomProvincia = newNomProvincia;
   }
   
   public String getNomDistrito() {
      return nomDistrito;
   }
   
   /** @param newNomDistrito */
   public void setNomDistrito(String newNomDistrito) {
      nomDistrito = newNomDistrito;
   }

}