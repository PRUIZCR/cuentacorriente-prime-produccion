/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.services;
import java.io.InputStream;
import java.util.List;
import java.util.Map;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager ;
import net.sf.jasperreports.engine.JasperPrint ;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.util.TransaccionDpmnException;

/**
Representa a un reporte del sistema

@author Roger A. Contreras Corrales
 */
public class ReporteJasper {
    
   /**
   Contiene los parametros del reporte y sus valores
    */
private Map<String, Object> parametros;
   /**
   Datos que se envian para ser visualizados
    */
private List<?> datos;

private JRDataSource dataSource;

   /**
   Ruta del archivo de reporte compilado (Archivo con extension jasper)
    */
private InputStream archivoReporte;

    
    public ReporteJasper( Map<String, Object> misParametros, List<?> misDatos, String nombreReporte ) throws TransaccionDpmnException {
        
            this.parametros = misParametros;
            this.datos = misDatos;
            
            if (this.datos.isEmpty()) {
                throw new TransaccionDpmnException("No hay datos que imprimir");
            }            
            
            if ( nombreReporte == null || nombreReporte.trim().length() <= 0 ) {
                throw new TransaccionDpmnException("Falta especificar el nombre del reporte");
            }
            
            this.archivoReporte = this.getClass().getResourceAsStream("/reportes/" + nombreReporte.trim());
            
            this.dataSource = new JRBeanCollectionDataSource(this.datos);
    }
    
    
    /**
   	Permite obtener una vista del reporte antes de ser impresa
     * @throws TransaccionDpmnException 
    */
    public byte[] generarReportePDF() throws TransaccionDpmnException {            
        try {
        	JasperPrint jasperPrint = JasperFillManager.fillReport(this.archivoReporte, this.parametros, this.dataSource);
        	this.archivoReporte.close();
        	return JasperExportManager.exportReportToPdf(jasperPrint);
        } catch (Exception ex) {
        	throw new TransaccionDpmnException(ex);
        }
    }
}