/***********************************************************************
 * Module:  GuiaRemision.java
 * Author:  rcontreras
 * Purpose: Defines the Class GuiaRemision
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.domain;

public class GuiaRemision extends ComprobantePago implements java.io.Serializable {
   /**
	 * 
	 */
	private static final long serialVersionUID = -2263664013219849325L;
	private String numSerie;
   private String numGuia;
   private String numRucRemitente;
   private String desRazonSocialRemitente;
   
   public String getNumSerie() {
      return numSerie;
   }
   
   /** @param newNumSerie */
   public void setNumSerie(String newNumSerie) {
      numSerie = newNumSerie;
   }
   
   public String getNumGuia() {
      return numGuia;
   }
   
   /** @param newNumGuia */
   public void setNumGuia(String newNumGuia) {
      numGuia = newNumGuia;
   }
   
   public String getNumRucRemitente() {
      return numRucRemitente;
   }
   
   /** @param newNumRucRemitente */
   public void setNumRucRemitente(String newNumRucRemitente) {
      numRucRemitente = newNumRucRemitente;
   }
   
   public String getDesRazonSocialRemitente() {
      return desRazonSocialRemitente;
   }
   
   /** @param newDesRazonSocialRemitente */
   public void setDesRazonSocialRemitente(String newDesRazonSocialRemitente) {
      desRazonSocialRemitente = newDesRazonSocialRemitente;
   }

}