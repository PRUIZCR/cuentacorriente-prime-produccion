/***********************************************************************
 * Module:  SecuenciaMongoDBImpl.java
 * Author:  rcontreras
 * Purpose: Defines the Class SecuenciaMongoDBImpl
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.repository.mongodb;


import pe.gob.sunat.tecnologia.arquitectura.framework.mongodb.client.MongoDBClient;


import java.math.BigDecimal;

import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.mongodb.client.MongoCollection;



public class SecuenciaMongoDBImpl implements pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.repository.SecuenciaRepository {
	private static final String SECUENCIA = "secuencias";
	private static final String DS_ESCRITURA= "dgctecorrienteimpo";
	private static final String DS_LECTURA= "dcctecorrienteimpo";
	
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public Integer getNexValue(String nomSecuencia) {
		//	getNextSequenceValue(sequenceName)
		MongoCollection<DBObject> colleccion = MongoDBClient.getCollection(DS_ESCRITURA, SECUENCIA, DBObject.class);
		  BasicDBObject find = new BasicDBObject();
		 find.put("_id", nomSecuencia);
		 BasicDBObject update = new BasicDBObject();
		 update.put("$inc", new BasicDBObject("sequence_value", 1));
		 DBObject obj =  colleccion.findOneAndUpdate(find, update);
		 String valor1= obj.get("sequence_value").toString();
		// String string1 = Double.valueOf(valor1+1).toString();
		 BigDecimal number = (new BigDecimal(valor1));  
		// number.stripTrailingZeros().toPlainString();
		 return Integer.valueOf(number.stripTrailingZeros().toPlainString())+1;
		 //return getRandomNumber();
	}
	
	public static int getRandomNumber(){
	   int numero = (int)(Math.random()*10+1);
	    return numero;
	}
}//