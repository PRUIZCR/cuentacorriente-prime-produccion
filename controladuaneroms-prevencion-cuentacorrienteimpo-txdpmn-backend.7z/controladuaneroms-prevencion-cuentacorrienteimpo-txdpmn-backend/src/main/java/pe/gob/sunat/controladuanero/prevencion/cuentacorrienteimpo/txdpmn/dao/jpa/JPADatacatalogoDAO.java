package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.dao.jpa;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.dao.DatacatalogoDAO;

import pe.gob.sunat.tecnologiams.arquitectura.framework.common.util.ConstantesUtils;
import pe.gob.sunat.tecnologiams.arquitectura.framework.microservices.util.UtilLog;

public class JPADatacatalogoDAO  implements DatacatalogoDAO {

	@Inject
	private UtilLog utilLog;
	
	@Inject
	@Named("dcbdsigad")
	protected EntityManager dcbdsigad;

	private Query query;

	@Override
	public String obtenerDataCatalogoAsoc(String codAsoccat, String codDatacat) {
	
        
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT DISTINCT D.COD_DATACATASOC ").
        append(" FROM DATACATASOC D, DATACATALOGO C").
        append(" WHERE D.COD_ASOCCAT = ? ").
        append(" AND D.COD_ESTADO IN ('01', '02') ").
        append(" AND C.COD_ESTADO IN ('01', '02') ").
        append(" AND D.IND_REGACTUAL = '1' ").
        append(" AND C.IND_REGACTUAL = '1' ").
        append(" AND D.COD_DATACAT = ? ").
        append(" AND D.COD_CATALOGOASOC = C.COD_CATALOGO ").
        append(" AND D.COD_DATACATASOC = C.COD_DATACAT ").
		append(" AND SYSDATE BETWEEN D.FEC_INIASOC AND D.FEC_FINASOC ").
        append(" AND SYSDATE BETWEEN C.FEC_INIDATCAT AND C.FEC_FINDATCAT ");
		
		String resultado = "";
		
		try {
			query = dcbdsigad.createNativeQuery(sql.toString());
			query.setParameter(1, codAsoccat);
			query.setParameter(2, codDatacat);

			
			resultado = query.getSingleResult().toString();

		} catch( java.lang.Exception ex ) {
			utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, ex.getMessage());
			ex.getMessage();
		}
		
		return resultado;
 
	}

}
