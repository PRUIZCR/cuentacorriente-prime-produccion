/***********************************************************************
 * Module:  RegistroDpmnServiceImpl.java
 * Author:  rcontreras
 * Purpose: Defines the Class RegistroDpmnServiceImpl
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.services;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import com.mongodb.BasicDBObject;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.bean.CheckDpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.bean.CorreoRegistroDpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.bean.CorreoRegistroDpmn.Destinatario;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.bean.IdentificadorDPMN;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.domain.CartaPorte;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.domain.DamSerieDpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.domain.Dpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.domain.GuiaRemision;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.repository.DamSerieDpmnRepository;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.repository.DpmnRepository;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.repository.SecuenciaRepository;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.util.TxDpmnUtils;
import pe.gob.sunat.tecnologiams.arquitectura.framework.microservices.model.bean.MensajeBean;
import pe.gob.sunat.tecnologiams.arquitectura.framework.microservices.util.ConstantesUtils;
import pe.gob.sunat.tecnologiams.arquitectura.framework.microservices.util.UtilLog;

public class RegistroDpmnServiceImpl implements RegistroDpmnService {
	@Inject
	private DpmnRepository dpmnRepository;
	@Inject 
	private SecuenciaRepository secuenciaRepository;
	@Inject private NotificacionRegistroDpmn notiregistroDpmn;
	@Inject private DamSerieDpmnRepository damSerieDpmnRepository;
	@Inject private UtilLog utilLog;
	public static String TIPO_CONTACTO_EXTERNO = "2";
	
	@Override
	public void grabar(Dpmn dpmn) {
		this.dpmnRepository.grabar(dpmn);
		this.grabarNotificacionTransp(dpmn);
		//Para Notificaci�n a Transportista
		this.grabarNotificacionImportador(dpmn);
		return;
	}

	@Override
	public List<MensajeBean> validarGrabacion(Dpmn dpmn) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public IdentificadorDPMN generarIdentificador(String codAduana, Integer annio) {
		//1. Definir el siguiente objeto: 
			
		IdentificadorDPMN identificador = new IdentificadorDPMN();

		//2. Setear las siguientes propiedades: 
		identificador.setCodAduana(codAduana);
		identificador.setAnio(annio);			
		//3. Obtener el correlativo de la DPMN: 			
		//identificador.setCorrelativo(Long.valueOf(this.secuenciaRepository.getNexValue("SENUMCORREDOC")));	
		identificador.setCorrelativo(Long.valueOf(this.secuenciaRepository.getNexValue("SENUMCORREDOC")));	
		//4. Definir el nombre de la secuencia que dar� el n�mero de la DPMN:			
		String secuenciaDMPN =	 "SENUMDPMN" + codAduana + annio;			
		//4. Obtener el n�mero de la DPMN: 	
		identificador.setNumero(this.secuenciaRepository.getNexValue(secuenciaDMPN));	
		//5. Retornar: 
		return identificador;
	}
	
	private void grabarNotificacionTransp(Dpmn dpmn){
		try {
			//la invocaci�n a la notificaci�n
			if(dpmn.getNumCorrelativo()!=null && dpmn.getEmpresaTransporte()!=null && dpmn.getEmpresaTransporte().getValEmail()!=null) {
	    		java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
	    		
	    		CorreoRegistroDpmn correoRegistroDpmn = new CorreoRegistroDpmn();
	    		correoRegistroDpmn.setPuestoControl(dpmn.getPuestoControlDescarga().getCodDatacat()+"-"+dpmn.getPuestoControlDescarga().getDesDataCat());
	    		correoRegistroDpmn.setNumeroDpmn(TxDpmnUtils.getNumeroDpmn(dpmn));
	    		correoRegistroDpmn.setFechaDpmn(sdf.format(dpmn.getFecDpmn()));
	    		correoRegistroDpmn.setAduanaDescarga(this.obtenerAduanaDescarga(dpmn));
	    		Destinatario destino= new CorreoRegistroDpmn().new Destinatario();
	    		destino.setCorreo(dpmn.getEmpresaTransporte().getValEmail());
	    		destino.setNombre(dpmn.getEmpresaTransporte().getNomEmpresa());
	    		correoRegistroDpmn.setDestinatario(destino);
	    		correoRegistroDpmn.setCorrelativoDpmn(dpmn.getNumCorrelativo());
	    		this.notiregistroDpmn.notificarTransportista(correoRegistroDpmn);
			}
		} catch (Exception ex) {
			String msgError = "Ha ocurrido un error al registrar la notificacion al transportista de la DPMN";
  	    	
			this.utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, msgError, ex.getStackTrace());
		}
	}
	public void grabarNotificacionImportador(Dpmn dpmn){
		try {
			//conseguimos los datos del importador
			List<DamSerieDpmn> lstDamSeriesDpmn =damSerieDpmnRepository.buscar(dpmn.getNumCorrelativo(), false);
			lstDamSeriesDpmn.forEach( dpmndecla -> {
				 if(dpmndecla.getAduanaDam() != null && dpmndecla.getAduanaDam().getCodDatacat()!=null && dpmndecla.getAnnDam()!=null && dpmndecla.getRegimenDam()!=null && dpmndecla.getNumDam()!=null){
					Map<String, Object> mapResultado = new HashMap<String,Object>();
					   String url = "";
					   String numeroDAM = dpmndecla.getAduanaDam().getCodDatacat()+"-"+dpmndecla.getAnnDam()+"-"+dpmndecla.getRegimenDam().getCodDatacat()+"-"+dpmndecla.getNumDam();
					   
					   url = "http://api.sunat.peru/v1/controladuanero/ingreso/declaracion/e/declaracionesingreso/"+numeroDAM;
					   HashMap<String, Object> datos = (HashMap<String, Object>) TxDpmnUtils.consumirREST(url);
					
					   if(datos==null || datos.containsKey("cod")) {
							return;
					   }else {
						   if(datos!=null && datos.get("rucDuenoConsignatario")!=null){
			            	   //obtenemos nombre comercial
							   String urlRuc = "";
							   String rucImportador = datos.get("rucDuenoConsignatario").toString();
							   
							   urlRuc = "http://api.sunat.peru/v1/contribuyente/registro/e/contribuyentes/"+rucImportador;
							   HashMap<String, Object> datosRuc = (HashMap<String, Object>) TxDpmnUtils.consumirREST(urlRuc);
							   if(datosRuc==null || datosRuc.containsKey("cod")) {
									return;
							   }else {
								   java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
						    		String nombreRuc=datosRuc.get("ddpNombre").toString();
						    		CorreoRegistroDpmn correoRegistroDpmn = new CorreoRegistroDpmn();
						    		correoRegistroDpmn.setPuestoControl(dpmn.getPuestoControlDescarga().getCodDatacat()+"-"+dpmn.getPuestoControlDescarga().getDesDataCat());
						    		correoRegistroDpmn.setNumeroDpmn(TxDpmnUtils.getNumeroDpmn(dpmn));
						    		correoRegistroDpmn.setFechaDpmn(sdf.format(dpmn.getFecDpmn()));
						    		correoRegistroDpmn.setAduanaDescarga(this.obtenerAduanaDescarga(dpmn));
						    		Destinatario destino= new CorreoRegistroDpmn().new Destinatario();
						    		
						    		destino.setNombre(mapResultado.get("rucDuenoConsignatario")+"-"+nombreRuc);
						    		correoRegistroDpmn.setDestinatario(destino);
						    		correoRegistroDpmn.setCorrelativoDpmn(dpmn.getNumCorrelativo());
						    		this.notiregistroDpmn.notificarImportador(correoRegistroDpmn, rucImportador, dpmndecla.getAduanaDam().getCodDatacat()); 
							   }           	
			            	
						 }
					}
				 }
			
				
			});
			
		} catch (Exception ex) {
			String msgError = "Ha ocurrido un error al registrar la notificacion al importador de la DPMN";
  	    	
			this.utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, msgError, ex.getStackTrace());
		}
	}
	private String obtenerAduanaDescarga(Dpmn dpmn) {		
		StringBuilder sb = new StringBuilder();
		
		String codigo = TxDpmnUtils.obtenerValorPropiedad("aduanaDescarga.codDatacat", dpmn, String.class);
		String descripcion = TxDpmnUtils.obtenerValorPropiedad("aduanaDescarga.desDataCat", dpmn, String.class);
		
		if ( codigo != null ) {
			sb.append(codigo);
			sb.append("-");
		}
		
		sb.append(descripcion);
		
		return sb.toString();
	}

	@Override
	public boolean seTerminoDeRegistrar(CheckDpmn chkDpmn) {		
		boolean resultado = false;
		
		try {
			resultado = this.dpmnRepository.seTerminoDeRegistrar(chkDpmn);
		} catch ( java.lang.Exception ex ) {
			resultado = false;
			this.utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, ex.getMessage(), ex.getStackTrace());
		}
		
		return resultado;
	}
}