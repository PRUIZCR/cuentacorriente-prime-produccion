/***********************************************************************
 * Module:  RegistroDpmnService.java
 * Author:  rcontreras
 * Purpose: Defines the Interface RegistroDpmnService
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.services;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.bean.CheckDpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.bean.IdentificadorDPMN;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.domain.Dpmn;
import pe.gob.sunat.tecnologiams.arquitectura.framework.microservices.model.bean.MensajeBean;

import java.util.*;

public interface RegistroDpmnService {
   /** @param dpmn */
	void grabar(Dpmn dpmn);
   /** @param dpmn */
   List<MensajeBean> validarGrabacion(Dpmn dpmn);
   /** @param codAduana */
   IdentificadorDPMN generarIdentificador(String codAduana, Integer annio);
   
   boolean seTerminoDeRegistrar(CheckDpmn chkDpmn);
   void grabarNotificacionImportador(Dpmn dpmn);
   
}