/***********************************************************************
 * Module:  AdjuntoDpmn.java
 * Author:  rcontreras
 * Purpose: Defines the Class AdjuntoDpmn
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.domain;

import java.util.*;

public class AdjuntoDpmn implements java.io.Serializable {
   /**
	 * 
	 */
	private static final long serialVersionUID = -8318457716655201953L;
	private String codArchivoEcm;
   private Long numCorrelativoDpmn;
   private String codTipoDocumento;
   private String desTipoDocumento;
   private String nomArchivo;
   private String nomContentType;
   private Date fecRegistro;
   private boolean indEliminado;
   
   public String getCodArchivoEcm() {
      return codArchivoEcm;
   }
   
   /** @param newCodArchivoEcm */
   public void setCodArchivoEcm(String newCodArchivoEcm) {
      codArchivoEcm = newCodArchivoEcm;
   }
   
   public Long getNumCorrelativoDpmn() {
      return numCorrelativoDpmn;
   }
   
   /** @param newNumCorrelativoDpmn */
   public void setNumCorrelativoDpmn(Long newNumCorrelativoDpmn) {
      numCorrelativoDpmn = newNumCorrelativoDpmn;
   }
   
   public String getCodTipoDocumento() {
      return codTipoDocumento;
   }
   
   /** @param newCodTipoDocumento */
   public void setCodTipoDocumento(String newCodTipoDocumento) {
      codTipoDocumento = newCodTipoDocumento;
   }
   
   public String getDesTipoDocumento() {
      return desTipoDocumento;
   }
   
   /** @param newDesTipoDocumento */
   public void setDesTipoDocumento(String newDesTipoDocumento) {
      desTipoDocumento = newDesTipoDocumento;
   }
   
   public String getNomArchivo() {
      return nomArchivo;
   }
   
   /** @param newNomArchivo */
   public void setNomArchivo(String newNomArchivo) {
      nomArchivo = newNomArchivo;
   }
   
   public String getNomContentType() {
      return nomContentType;
   }
   
   /** @param newNomContentType */
   public void setNomContentType(String newNomContentType) {
      nomContentType = newNomContentType;
   }
   
   public Date getFecRegistro() {
      return fecRegistro;
   }
   
   /** @param newFecRegistro */
   public void setFecRegistro(Date newFecRegistro) {
      fecRegistro = newFecRegistro;
   }
   
   public boolean getIndEliminado() {
      return indEliminado;
   }
   
   /** @param newIndEliminado */
   public void setIndEliminado(boolean newIndEliminado) {
      indEliminado = newIndEliminado;
   }

}