package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.util;

import org.apache.commons.beanutils.PropertyUtils;
import java.io.BufferedInputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.domain.ComprobantePago;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.domain.DamSerieDpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.domain.Dpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.domain.common.DataCatalogo;
import pe.gob.sunat.tecnologiams.arquitectura.framework.common.util.ConstantesUtils;
import pe.gob.sunat.tecnologiams.arquitectura.framework.microservices.util.UtilLog;

/**
 * <p>M&eacute;todos utilitarios referentes a 
 * obtenci&oacute;n de informaci&oacute;n de la DPMN</p>
 * @author rcontreras
 */
public class TxDpmnUtils {
	
	private static final String GUION = "-";
	private static UtilLog utilLog = new UtilLog();
	private TxDpmnUtils() {
	      throw new IllegalAccessError("No se puede instanciar clase util");
	}
	
	/**
	 * <p>Obtiene el n&uacute;mero de la DPMN en formato {aduana}-{anio}-{n&uacute;mero}</p>
	 * @author rcontreras
	 * @param dpmn DPMN
	 * @return
	 * N&uacute;mero de la DPMN
	 */
	public static String getNumeroDpmn(Dpmn dpmn) {
		
		if ( dpmn == null ) {
			return null;
		}
		
		java.lang.StringBuilder sb = new java.lang.StringBuilder();
		
		boolean hayAduana = dpmn.getAduana() != null;
		
		
		if ( hayAduana ) {
			sb.append(dpmn.getAduana().getCodDatacat());
			sb.append(GUION);
		}
		
		boolean hayAnio = dpmn.getAnnDpmn() != null;
		
		if ( hayAnio ) {
			sb.append(dpmn.getAnnDpmn());
			sb.append(GUION);
		}
		
		sb.append(dpmn.getNumDpmn());
		
		return sb.toString();
	}
	
	/**
	 * <p>Obtiene el n&uacute;mero de la DAM en formato {aduana}-{regimen}-{anio}-{n&uacute;mero}</p>
	 * @author rcontreras
	 * @param damSerieDpmn Serie de la DAM vinculada a la DPMN
	 * @return
	 * N&uacute;mero de la DPMN
	 */
	 public static String obtenerNumeroDam(DamSerieDpmn damSerieDpmn) {
		 java.lang.StringBuilder sb = new java.lang.StringBuilder();
		 
		 String codAduana = obtenerValorPropiedad("aduanaDam.codDatacat", damSerieDpmn, String.class);
		 String codRegimen = obtenerValorPropiedad("regimenDam.codDatacat", damSerieDpmn, String.class);
		 Integer anio = damSerieDpmn.getAnnDam();
		 Integer numero = damSerieDpmn.getNumDam();
		 
		 if ( codAduana != null ) {
			 sb.append(codAduana);
			 sb.append(GUION);
		 }
		 
		 if ( codRegimen != null ) {
			 sb.append(codRegimen);
			 sb.append(GUION);
		 }
		 
		 if ( anio != null ) {
			 sb.append(anio);
			 sb.append(GUION);
		 }		 
		 
		 sb.append(numero);
		 
		 return sb.toString();
	 }
	
	
	/**
	 * <p>Obtiene el c&oacute;digo junto con la descripci&oacute;n de un datacatalogo.&nbsp;</p>
	 * <p>El valor retornado ser&iacute;a en el formato {codigo}-{Descripci&oacute;n}</p>
	 * @author rcontreras
	 * @param dataCat Datacatalogo
	 * @return
	 * El c&oacute;digo junto con la descripci&oacute;n 
	 */
	public static String getCodDesCatalogo(DataCatalogo dataCat) {
		
		if ( dataCat == null ) {
			return null;
		}
		
		java.lang.StringBuilder sb = new java.lang.StringBuilder();		
		
		boolean hayCodigo = dataCat.getCodDatacat() != null; 
		
		if ( hayCodigo ) {
			sb.append(dataCat.getCodDatacat());
			sb.append(GUION);
		}
		
		sb.append(dataCat.getDesDataCat());
		
		return sb.toString();
	}
	
	public static String getFechaFormateada(java.util.Date fecha, String formato) {
		
		if ( fecha == null ) {
			return null;
		}
		
		java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat(formato);
		return sdf.format(fecha);
		
	}
	
	public static void copyPropsComproPago(ComprobantePago origen, ComprobantePago destino) {
		destino.setNumCorrelativo(origen.getNumCorrelativo());
		destino.setTipoComprobante(origen.getTipoComprobante());
		destino.setNumRucDestinatario(origen.getNumRucDestinatario());
		destino.setDesRazonSocialDestinatario(origen.getDesRazonSocialDestinatario());
		destino.setMotivoDeTraslado(origen.getMotivoDeTraslado());
		destino.setUbigeoDestino(origen.getUbigeoDestino());
		destino.setIndEliminado(origen.getIndEliminado());
		destino.setAuditoria(origen.getAuditoria());
	}
	
	/**
	 * Obtiene de un objeto el valor de una propiedad.
	 * @author rcontreras
	 * @param propiedad Nombre de la propiedad, puede ser una propiedad anidada
	 * @param objeto Objeto del cual se desea obtener el valor de la propiedad
	 * @return
	 * <ul>
	 * 	<li>Si existe la propiedad y no hay error, se obtiene su valor</li>
	 *  <li>Caso contrario, se retorna NULL</li>
	 * </ul>
	 */
	public static <T> T  obtenerValorPropiedad (String propiedad, Object objeto, Class<T> clase) {
		try {
			
			if ( clase == null ) {
				return null;
			}
			
			return clase.cast(PropertyUtils.getNestedProperty(objeto, propiedad));
		} catch ( java.lang.Exception ex ) {
			return null;
		}
	}
	@SuppressWarnings("deprecation")
	public static Object consumirREST(String urlREST) {

		DefaultHttpClient httpclient = new DefaultHttpClient();

		Object response = null;
		utilLog.imprimirLog(ConstantesUtils.LEVEL_INFO, "****iniciar consumirREST:" + urlREST + "****");
		try {
			HttpGet httpGetRequest = new HttpGet(urlREST);
			HttpResponse httpResponse = httpclient.execute(httpGetRequest);
			HttpEntity entity = httpResponse.getEntity();

			byte[] buffer = new byte[1024];
			if (entity != null) {
				InputStream inputStream = entity.getContent();

				try {
					int bytesRead = 0;
					BufferedInputStream bis = new BufferedInputStream(inputStream);
					StringBuffer sb = new StringBuffer();
					while ((bytesRead = bis.read(buffer)) != -1) {
						String trama = new String(buffer, 0, bytesRead);
						sb.append(trama);
					}
					inputStream.close();

					ObjectMapper mapper = new ObjectMapper();
					mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
					mapper.setSerializationInclusion(Include.ALWAYS);
					SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
					mapper.setDateFormat(sdf.getDateInstance());

					if (httpResponse.getStatusLine().getStatusCode() == 200) {
						response = mapper.readValue(sb.toString(), Object.class);
					} else {
						response = null;
					}

					utilLog.imprimirLog(ConstantesUtils.LEVEL_INFO, "****finalizar consumirREST:" + urlREST + "****");

				} catch (Exception e) {
					utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR,
							"Ocurrio un error al consumir servicio: " + urlREST, e.getStackTrace());
				}
			}

		} catch (Exception e) {
			utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, "Ocurrio un error al consumir servicio: " + urlREST,
					e.getStackTrace());
		} finally {
			httpclient.getConnectionManager().shutdown();
		}

		return response;
	}
}
