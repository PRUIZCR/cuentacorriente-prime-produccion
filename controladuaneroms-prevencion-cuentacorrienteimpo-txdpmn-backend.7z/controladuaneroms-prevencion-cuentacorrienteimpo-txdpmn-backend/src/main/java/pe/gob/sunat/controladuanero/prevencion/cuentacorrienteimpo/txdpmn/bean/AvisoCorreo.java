/***********************************************************************
 * Module:  AvisoCorreo.java
 * Author:  rcontreras
 * Purpose: Defines the Class AvisoCorreo
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.bean;

import java.util.Date;
import java.util.List;

/** <p>Representa un aviso de correo gen&eacute;rico. </p>
 * <p>Un aviso de correo gen&eacute;rico es un aviso que se utiliza para realizar una notificaci&oacute;n 
 * por correo electr&oacute;nico a cualquier destinatario(s), incluyendo la posibilidad de adjuntar archivos . </p> */
public class AvisoCorreo {
   /** <p>Direcci&oacute;n de correo electr&oacute;nico de quien env&iacute;a el aviso </p> */
   private String remitente;
   /** <p>Correo electr&oacute;nico del destinatario del aviso </p> */
   private String destinatario;
   /** <p>Lista de correos electr&oacute;nicos a quien se enviar&aacute; una copia del aviso</p> */
   private List<String> conCopia;
   /** Asunto del aviso */
   private String asunto;
   /** <p>Fecha que indica cuando se publica el aviso. </p> */
   private Date fechaPublicacion;
   /** <p>N&uacute;mero de d&iacute;as que tendr&aacute; vigencia el aviso, para que este pueda ser enviado. </p> */
   private Integer numDiasVigencia;
   
   private java.util.List<ArchivoAdjunto> adjuntos;
   private PlantillaAviso plantilla;
   
   
   /** @pdGenerated default getter */
   public java.util.List<ArchivoAdjunto> getAdjuntos() {
      if (adjuntos == null)
         adjuntos = new java.util.ArrayList<>();
      return adjuntos;
   }
   
   /** @pdGenerated default setter
     * @param newAdjuntos */
   public void setAdjuntos(java.util.List<ArchivoAdjunto> newAdjuntos) {
      removeAllAdjuntos();
      for (java.util.Iterator<ArchivoAdjunto> iter = newAdjuntos.iterator(); iter.hasNext();)
         addAdjuntos(iter.next());
   }
   
   /** @pdGenerated default add
     * @param newArchivoAdjunto */
   public void addAdjuntos(ArchivoAdjunto newArchivoAdjunto) {
      if (newArchivoAdjunto == null)
         return;
      if (this.adjuntos == null)
         this.adjuntos = new java.util.ArrayList<>();
      if (!this.adjuntos.contains(newArchivoAdjunto))
         this.adjuntos.add(newArchivoAdjunto);
   }
   
   /** @pdGenerated default remove
     * @param oldArchivoAdjunto */
   public void removeAdjuntos(ArchivoAdjunto oldArchivoAdjunto) {
      if (oldArchivoAdjunto == null)
         return;
      if (this.adjuntos != null && this.adjuntos.contains(oldArchivoAdjunto))
            this.adjuntos.remove(oldArchivoAdjunto);
   }
   
   /** @pdGenerated default removeAll */
   public void removeAllAdjuntos() {
      if (adjuntos != null)
         adjuntos.clear();
   }
   /** @pdGenerated default parent getter */
   public PlantillaAviso getPlantilla() {
      return plantilla;
   }
   
   /** @pdGenerated default parent setter
     * @param newPlantillaAviso */
   public void setPlantilla(PlantillaAviso newPlantillaAviso) {
      this.plantilla = newPlantillaAviso;
   }
   
   public String getRemitente() {
      return remitente;
   }
   
   /** @param newRemitente */
   public void setRemitente(String newRemitente) {
      remitente = newRemitente;
   }
   
   public String getDestinatario() {
      return destinatario;
   }
   
   /** @param newDestinatario */
   public void setDestinatario(String newDestinatario) {
      destinatario = newDestinatario;
   }
   
   public List<String> getConCopia() {
      return conCopia;
   }
   
   /** @param newConCopia */
   public void setConCopia(List<String> newConCopia) {
      conCopia = newConCopia;
   }
   
   public String getAsunto() {
      return asunto;
   }
   
   /** @param newAsunto */
   public void setAsunto(String newAsunto) {
      asunto = newAsunto;
   }
   
   public Date getFechaPublicacion() {
      return fechaPublicacion;
   }
   
   /** @param newFechaPublicacion */
   public void setFechaPublicacion(Date newFechaPublicacion) {
      fechaPublicacion = newFechaPublicacion;
   }
   
   public Integer getNumDiasVigencia() {
      return numDiasVigencia;
   }
   
   /** @param newNumDiasVigencia */
   public void setNumDiasVigencia(Integer newNumDiasVigencia) {
      numDiasVigencia = newNumDiasVigencia;
   }

}