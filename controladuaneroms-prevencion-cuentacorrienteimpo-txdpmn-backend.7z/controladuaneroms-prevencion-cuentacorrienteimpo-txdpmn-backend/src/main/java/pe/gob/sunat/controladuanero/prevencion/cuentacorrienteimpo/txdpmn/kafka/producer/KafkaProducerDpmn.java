/***********************************************************************
 * Module:  KafkaProducerDpmn.java
 * Author:  rcontreras
 * Purpose: Defines the Interface KafkaProducerDpmn
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.kafka.producer;

import com.fasterxml.jackson.core.JsonProcessingException;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.domain.Dpmn;

/**
 * <p>
 * Permite producir mensajes relacionados con el mantenimiento de la
 * informaci&oacute;n de la colecci&oacute;n dpmns. Esta colecci&oacute;n se
 * encuentra en la base&nbsp; de datos mongodb de cuenta corriente de
 * importaciones (bdCteCorrienteImpo)
 * </p>
 */
public interface KafkaProducerDpmn {
   /** <p>Env&iacute;a un mensaje que indica que se desea registrar informaci&oacute;n</p> 
    * 
    * @param dpmn <p>Informaci&oacute;n de la DPMN</p> */
   void enviarMsgGuardar(Dpmn dpmn)  throws JsonProcessingException ;
   /** <p>Env&iacute;a un mensaje para indicar que se desea actualizar informaci&oacute;n.</p>
    * 
    * @param dpmn <p>Informaci&oacute;n de la DPMN</p> */
   void enviarMsgActualizar(Dpmn dpmn)  throws JsonProcessingException;
   /** <p>Env&iacute;a un mensaje para indicar que se desea eliminar informaci&oacute;n</p>
    * 
    * @param correlativoDpmn <p>Correlativo de la DPMN que se desea eliminar</p> */
   void enviarMsgEliminar(Long correlativoDpmn)  throws JsonProcessingException;

}