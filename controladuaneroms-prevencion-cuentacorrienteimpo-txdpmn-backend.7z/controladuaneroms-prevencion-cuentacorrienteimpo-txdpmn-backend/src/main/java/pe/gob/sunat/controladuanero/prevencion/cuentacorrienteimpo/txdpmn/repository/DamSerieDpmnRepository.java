/***********************************************************************
 * Module:  DamSerieDpmnRepository.java
 * Author:  rcontreras
 * Purpose: Defines the Interface DamSerieDpmnRepository
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.repository;

import java.util.List;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.domain.DamSerieDpmn;

/** <p>Permite trabajar con la colecci&oacute;n "damSeriesDpmn"</p> */
public interface DamSerieDpmnRepository {
   /** <p>Graba la informaci&oacute;n de las series de la DAM vinculadas a la DPMN.&nbsp;</p>
    * <p>Esta informaci&oacute;n la guarda en la colecci&oacute;n "damSeriesDpmn"</p>
    * 
    * @param damSeriesDpmn Informaci&oacute;n de las series de la DAM vinculadas a la DPMN */
   void grabar(List<DamSerieDpmn> damSeriesDpmn);
   
   
   /**
    * Busca las series de la declaraci&oacute;n que se encuentran vinculadas a la DPMN
    * @param correlativoDpmn Correlativo de la DPMN
    * @param incluirAnuladas Indicar si en la b&uacute;squeda tambi&eacute;n se deben incluir registros anulados
    * @return
    * <ul>
    * 	<li>Si existen resultados, se retorna una lista de ellos.</li>
    * 	<li>Si no existen resultados, se retorna una lista vac&iacute;a.</li>
    * </ul>
    */
   List<DamSerieDpmn> buscar(Long correlativoDpmn, boolean incluirAnuladas);
}