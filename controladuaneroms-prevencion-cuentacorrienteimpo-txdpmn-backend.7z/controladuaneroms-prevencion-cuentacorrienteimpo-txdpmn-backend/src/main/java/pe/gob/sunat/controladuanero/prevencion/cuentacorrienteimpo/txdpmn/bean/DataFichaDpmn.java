package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.bean;

import java.util.List;

/**
 * <p>Representa a la data que ser&aacute; pasada al reporte 
 * jasper para la ficha de la DPMN con c&oacute;digo QR.</p>
 * @author rcontreras
 */
public class DataFichaDpmn implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4586326672134484866L;

	private String numeroDpmn;
	private String aduanaDpmn;
	private String puestoControl;
	private String fechaRegistro;
	private String nacionalidadEmpTrans;
	private String rucEmpTrans;
	private String razSocialEmpTrans;
	private String paisPlaca;
	private String placa;
	private String paisPlacaRemolque;
	private String placaRemolque;
	private String nacionalidadConductor;
	private String tipoDocConductor;
	private String nombreConductor;
	private String numDocConductor;
	private String licenciaConductor;
	private String origen;
	private String observacion;
	
	private List<DataFichaDpmn.Comprobante> comprobantes;
	private List<DataFichaDpmn.Declaracion> declaraciones;
	
	public String getNumeroDpmn() {
		return numeroDpmn;
	}
	public void setNumeroDpmn(String numeroDpmn) {
		this.numeroDpmn = numeroDpmn;
	}
	public String getAduanaDpmn() {
		return aduanaDpmn;
	}
	public void setAduanaDpmn(String aduanaDpmn) {
		this.aduanaDpmn = aduanaDpmn;
	}
	public String getPuestoControl() {
		return puestoControl;
	}
	public void setPuestoControl(String puestoControl) {
		this.puestoControl = puestoControl;
	}
	public String getFechaRegistro() {
		return fechaRegistro;
	}
	public void setFechaRegistro(String fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}
	public String getNacionalidadEmpTrans() {
		return nacionalidadEmpTrans;
	}
	public void setNacionalidadEmpTrans(String nacionalidadEmpTrans) {
		this.nacionalidadEmpTrans = nacionalidadEmpTrans;
	}
	public String getRucEmpTrans() {
		return rucEmpTrans;
	}
	public void setRucEmpTrans(String rucEmpTrans) {
		this.rucEmpTrans = rucEmpTrans;
	}
	public String getRazSocialEmpTrans() {
		return razSocialEmpTrans;
	}
	public void setRazSocialEmpTrans(String razSocialEmpTrans) {
		this.razSocialEmpTrans = razSocialEmpTrans;
	}
	public String getPaisPlaca() {
		return paisPlaca;
	}
	public void setPaisPlaca(String paisPlaca) {
		this.paisPlaca = paisPlaca;
	}
	public String getPlaca() {
		return placa;
	}
	public void setPlaca(String placa) {
		this.placa = placa;
	}
	public String getPaisPlacaRemolque() {
		return paisPlacaRemolque;
	}
	public void setPaisPlacaRemolque(String paisPlacaRemolque) {
		this.paisPlacaRemolque = paisPlacaRemolque;
	}
	public String getPlacaRemolque() {
		return placaRemolque;
	}
	public void setPlacaRemolque(String placaRemolque) {
		this.placaRemolque = placaRemolque;
	}
	public String getNacionalidadConductor() {
		return nacionalidadConductor;
	}
	public void setNacionalidadConductor(String nacionalidadConductor) {
		this.nacionalidadConductor = nacionalidadConductor;
	}
	public String getTipoDocConductor() {
		return tipoDocConductor;
	}
	public void setTipoDocConductor(String tipoDocConductor) {
		this.tipoDocConductor = tipoDocConductor;
	}
	public String getNombreConductor() {
		return nombreConductor;
	}
	public void setNombreConductor(String nombreConductor) {
		this.nombreConductor = nombreConductor;
	}
	public String getNumDocConductor() {
		return numDocConductor;
	}
	public void setNumDocConductor(String numDocConductor) {
		this.numDocConductor = numDocConductor;
	}
	public String getLicenciaConductor() {
		return licenciaConductor;
	}
	public void setLicenciaConductor(String licenciaConductor) {
		this.licenciaConductor = licenciaConductor;
	}
	public String getOrigen() {
		return origen;
	}
	public void setOrigen(String origen) {
		this.origen = origen;
	}
	public String getObservacion() {
		return observacion;
	}
	public void setObservacion(String observacion) {
		this.observacion = observacion;
	}
	
	
	public void addComprobante(DataFichaDpmn.Comprobante newComprobante) {
		if ( this.comprobantes == null ) {
			this.comprobantes = new java.util.ArrayList<>();
		}
		
		this.comprobantes.add(newComprobante);
	}
	
	public List<DataFichaDpmn.Comprobante> getComprobantes() {		
		if ( this.comprobantes == null ) {
			this.comprobantes = new java.util.ArrayList<>();
		}
		
		return this.comprobantes;
	}
	public void setComprobantes(List<DataFichaDpmn.Comprobante> comprobantes) {
		this.comprobantes = comprobantes;
	}
	
	public void addDeclaracion(DataFichaDpmn.Declaracion newDeclaracion) {		
		if ( this.declaraciones == null ) {
			this.declaraciones = new java.util.ArrayList<>();
		}
		
		this.declaraciones.add(newDeclaracion);
	}

	public List<DataFichaDpmn.Declaracion> getDeclaraciones() {
		if ( this.declaraciones == null ) {
			this.declaraciones = new java.util.ArrayList<>();
		}
		
		return this.declaraciones;
	}
	public void setDeclaraciones(List<DataFichaDpmn.Declaracion> declaraciones) {
		this.declaraciones = declaraciones;
	}

	public static class Comprobante implements java.io.Serializable {
		/**
		 * 
		 */
		private static final long serialVersionUID = 3598653311813317010L;
		private Long numCorrelativo;
		private String numero;
		private String rucRemitente;
		private String razonRemitente;
		private String motivo;
		private String rucDestinatario;
		private String razonDestinatario;
		private String destino;
		private String empresa;
		
		public Long getNumCorrelativo() {
			return numCorrelativo;
		}
		public void setNumCorrelativo(Long numCorrelativo) {
			this.numCorrelativo = numCorrelativo;
		}
		public String getNumero() {
			return numero;
		}
		public void setNumero(String numero) {
			this.numero = numero;
		}
		public String getRucRemitente() {
			return rucRemitente;
		}
		public void setRucRemitente(String rucRemitente) {
			this.rucRemitente = rucRemitente;
		}
		public String getRazonRemitente() {
			return razonRemitente;
		}
		public void setRazonRemitente(String razonRemitente) {
			this.razonRemitente = razonRemitente;
		}
		public String getMotivo() {
			return motivo;
		}
		public void setMotivo(String motivo) {
			this.motivo = motivo;
		}
		public String getRucDestinatario() {
			return rucDestinatario;
		}
		public void setRucDestinatario(String rucDestinatario) {
			this.rucDestinatario = rucDestinatario;
		}
		public String getRazonDestinatario() {
			return razonDestinatario;
		}
		public void setRazonDestinatario(String razonDestinatario) {
			this.razonDestinatario = razonDestinatario;
		}
		public String getDestino() {
			return destino;
		}
		public void setDestino(String destino) {
			this.destino = destino;
		}
		public String getEmpresa() {
			return empresa;
		}
		public void setEmpresa(String empresa) {
			this.empresa = empresa;
		}
	}
	
	public static class Declaracion implements java.io.Serializable {		
		/**
		 * 
		 */
		private static final long serialVersionUID = 5855126809617041935L;
		private String comprobante;
		private String dam;
		private Integer serie;
		private String descripcion;
		private java.math.BigDecimal cntdeclarada;
		private java.math.BigDecimal cntretirada;
		private String unidad;
		
		
		public String getComprobante() {
			return comprobante;
		}
		public void setComprobante(String comprobante) {
			this.comprobante = comprobante;
		}
		public String getDam() {
			return dam;
		}
		public void setDam(String dam) {
			this.dam = dam;
		}
		public Integer getSerie() {
			return serie;
		}
		public void setSerie(Integer serie) {
			this.serie = serie;
		}
		public String getDescripcion() {
			return descripcion;
		}
		public void setDescripcion(String descripcion) {
			this.descripcion = descripcion;
		}
		public java.math.BigDecimal getCntdeclarada() {
			return cntdeclarada;
		}
		public void setCntdeclarada(java.math.BigDecimal cntdeclarada) {
			this.cntdeclarada = cntdeclarada;
		}
		public java.math.BigDecimal getCntretirada() {
			return cntretirada;
		}
		public void setCntretirada(java.math.BigDecimal cntretirada) {
			this.cntretirada = cntretirada;
		}
		public String getUnidad() {
			return unidad;
		}
		public void setUnidad(String unidad) {
			this.unidad = unidad;
		}	
		
	}
	
}
