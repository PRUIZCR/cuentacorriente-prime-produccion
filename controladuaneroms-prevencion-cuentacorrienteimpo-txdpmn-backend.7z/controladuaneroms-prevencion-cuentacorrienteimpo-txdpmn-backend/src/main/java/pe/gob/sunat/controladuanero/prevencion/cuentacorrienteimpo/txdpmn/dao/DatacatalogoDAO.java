package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.dao;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.tecnologiams.arquitectura.framework.jpa.dao.BaseDao;

public interface DatacatalogoDAO{
	 public String  obtenerDataCatalogoAsoc(String codAsoccat, String codDatacat);
	
}
