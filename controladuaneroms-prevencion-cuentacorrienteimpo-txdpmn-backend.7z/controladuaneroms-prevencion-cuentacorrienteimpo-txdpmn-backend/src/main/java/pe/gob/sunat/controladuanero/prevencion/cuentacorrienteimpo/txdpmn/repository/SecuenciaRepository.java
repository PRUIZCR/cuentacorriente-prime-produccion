/***********************************************************************
 * Module:  SecuenciaRepository.java
 * Author:  rcontreras
 * Purpose: Defines the Interface SecuenciaRepository
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.repository;

/** <p>Permite trabajar con la colecci&oacute;n "secuencias"</p> */
public interface SecuenciaRepository {
   /** Obtiene el siguiente valor de la secuencia
    * 
    * @param nomSecuencia Nombre de la secuencia
    * @return 
    * <ul> 
    * <li>Si la secuencia existe, se retorna su siguiente valor</li>
    * <li>Si la secuencia no existe, se retorna NULL</li>
    * </ul> */
   Integer getNexValue(String nomSecuencia);

}