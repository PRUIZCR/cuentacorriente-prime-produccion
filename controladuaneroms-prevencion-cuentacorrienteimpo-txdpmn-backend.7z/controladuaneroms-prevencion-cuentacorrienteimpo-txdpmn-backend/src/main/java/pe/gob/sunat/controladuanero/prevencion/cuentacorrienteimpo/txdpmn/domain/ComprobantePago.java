/***********************************************************************
 * Module:  ComprobantePago.java
 * Author:  rcontreras
 * Purpose: Defines the Class ComprobantePago
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.domain;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonSubTypes.Type;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.domain.common.Auditoria;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.domain.common.DataCatalogo;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.domain.common.Ubigeo;


@JsonTypeInfo(
	use = JsonTypeInfo.Id.NAME, 
	include = JsonTypeInfo.As.PROPERTY, 
	property = "type")
@JsonSubTypes({ 
	@Type(value = GuiaRemision.class, name = "GuiaRemision"), 
	@Type(value = CartaPorte.class, name = "CartaPorte")
})
public class ComprobantePago implements java.io.Serializable {
   /**
	 * 
	 */
	private static final long serialVersionUID = -5504468939628612261L;
	private Long numCorrelativo;
   private DataCatalogo tipoComprobante;
   private String numRucDestinatario;
   private String desRazonSocialDestinatario;
   private DataCatalogo motivoDeTraslado;
   private Ubigeo ubigeoDestino;
   private boolean indEliminado;
   private Auditoria auditoria;
   
   public Long getNumCorrelativo() {
      return numCorrelativo;
   }
   
   /** @param newNumCorrelativo */
   public void setNumCorrelativo(Long newNumCorrelativo) {
      numCorrelativo = newNumCorrelativo;
   }
   
   public DataCatalogo getTipoComprobante() {
      return tipoComprobante;
   }
   
   /** @param newTipoComprobante */
   public void setTipoComprobante(DataCatalogo newTipoComprobante) {
      tipoComprobante = newTipoComprobante;
   }
   
   public String getNumRucDestinatario() {
      return numRucDestinatario;
   }
   
   /** @param newNumRucDestinatario */
   public void setNumRucDestinatario(String newNumRucDestinatario) {
      numRucDestinatario = newNumRucDestinatario;
   }
   
   public String getDesRazonSocialDestinatario() {
      return desRazonSocialDestinatario;
   }
   
   /** @param newDesRazonSocialDestinatario */
   public void setDesRazonSocialDestinatario(String newDesRazonSocialDestinatario) {
      desRazonSocialDestinatario = newDesRazonSocialDestinatario;
   }
   
   public DataCatalogo getMotivoDeTraslado() {
      return motivoDeTraslado;
   }
   
   /** @param newMotivoDeTraslado */
   public void setMotivoDeTraslado(DataCatalogo newMotivoDeTraslado) {
      motivoDeTraslado = newMotivoDeTraslado;
   }
   
   public Ubigeo getUbigeoDestino() {
      return ubigeoDestino;
   }
   
   /** @param newUbigeoDestino */
   public void setUbigeoDestino(Ubigeo newUbigeoDestino) {
      ubigeoDestino = newUbigeoDestino;
   }
   
   public boolean getIndEliminado() {
      return indEliminado;
   }
   
   /** @param newIndEliminado */
   public void setIndEliminado(boolean newIndEliminado) {
      indEliminado = newIndEliminado;
   }
   
   public Auditoria getAuditoria() {
      return auditoria;
   }
   
   /** @param newAuditoria */
   public void setAuditoria(Auditoria newAuditoria) {
      auditoria = newAuditoria;
   }

}