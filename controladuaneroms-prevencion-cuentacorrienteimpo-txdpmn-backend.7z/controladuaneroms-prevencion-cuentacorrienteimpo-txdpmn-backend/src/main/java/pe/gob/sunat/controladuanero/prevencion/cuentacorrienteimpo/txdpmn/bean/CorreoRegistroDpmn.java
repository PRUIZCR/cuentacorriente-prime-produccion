/***********************************************************************
 * Module:  CorreoRegistroDpmn.java
 * Author:  rcontreras
 * Purpose: Defines the Class CorreoRegistroDpmn
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.bean;

import java.util.*;

public class CorreoRegistroDpmn {
   private CorreoRegistroDpmn.Destinatario destinatario;
   private Long correlativoDpmn;
   private String numeroDpmn;
   private String fechaDpmn;
   private String aduanaDescarga;
   private String puestoControl;
   
   public String getNumeroDpmn() {
      return numeroDpmn;
   }
   
   /** @param newNumeroDpmn */
   public void setNumeroDpmn(String newNumeroDpmn) {
      numeroDpmn = newNumeroDpmn;
   }
   
   public Long getCorrelativoDpmn() {
      return correlativoDpmn;
   }
   
   /** @param newCorrelativoDpmn */
   public void setCorrelativoDpmn(Long newCorrelativoDpmn) {
      correlativoDpmn = newCorrelativoDpmn;
   }
   
   public String getAduanaDescarga() {
      return aduanaDescarga;
   }
   
   /** @param newAduanaDescarga */
   public void setAduanaDescarga(String newAduanaDescarga) {
      aduanaDescarga = newAduanaDescarga;
   }
   
   public String getPuestoControl() {
      return puestoControl;
   }
   
   /** @param newPuestoControl */
   public void setPuestoControl(String newPuestoControl) {
      puestoControl = newPuestoControl;
   }
   
   public CorreoRegistroDpmn.Destinatario getDestinatario() {
      return destinatario;
   }
   
   /** @param newDestinatario */
   public void setDestinatario(CorreoRegistroDpmn.Destinatario newDestinatario) {
      destinatario = newDestinatario;
   }
   
   public String getFechaDpmn() {
      return fechaDpmn;
   }
   
   /** @param newFechaDpmn */
   public void setFechaDpmn(String newFechaDpmn) {
      fechaDpmn = newFechaDpmn;
   }

   public class Destinatario {
      private String correo;
      private String nombre;
      
      public String getCorreo() {
         return correo;
      }
      
      /** @param newCorreo */
      public void setCorreo(String newCorreo) {
         correo = newCorreo;
      }
      
      public String getNombre() {
         return nombre;
      }
      
      /** @param newNombre */
      public void setNombre(String newNombre) {
         nombre = newNombre;
      }
   
   }

}