package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.kafka.producer;

import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.bean.KafkaMsgDamSeriesDpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.domain.DamSerieDpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.main.config.TransaccionDpmnConfig;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.util.Constantes;
import pe.gob.sunat.tecnologia3.arquitectura.framework.kafka.Producer;

public class KafkaProducerDamSeriesDpmnImpl implements KafkaProducerDamSeriesDpmn {
	
	private Producer producer;
	
	public KafkaProducerDamSeriesDpmnImpl() {
		this.producer = new Producer(TransaccionDpmnConfig.getConfig().getCfgKafkaProducerDamSeriesDpmn());
	}
	
	/**
	 * {@inheritDoc}
	 * @author rcontreras
	 * @throws JsonProcessingException 
	 */
	@Override
	public void enviarMsgGuardar(List<DamSerieDpmn> damSeriesDpmn) throws JsonProcessingException {
		KafkaMsgDamSeriesDpmn msgDamSeriesDpmn = new KafkaMsgDamSeriesDpmn();
		msgDamSeriesDpmn.setTipoOperacion(Constantes.TipoOperacion.REGISTRO.getCodigo());
		msgDamSeriesDpmn.setDamSeriesDpmn(damSeriesDpmn);
		
		ObjectMapper objectMapper = new ObjectMapper();
		String dataJson = objectMapper.writeValueAsString(msgDamSeriesDpmn);
		
		this.producer.send(dataJson);
		
	}
	
}