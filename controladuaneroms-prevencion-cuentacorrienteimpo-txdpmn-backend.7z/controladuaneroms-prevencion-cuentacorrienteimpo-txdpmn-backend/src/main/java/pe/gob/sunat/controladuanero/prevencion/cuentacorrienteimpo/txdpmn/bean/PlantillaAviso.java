/***********************************************************************
 * Module:  PlantillaAviso.java
 * Author:  rcontreras
 * Purpose: Defines the Class PlantillaAviso
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.bean;

import java.util.*;

/** <p>Representa la plantilla utilizada para generar un aviso . </p>
 * <p>Se trata de una plantilla velocity con extensi&oacute;n HTML, que se utilizar&aacute; para la generaci&oacute;n del contenido del aviso. </p> */
public class PlantillaAviso {
   /** N&uacute;mero de servicio de la plantilla */
   private Integer numeroServicio;
   /** <p>Archivo donde se encuentra la plantilla</p> */
   private String archivo;
   /** <p>Data que ser&aacute; mapeada en el contenido del archivo de plantilla. </p> */
   private Map<String, String> data;
   
   public String getArchivo() {
      return archivo;
   }
   
   /** @param newArchivo */
   public void setArchivo(String newArchivo) {
      archivo = newArchivo;
   }
   
   public Map<String, String> getData() {
      return data;
   }
   
   /** @param newData */
   public void setData(Map<String, String> newData) {
      data = newData;
   }
   
   public Integer getNumeroServicio() {
      return numeroServicio;
   }
   
   /** @param newNumeroServicio */
   public void setNumeroServicio(Integer newNumeroServicio) {
      numeroServicio = newNumeroServicio;
   }

}