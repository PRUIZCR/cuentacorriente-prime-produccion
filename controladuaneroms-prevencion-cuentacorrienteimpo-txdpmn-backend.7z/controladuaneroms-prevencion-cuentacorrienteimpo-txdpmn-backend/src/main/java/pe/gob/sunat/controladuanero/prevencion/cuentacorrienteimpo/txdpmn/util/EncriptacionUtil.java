package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.util;

import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;
public class EncriptacionUtil {
	private static final String ALGORITMO_ENCRIPTACION = "PBEWithMD5AndDES";
	private static final String CLAVE = "abgY6@0MvY-$*45=?hydlmHK10=";
	private static final byte[] SALT = {
            (byte) 0xde, (byte) 0x33, (byte) 0x10, (byte) 0x12,
            (byte) 0xde, (byte) 0x33, (byte) 0x10, (byte) 0x12,
        };
	
	private EncriptacionUtil() {
		throw new IllegalAccessError("No se puede instanciar clase util");
	}
	
	private static SecretKey getClave() throws NoSuchAlgorithmException, InvalidKeySpecException {
		PBEKeySpec pbeSpec = new PBEKeySpec(CLAVE.toCharArray());
		SecretKeyFactory keyFact = SecretKeyFactory.getInstance(ALGORITMO_ENCRIPTACION);
		return keyFact.generateSecret(pbeSpec);
	}
	
	public static byte[] encriptar(byte[] data) throws Exception {
		try {
			SecretKey secretKey = getClave();
			Cipher cipher = Cipher.getInstance(ALGORITMO_ENCRIPTACION);
			cipher.init(Cipher.ENCRYPT_MODE, secretKey, new PBEParameterSpec(SALT, 20));
			return cipher.doFinal(data);
		}catch (java.lang.Exception ex) {
			throw new Exception(ex);
		}
	}
	
	public static byte[] desencriptar(byte[] data) throws Exception {
		try {
			SecretKey secretKey = getClave();
			Cipher cipher = Cipher.getInstance(ALGORITMO_ENCRIPTACION);
			cipher.init(Cipher.DECRYPT_MODE, secretKey, new PBEParameterSpec(SALT, 20));
			return cipher.doFinal(data);
		}catch (java.lang.Exception ex) {
			throw new Exception(ex);
		}
	}	
	
	/**
	 * Encripta una cadena de texto y la retorna como una cadena de texto en base64 para URL 
	 * @author rcontreras
	 * @param cadena cadena de texto que se desea encriptar 
	 * @return
	 * Si es correcto, se retorna una cadena encriptada en base 64 modificado para URL
	 * @throws SalidaException
	 */
	public static final String encriptarParamURL(String cadena) throws Exception {
		return new String(Base64.getUrlEncoder().encode(encriptar(cadena.getBytes())));
	}
	
	
	/**
	 * <p>Se encarga de desencriptar una cadena en base64 para URL. </p>
	 * <p><strong>Nota: </strong>La cadena a desencriptar, debi&oacute; ser generada por {@link EncriptacionUtil#encriptarParamURL}</p>
	 * @author rcontreras
	 * @param cadena Cadena de texto en base 64 para URL
	 * @return 
	 * Si es correcto, se retorna la cadena original que fue utilizada en {@link EncriptacionUtil#encriptarParamURL}
	 * @throws SalidaException
	 */
	public static final String desencriptarParamURL(String cadena) throws Exception {
		byte[] data = Base64.getUrlDecoder().decode(cadena);
		return new String(desencriptar(data));
	}
	
}
