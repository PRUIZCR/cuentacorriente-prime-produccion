/***********************************************************************
 * Module:  ArchivoAdjunto.java
 * Author:  rcontreras
 * Purpose: Defines the Class ArchivoAdjunto
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.bean;

import java.util.*;

/** Archivo que se desea adjuntar */
public class ArchivoAdjunto {
   /** Nombre del archivo */
   private String nombre;
   private String tipoContenido;
   /** Contenido del archivo */
   private byte[] contenido;
   
   public String getNombre() {
      return nombre;
   }
   
   /** @param newNombre */
   public void setNombre(String newNombre) {
      nombre = newNombre;
   }
   
   public byte[] getContenido() {
      return contenido;
   }
   
   /** @param newContenido */
   public void setContenido(byte[] newContenido) {
      contenido = newContenido;
   }
   
   public String getTipoContenido() {
      return tipoContenido;
   }
   
   /** @param newTipoContenido */
   public void setTipoContenido(String newTipoContenido) {
      tipoContenido = newTipoContenido;
   }

}