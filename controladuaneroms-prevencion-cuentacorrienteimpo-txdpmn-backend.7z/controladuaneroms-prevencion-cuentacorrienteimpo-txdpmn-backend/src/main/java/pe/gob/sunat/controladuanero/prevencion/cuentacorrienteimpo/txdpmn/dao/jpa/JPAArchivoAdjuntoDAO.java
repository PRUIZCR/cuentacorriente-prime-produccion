/***********************************************************************
 * Module:  JPAAvisosDAO.java
 * Author:  msancheza
 * Purpose: Defines the Class JPAAvisosDAO
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.dao.jpa;

import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.bean.ArchivoAdjunto;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.dao.ArchivoAdjuntoDAO;
import pe.gob.sunat.tecnologiams.arquitectura.framework.common.util.ConstantesUtils;
import pe.gob.sunat.tecnologiams.arquitectura.framework.jpa.dao.AbstractDao;
import pe.gob.sunat.tecnologiams.arquitectura.framework.microservices.util.UtilLog;

public class JPAArchivoAdjuntoDAO  implements ArchivoAdjuntoDAO {
	
	@Inject
	private UtilLog utilLog;

	@Inject
	@Named("dgbdsigad")
	protected EntityManager dgbdsigad;
	
	@Override
	public void insert(Map datos) {
 	    try {
	  	    	dgbdsigad.getTransaction().begin();
	  		    Query query = dgbdsigad.createNativeQuery("INSERT INTO AVISOADJUNTO (num_secaviso,num_secadj,nom_adjunto,arc_adjunto) values (?,?,?,?) ");
	  		    query.setParameter(1, datos.get("numSecAviso").toString());
	  		    query.setParameter(2, datos.get("numSecAdj").toString());
	  		    query.setParameter(3, datos.get("nomAdjunto").toString());
	  		    query.setParameter(4, datos.get("arcAdjunto"));
	  		    
	  		    query.executeUpdate();
	  		    dgbdsigad.getTransaction().commit();
	  		} catch( java.lang.Exception ex ) {
	  			utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, ex.getMessage());
	  		}
	  	    
	  	 
	}


}