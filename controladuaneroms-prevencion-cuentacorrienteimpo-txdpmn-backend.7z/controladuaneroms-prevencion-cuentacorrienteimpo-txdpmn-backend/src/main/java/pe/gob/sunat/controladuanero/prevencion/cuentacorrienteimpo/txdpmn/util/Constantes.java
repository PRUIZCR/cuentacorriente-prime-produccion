/***********************************************************************
 * Module:  Constantes.java
 * Author:  rcontreras
 * Purpose: Defines the Class Constantes
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.util;

public class Constantes {
	
	
	public static final Integer COD_ESTADO_HTTP_ERROR_VALIDACION = 422;
	public static final String MSG_PERSISTENCE_EXCEPTION = "Excepcion PersistenceException {}";
	public final static String COD_TIPOAVISO_MENSAJE = "2";
	public final static String COD_GRUPO_MENSAJES = "941";
	public final static String COD_ATRIBUTO_MENSAJE_DIASVIGENCIA = "124";
	public final static String COD_CATALOGO_AVISOSELECTRONICOS = "AW";
	private Constantes() {
	      throw new IllegalAccessError("No se puede instanciar clase util");
	}
	
   public enum TipoOperacion {
      REGISTRO("01"),
      MODIFICACION("02"),
      ANULACION("03");
   
      private final String codigo;
      
      /** @param newCodigo */
      private TipoOperacion(String newCodigo) {
         this.codigo = newCodigo;
      }
      
      public String getCodigo() {
    	  return this.codigo;
      }
      
      /** Verifica si el c&oacute;digo pasado pertenece a la constante ENUM referenciada
       * 
       * @param valor Valor que se desea verificar si es igual al c&oacute;digo de la constante ENUM
       * @return 
       * <ul>
       *   <li>true - Si es un c&oacute;digo v&aacute;lido.</li>
       *   <li>false - Si no es un c&oacute;digo v&aacute;lido </li>
       * </ul> */
      public boolean is(String valor) {
         return this.codigo.equals(valor);
      }
      
      /** <p>Obtiene la respectiva instancia de la constante ENUM, la cual  corresponda con el valor de su c&oacute;digo.</p>
       * 
       * @param valorCodigo Valor del c&oacute;digo que se asocia con la constante ENUM a buscar.
       * @return
       * <ul>
       *   <li>Si se encuentra constante ENUM con ese determinado c&oacute;digo, entonces esta es retornada.</li>
       *   <li>Si no se encuentra constante ENUM con ese determinado c&oacute;digo, entonces se retorna NULL</li>
       * </ul> */
      public static Constantes.TipoOperacion getInstancia(String valorCodigo) {
    	  TipoOperacion[] listaTipoOperacion =  TipoOperacion.values();
    	  for(TipoOperacion tipoOperacion : listaTipoOperacion){
    		  String codigo = tipoOperacion.getCodigo();
    		  if(codigo.equals(valorCodigo)){
    			  return tipoOperacion;
    		  }
    	  }
         return null;
      }
   
   }

}