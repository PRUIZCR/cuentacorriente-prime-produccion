package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.util;

public class TransaccionDpmnException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 6217278155222639145L;

	public TransaccionDpmnException(String message, Throwable cause) {
        super(message, cause);
    }

    public TransaccionDpmnException(String message) {
        super(message);
    }

    public TransaccionDpmnException(Throwable cause) {
        super(cause);
    }

}
