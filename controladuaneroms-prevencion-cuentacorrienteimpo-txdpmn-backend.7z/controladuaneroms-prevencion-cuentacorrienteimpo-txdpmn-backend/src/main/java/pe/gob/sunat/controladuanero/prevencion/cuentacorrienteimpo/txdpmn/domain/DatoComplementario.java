/***********************************************************************
 * Module:  DatoComplementario.java
 * Author:  rcontreras
 * Purpose: Defines the Class DatoComplementario
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.domain;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.domain.common.Ubigeo;

public class DatoComplementario implements java.io.Serializable {
   /**
	 * 
	 */
	private static final long serialVersionUID = 4675212974529278710L;
	private Ubigeo ubigeoOrigen;
   private String desObservacion;
   
   public Ubigeo getUbigeoOrigen() {
      return ubigeoOrigen;
   }
   
   /** @param newUbigeoOrigen */
   public void setUbigeoOrigen(Ubigeo newUbigeoOrigen) {
      ubigeoOrigen = newUbigeoOrigen;
   }
   
   public String getDesObservacion() {
      return desObservacion;
   }
   
   /** @param newDesObservacion */
   public void setDesObservacion(String newDesObservacion) {
      desObservacion = newDesObservacion;
   }

}