/***********************************************************************
 * Module:  DamSerieDpmnMongoDBImpl.java
 * Author:  rcontreras
 * Purpose: Defines the Class DamSerieDpmnMongoDBImpl
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.repository.mongodb;

import java.util.List;

import org.bson.conversions.Bson;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.model.Filters;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.domain.DamSerieDpmn;
import pe.gob.sunat.tecnologia.arquitectura.framework.mongodb.client.MongoDBClient;

public class DamSerieDpmnMongoDBImpl implements pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.repository.DamSerieDpmnRepository {
	private static final String DAMSERIEDPMNS = "damSeriesDpmn";
	private static final String DS_ESCRITURA = "dgctecorrienteimpo";
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public void grabar(List<DamSerieDpmn> damSeriesDpmn) {
		//1. Grabar el objeto damSeriesDpmn en la colecci�n "damSeriesDpmn"
		MongoCollection<DamSerieDpmn> colleccion = MongoDBClient.getCollection(DS_ESCRITURA,DAMSERIEDPMNS,DamSerieDpmn.class);
		colleccion.insertMany(damSeriesDpmn);
	}

	/**
	 * @author rcontreras
	 * {@inheritDoc}
	 */
	@Override
	public List<DamSerieDpmn> buscar(Long correlativoDpmn, boolean incluirAnuladas) {
		MongoCollection<DamSerieDpmn> coleccion = MongoDBClient.getCollection(DS_ESCRITURA, DAMSERIEDPMNS, DamSerieDpmn.class);
		
		List<DamSerieDpmn> resultado = new java.util.ArrayList<>();
		
		Bson filtros = null;
		
		if ( !incluirAnuladas ) {
			filtros = Filters.and(Filters.eq("numCorreDpmn", correlativoDpmn), Filters.ne("indEliminado", true));
		} else {
			filtros = Filters.eq("numCorreDpmn", correlativoDpmn);
		}
		
		MongoCursor<DamSerieDpmn> cursor = coleccion.find(filtros).iterator();

		try {
			
			while ( cursor.hasNext() ) {
				resultado.add(cursor.next());
			}
			
		} finally {
			cursor.close();
		}
		
		return resultado;
	}
}