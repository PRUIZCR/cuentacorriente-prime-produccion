/***********************************************************************
 * Module:  JPAAvisosDAO.java
 * Author:  msancheza
 * Purpose: Defines the Class JPAAvisosDAO
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.dao.jpa;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.eclipse.persistence.exceptions.DatabaseException;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.bean.AvisoCorreo;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.txdpmn.dao.AvisosDAO;
import pe.gob.sunat.tecnologiams.arquitectura.framework.common.util.ConstantesUtils;
import pe.gob.sunat.tecnologiams.arquitectura.framework.jpa.dao.AbstractDao;
import pe.gob.sunat.tecnologiams.arquitectura.framework.microservices.util.UtilLog;

public class JPAAvisosDAO implements AvisosDAO {
	@Inject
	private UtilLog utilLog;

	@Inject
	@Named("dgbdsigad")
	protected EntityManager dgbdsigad;
	
	@Override
	  public void insert(Long numId,Integer servicioId, StringBuffer data, String tipoAviso,
	      Timestamp fechaPublicacion, Timestamp fechaVigencia,Timestamp fechaCreacion,String tipoProcUsu)
	  throws DatabaseException {
	
		//Long seq = ((BigDecimal) (dcbdsigad.createNativeQuery("select SEAVISOS.nextval from dual").getResultList()).get(0)).longValue();
	
		dgbdsigad.getTransaction().begin();
	    Query query = dgbdsigad.createNativeQuery("INSERT INTO avisos (num_secaviso, num_servicio, 	des_dataaviso, cod_tipoaviso,fec_regis,fec_publicacion, fec_vigencia,ind_estado) VALUES(?,?,?,?,?,?,?,?)");
	    query.setParameter(1, numId);
	    query.setParameter(2, servicioId);
	    query.setParameter(3, data.toString());
	    query.setParameter(4, tipoAviso);
	    query.setParameter(5, fechaPublicacion);
	    query.setParameter(6, fechaVigencia);
	    query.setParameter(7, fechaCreacion);
	    if ("1".equals(tipoProcUsu)){
	    	query.setParameter(8, "0");//aviso pendiente de procesar los usuarios desde la data en json
		    }else if ("2".equals(tipoProcUsu)){
		    	query.setParameter(8, "2");;//aviso pendiente de procesar los usuarios desde un archivo
		    }

	    query.executeUpdate();
	    dgbdsigad.getTransaction().commit();

		
	}
	@Override
	public BigDecimal getSecuencia(){
		StringBuilder sql = new StringBuilder();
		BigDecimal resultado = new BigDecimal(0);
		sql.append("select SEAVISOS.nextval from dual");

		try {
			Query query = dgbdsigad.createNativeQuery(sql.toString());
			resultado = (BigDecimal) query.getSingleResult();
	
		} catch (java.lang.Exception ex) {
			utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, ex.getMessage());
		}
		return resultado;
	}
	

}