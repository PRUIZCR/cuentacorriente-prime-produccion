# Versi&oacute;n actual
1.0.38-1

# Descripcion
Microservicio para consulta de RCE

# Historial de cambios

| Versi&oacute;n | Pase | Descripci&oacute;n |
| --- | --- | --- |
| 1.0.38-1 | PAS20211U220100038 | Microservicio para consulta de RCE | 