export const environment = {
  production: false,
  urlBase: 'https://api-desa.sunat.gob.pe'
};
