import { Component, OnInit} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TokenAccesoService } from './services/token-acceso.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'controladuaneroms-prevencion-cuentacorrienteimpo-condpmn-frontend';
  

  constructor(private activateRoute: ActivatedRoute,
    private router: Router,
    private tokenAccesoService: TokenAccesoService,) { }
  
  ngOnInit(): void {
    this.activateRoute.queryParams
    .subscribe(params => {
      if ( params.token != null ) {
        this.tokenAccesoService.guardarTokenSession(params.token);
        this.router.navigate(['/condpmn']);
      }

      }
    );
  }
}
