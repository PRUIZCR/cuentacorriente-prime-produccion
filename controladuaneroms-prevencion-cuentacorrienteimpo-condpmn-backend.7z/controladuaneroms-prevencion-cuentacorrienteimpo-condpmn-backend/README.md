# Versi&oacute;n actual
1.0.59-1

# Descripcion
Microservicio para consulta de la DPMN. 
Aqui deben estar los servicios REST que seran usados por los FrontEnd que 
implementan la consulta de la DPMN en el portal del operador, intranet, o extranet. 

# Historial de cambios

| Versi&oacute;n | Pase | Descripci&oacute;n |
| --- | --- | --- |
| 1.0.59-1 | PAS20211U220100059 | Microservicio para consulta de la DPMN | 