package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.util;

public class Reporte {
	private String numeroDeDocumentoDescarga;
	private String estado;
	private String paisPlaca;
	private String placaCarreta;
	private String flujoVehiculo;
	private String fechaDeRegistro;
	private String rucDelRemitente;
	private Integer cantidadDeSeries;
	private Integer cantidadDeControles;
	private String fechaDelUltimoControl;
	private String canalDelUltimoControl;
	private String funcionarioAduanero;

	public String getNumeroDeDocumentoDescarga() {
		return numeroDeDocumentoDescarga;
	}

	public void setNumeroDeDocumentoDescarga(String numeroDeDocumentoDescarga) {
		this.numeroDeDocumentoDescarga = numeroDeDocumentoDescarga;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getPaisPlaca() {
		return paisPlaca;
	}

	public void setPaisPlaca(String paisPlaca) {
		this.paisPlaca = paisPlaca;
	}

	public String getPlacaCarreta() {
		return placaCarreta;
	}

	public void setPlacaCarreta(String placaCarreta) {
		this.placaCarreta = placaCarreta;
	}

	public String getFlujoVehiculo() {
		return flujoVehiculo;
	}

	public void setFlujoVehiculo(String flujoVehiculo) {
		this.flujoVehiculo = flujoVehiculo;
	}

	public String getFechaDeRegistro() {
		return fechaDeRegistro;
	}

	public void setFechaDeRegistro(String fechaDeRegistro) {
		this.fechaDeRegistro = fechaDeRegistro;
	}

	public String getRucDelRemitente() {
		return rucDelRemitente;
	}

	public void setRucDelRemitente(String rucDelRemitente) {
		this.rucDelRemitente = rucDelRemitente;
	}

	public Integer getCantidadDeSeries() {
		return cantidadDeSeries;
	}

	public void setCantidadDeSeries(Integer cantidadDeSeries) {
		this.cantidadDeSeries = cantidadDeSeries;
	}

	public Integer getCantidadDeControles() {
		return cantidadDeControles;
	}

	public void setCantidadDeControles(Integer cantidadDeControles) {
		this.cantidadDeControles = cantidadDeControles;
	}

	public String getFechaDelUltimoControl() {
		return fechaDelUltimoControl;
	}

	public void setFechaDelUltimoControl(String fechaDelUltimoControl) {
		this.fechaDelUltimoControl = fechaDelUltimoControl;
	}

	public String getCanalDelUltimoControl() {
		return canalDelUltimoControl;
	}

	public void setCanalDelUltimoControl(String canalDelUltimoControl) {
		this.canalDelUltimoControl = canalDelUltimoControl;
	}

	public String getFuncionarioAduanero() {
		return funcionarioAduanero;
	}

	public void setFuncionarioAduanero(String funcionarioAduanero) {
		this.funcionarioAduanero = funcionarioAduanero;
	}

}
