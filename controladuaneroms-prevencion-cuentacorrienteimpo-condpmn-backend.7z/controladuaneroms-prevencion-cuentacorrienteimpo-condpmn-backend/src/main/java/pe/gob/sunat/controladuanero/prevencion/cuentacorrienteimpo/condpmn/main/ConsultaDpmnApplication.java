package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.main;

import io.dropwizard.setup.Bootstrap;
import io.dropwizard.setup.Environment;
import io.dropwizard.views.ViewBundle;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.main.config.ConsultaDpmnConfig;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.ws.rest.ConsultaDamSerieCcmnRestService;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.ws.rest.ConsultaDamSerieDpmnRestService;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.ws.rest.ConsultaDeCcmnRestService;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.ws.rest.ConsultaDeDpmnRestService;
import pe.gob.sunat.tecnologiams.arquitectura.framework.microservices.SunatApplication;
import pe.gob.sunat.tecnologiams.arquitectura.framework.microservices.exception.ConstraintViolationExceptionMapper;
import pe.gob.sunat.tecnologiams.arquitectura.framework.microservices.exception.GenericExceptionMapper;
import pe.gob.sunat.tecnologiams.arquitectura.framework.microservices.exception.ObjectNotFoundExceptionMapper;

public class ConsultaDpmnApplication extends SunatApplication<ConsultaDpmnConfig> {

	@Override
	public void onRun(ConsultaDpmnConfig configuration, Environment environment) throws Exception {
		environment.jersey().register(ConstraintViolationExceptionMapper.class);
		environment.jersey().register(ObjectNotFoundExceptionMapper.class);
		environment.jersey().register(GenericExceptionMapper.class);
		environment.jersey().register(ConsultaDeDpmnRestService.class);
		environment.jersey().register(ConsultaDamSerieDpmnRestService.class);
		environment.jersey().register(ConsultaDeCcmnRestService.class);
		environment.jersey().register(ConsultaDamSerieCcmnRestService.class);
		ConsultaDpmnConfig.loadConfig(configuration);
		configuration.getMongodb().loadConfig();
	}

	@Override
	public void onInitialize(Bootstrap<ConsultaDpmnConfig> bootstrap) {
		bootstrap.addBundle(new ViewBundle<>());
	}

	public static void main(String... params) throws Exception {
		new ConsultaDpmnApplication().run(params);
	}

}