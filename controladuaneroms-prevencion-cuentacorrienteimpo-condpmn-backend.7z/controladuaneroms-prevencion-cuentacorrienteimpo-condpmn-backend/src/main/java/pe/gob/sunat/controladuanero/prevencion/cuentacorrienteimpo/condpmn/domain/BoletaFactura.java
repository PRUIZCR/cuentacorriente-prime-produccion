/***********************************************************************
 * Module:  BoletaFactura.java
 * Author:  rcontreras
 * Purpose: Defines the Class BoletaFactura
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.common.DataCatalogo;

public class BoletaFactura extends ComprobantePago implements java.io.Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -6602253987456362133L;
	private String numSerie;
	private String numComprobante;
	private String numRuc;
	private DataCatalogo tipoDocAdquiriente;
	private String nomAdquiriente;

	public String getNumSerie() {
		return numSerie;
	}

	/** @param newNumSerie */
	public void setNumSerie(String newNumSerie) {
		numSerie = newNumSerie;
	}

	public String getNumComprobante() {
		return numComprobante;
	}

	/** @param newNumComprobante */
	public void setNumComprobante(String newNumComprobante) {
		numComprobante = newNumComprobante;
	}

	public String getNumRuc() {
		return numRuc;
	}

	/** @param newNumRuc */
	public void setNumRuc(String newNumRuc) {
		numRuc = newNumRuc;
	}

	public DataCatalogo getTipoDocAdquiriente() {
		return tipoDocAdquiriente;
	}

	/** @param newTipoDocAdquiriente */
	public void setTipoDocAdquiriente(DataCatalogo newTipoDocAdquiriente) {
		tipoDocAdquiriente = newTipoDocAdquiriente;
	}

	public String getNomAdquiriente() {
		return nomAdquiriente;
	}

	/** @param newNomAdquiriente */
	public void setNomAdquiriente(String newNomAdquiriente) {
		nomAdquiriente = newNomAdquiriente;
	}

}