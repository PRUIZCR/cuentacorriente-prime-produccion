package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.repository.mongodb;

import java.util.ArrayList;
import java.util.List;

import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Filters;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.DamSerieDpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.repository.DamSerieDpmnRepository;
import pe.gob.sunat.tecnologia.arquitectura.framework.mongodb.client.MongoDBClient;

public class DamSerieDpmnMongoDBImpl implements DamSerieDpmnRepository{
	
	public static final String DC_CUENTA_CORRIENTE = "dcctecorrienteimpo";

	@Override
	public List<DamSerieDpmn> buscarPorNumCorreDpmn(Long numCorreDpmn) {
		List<DamSerieDpmn> lstDamSerieDpmn = new ArrayList<DamSerieDpmn>();
		MongoCollection<DamSerieDpmn> collection = MongoDBClient.getCollection(DC_CUENTA_CORRIENTE, "damSeriesDpmn", DamSerieDpmn.class);		
		FindIterable<DamSerieDpmn> findIterable = collection.find(Filters.and(Filters.eq("numCorreDpmn", numCorreDpmn), Filters.not(Filters.eq("indEliminado", true))));
		
		for (DamSerieDpmn damSerieDpmn : findIterable) {
			lstDamSerieDpmn.add(damSerieDpmn);
		}
		
		return lstDamSerieDpmn;
	}

}
