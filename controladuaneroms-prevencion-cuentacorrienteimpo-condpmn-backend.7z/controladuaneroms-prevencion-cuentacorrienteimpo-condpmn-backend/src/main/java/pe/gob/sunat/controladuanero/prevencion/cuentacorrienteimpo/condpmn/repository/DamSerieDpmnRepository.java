package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.repository;

import java.util.List;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.DamSerieDpmn;

public interface DamSerieDpmnRepository {
	List<DamSerieDpmn> buscarPorNumCorreDpmn(Long numCorreDpmn);
}
