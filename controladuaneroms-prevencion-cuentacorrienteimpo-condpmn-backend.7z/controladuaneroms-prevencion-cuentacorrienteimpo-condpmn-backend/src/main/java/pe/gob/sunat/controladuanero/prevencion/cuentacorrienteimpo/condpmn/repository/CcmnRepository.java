/***********************************************************************
 * Module:  CcmnRepository.java
 * Author:  anoriega
 * Purpose: Defines the Interface CcmnRepository
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.repository;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.Ccmn;

public interface CcmnRepository {
	
	/** @param numCorrelativo */
	public Ccmn consultarCcmn(Long numCorrelativo);

}