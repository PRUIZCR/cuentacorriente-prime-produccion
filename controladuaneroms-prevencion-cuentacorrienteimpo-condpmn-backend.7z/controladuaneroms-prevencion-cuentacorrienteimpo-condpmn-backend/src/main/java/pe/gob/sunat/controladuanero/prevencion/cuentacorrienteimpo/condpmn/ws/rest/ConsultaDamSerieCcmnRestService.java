/***********************************************************************
 * Module:  ConsultaDamSerieCcmnRestService.java
 * Author:  anoriega
 * Purpose: Defines the Class ConsultaDamSerieCcmnRestService
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.ws.rest;

import javax.ws.rs.core.Response;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.Ccmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.DamSerieCcmn;
import pe.gob.sunat.tecnologiams.arquitectura.framework.microservices.model.bean.MensajeBean;
import pe.gob.sunat.tecnologiams.arquitectura.framework.microservices.util.ConstantesUtils;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/v1/controladuanero/prevencion/cuentacorrienteimpo")
public class ConsultaDamSerieCcmnRestService extends DpmnCcmnAbstractRest {

	/** @param numCorrelativoCcmn */
	@GET
	@Path("/e/ccmns/{numCorreCcmn}/damseriesccmn")
	@Produces({ MediaType.APPLICATION_JSON })
	public Response buscarPorNumCorreCcmn(@PathParam("numCorreCcmn") Long numCorreCcmn) {
		MensajeBean msjBean = new MensajeBean();
		try {
			Ccmn ccmn = this.consultaDeCcmnService.consultarCcmn(numCorreCcmn);

			if (ccmn == null) {
				msjBean = new MensajeBean();
				msjBean.setCod(1);
				msjBean.setMsg("No se ha encontrado CCMN con el correlativo ingresado");
				return Response.status(COD_ERROR_VALIDACION).entity(msjBean)
						.type(MediaType.APPLICATION_JSON_TYPE.withCharset("utf-8")).build();
			}

			List<DamSerieCcmn> lstSerieCcmn = this.consultaDamSerieCcmnService.buscarPorNumCorreCcmn(numCorreCcmn);

			if (lstSerieCcmn == null || lstSerieCcmn.isEmpty()) {
				msjBean = new MensajeBean();
				msjBean.setCod(1);
				msjBean.setMsg("No se ha encontrado series con el correlativo indicado");
				return Response.status(COD_ERROR_VALIDACION).entity(msjBean)
						.type(MediaType.APPLICATION_JSON_TYPE.withCharset("utf-8")).build();
			}

			return Response.ok(lstSerieCcmn).build();

		} catch (java.lang.Exception ex) {
			utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, "Ha ocurrido un error al buscar los ccmn",
					ex.getStackTrace());
			msjBean = new MensajeBean();
			msjBean.setCod(1);
			msjBean.setMsg("Ha ocurrido un error al buscar las series del dpmn");
			return Response.status(COD_ERROR_VALIDACION).entity(msjBean)
					.type(MediaType.APPLICATION_JSON_TYPE.withCharset("utf-8")).build();
		}
	}

}