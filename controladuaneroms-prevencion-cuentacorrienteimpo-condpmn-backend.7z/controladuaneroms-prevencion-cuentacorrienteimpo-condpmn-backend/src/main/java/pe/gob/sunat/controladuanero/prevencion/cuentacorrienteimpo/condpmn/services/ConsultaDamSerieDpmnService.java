package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.services;

import java.util.List;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.DamSerieDpmn;

public interface ConsultaDamSerieDpmnService {
	/**
	 * Obtiene las series de la dpmn
	 * @param numCorreDpmn
	 * @return
	 */
	List<DamSerieDpmn> buscarPorNumCorreDpmn(Long numCorreDpmn);
}
