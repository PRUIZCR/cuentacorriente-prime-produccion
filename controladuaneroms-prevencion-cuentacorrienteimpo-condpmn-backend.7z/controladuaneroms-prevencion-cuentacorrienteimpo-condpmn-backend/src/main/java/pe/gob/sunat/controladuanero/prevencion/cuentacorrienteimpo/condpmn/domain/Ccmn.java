/***********************************************************************
 * Module:  Ccmn.java
 * Author:  anoriega
 * Purpose: Defines the Class Ccmn
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.common.Auditoria;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.common.DataCatalogo;

public class Ccmn implements java.io.Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -2145681480668933372L;
	/**
	 * <p>
	 * N&uacute;mero correlativo &uacute;nico
	 * </p>
	 */
	private Long numCorrelativo;
	/**
	 * <p>
	 * Aduana, con el valor de la aduana de descarga
	 * </p>
	 */
	private DataCatalogo aduana;
	private DataCatalogo puestoControl;
	/**
	 * <p>
	 * A&ntilde;o, con el valor del a&ntilde;o actual
	 * </p>
	 */
	private Integer annCcmn;
	/**
	 * <p>
	 * N&uacute;mero de CCMN
	 * </p>
	 */
	private Integer numCcmn;
	private Date fecCcmn;
	private DataCatalogo estado;
	private DataCatalogo aduanaDescarga;
	private DataCatalogo puestoControlDescarga;
	/**
	 * Indica el m�dulo a trav�s del cual se raliza el registro. Puede ser portal
	 * del funcionario aduanero o aplicativo m�vil.
	 */
	private DataCatalogo moduloRegistro;
	private String codVariableControl;
	private Auditoria auditoria;
	private Long numCorrelativoDpmn;
	private String nomFuncionarioAduanero;
	private Integer cntDamSeries;
	private Integer cntAdjuntos;

	private DatoComplementario datoComplementario;
	private EmpresaTransporte empresaTransporte;
	private Conductor conductor;
	private List<ComprobantePago> comprobantePago;
	private Responsable responsable;

	/** @pdGenerated default parent getter */
	public DatoComplementario getDatoComplementario() {
		return datoComplementario;
	}

	/**
	 * @pdGenerated default parent setter
	 * @param newDatoComplementario
	 */
	public void setDatoComplementario(DatoComplementario newDatoComplementario) {
		this.datoComplementario = newDatoComplementario;
	}

	/** @pdGenerated default parent getter */
	public EmpresaTransporte getEmpresaTransporte() {
		return empresaTransporte;
	}

	/**
	 * @pdGenerated default parent setter
	 * @param newEmpresaTransporte
	 */
	public void setEmpresaTransporte(EmpresaTransporte newEmpresaTransporte) {
		this.empresaTransporte = newEmpresaTransporte;
	}

	/** @pdGenerated default parent getter */
	public Conductor getConductor() {
		return conductor;
	}

	/**
	 * @pdGenerated default parent setter
	 * @param newConductor
	 */
	public void setConductor(Conductor newConductor) {
		this.conductor = newConductor;
	}

	/** @pdGenerated default getter */
	public List<ComprobantePago> getComprobantePago() {
		if (comprobantePago == null)
			comprobantePago = new ArrayList<ComprobantePago>();
		return comprobantePago;
	}

	/**
	 * @pdGenerated default setter
	 * @param newComprobantePago
	 */
	public void setComprobantePago(List<ComprobantePago> newComprobantePago) {
		removeAllComprobantePago();
		for (Iterator<ComprobantePago> iter = newComprobantePago.iterator(); iter.hasNext();)
			addComprobantePago((ComprobantePago) iter.next());
	}

	/**
	 * @pdGenerated default add
	 * @param newComprobantePago
	 */
	public void addComprobantePago(ComprobantePago newComprobantePago) {
		if (newComprobantePago == null)
			return;
		if (this.comprobantePago == null)
			this.comprobantePago = new ArrayList<ComprobantePago>();
		if (!this.comprobantePago.contains(newComprobantePago))
			this.comprobantePago.add(newComprobantePago);
	}

	/**
	 * @pdGenerated default remove
	 * @param oldComprobantePago
	 */
	public void removeComprobantePago(ComprobantePago oldComprobantePago) {
		if (oldComprobantePago == null)
			return;
		if (this.comprobantePago != null && this.comprobantePago.contains(oldComprobantePago))
			this.comprobantePago.remove(oldComprobantePago);
	}

	/** @pdGenerated default removeAll */
	public void removeAllComprobantePago() {
		if (comprobantePago != null)
			comprobantePago.clear();
	}

	public Long getNumCorrelativo() {
		return numCorrelativo;
	}

	/** @param newNumCorrelativo */
	public void setNumCorrelativo(Long newNumCorrelativo) {
		numCorrelativo = newNumCorrelativo;
	}

	public DataCatalogo getAduana() {
		return aduana;
	}

	/** @param newAduana */
	public void setAduana(DataCatalogo newAduana) {
		aduana = newAduana;
	}

	public Integer getAnnCcmn() {
		return annCcmn;
	}

	/** @param newAnnCcmn */
	public void setAnnCcmn(Integer newAnnCcmn) {
		annCcmn = newAnnCcmn;
	}

	public Integer getNumCcmn() {
		return numCcmn;
	}

	/** @param newNumCcmn */
	public void setNumCcmn(Integer newNumCcmn) {
		numCcmn = newNumCcmn;
	}

	public Date getFecCcmn() {
		return fecCcmn;
	}

	/** @param newFecCcmn */
	public void setFecCcmn(Date newFecCcmn) {
		fecCcmn = newFecCcmn;
	}

	public DataCatalogo getEstado() {
		return estado;
	}

	/** @param newEstado */
	public void setEstado(DataCatalogo newEstado) {
		estado = newEstado;
	}

	public DataCatalogo getAduanaDescarga() {
		return aduanaDescarga;
	}

	/** @param newAduanaDescarga */
	public void setAduanaDescarga(DataCatalogo newAduanaDescarga) {
		aduanaDescarga = newAduanaDescarga;
	}

	public DataCatalogo getPuestoControlDescarga() {
		return puestoControlDescarga;
	}

	/** @param newPuestoControlDescarga */
	public void setPuestoControlDescarga(DataCatalogo newPuestoControlDescarga) {
		puestoControlDescarga = newPuestoControlDescarga;
	}

	public DataCatalogo getModuloRegistro() {
		return moduloRegistro;
	}

	/** @param newModuloRegistro */
	public void setModuloRegistro(DataCatalogo newModuloRegistro) {
		moduloRegistro = newModuloRegistro;
	}

	public String getCodVariableControl() {
		return codVariableControl;
	}

	/** @param newCodVariableControl */
	public void setCodVariableControl(String newCodVariableControl) {
		codVariableControl = newCodVariableControl;
	}

	public Auditoria getAuditoria() {
		return auditoria;
	}

	/** @param newAuditoria */
	public void setAuditoria(Auditoria newAuditoria) {
		auditoria = newAuditoria;
	}

	/** @pdGenerated default parent getter */
	public Responsable getResponsable() {
		return responsable;
	}

	/**
	 * @pdGenerated default parent setter
	 * @param newResponsable
	 */
	public void setResponsable(Responsable newResponsable) {
		this.responsable = newResponsable;
	}

	public DataCatalogo getPuestoControl() {
		return puestoControl;
	}

	public void setPuestoControl(DataCatalogo puestoControl) {
		this.puestoControl = puestoControl;
	}

	public Long getNumCorrelativoDpmn() {
		return numCorrelativoDpmn;
	}

	public void setNumCorrelativoDpmn(Long numCorrelativoDpmn) {
		this.numCorrelativoDpmn = numCorrelativoDpmn;
	}

	public String getNomFuncionarioAduanero() {
		return nomFuncionarioAduanero;
	}

	public void setNomFuncionarioAduanero(String nomFuncionarioAduanero) {
		this.nomFuncionarioAduanero = nomFuncionarioAduanero;
	}

	public Integer getCntDamSeries() {
		return cntDamSeries;
	}

	public void setCntDamSeries(Integer cntDamSeries) {
		this.cntDamSeries = cntDamSeries;
	}

	public Integer getCntAdjuntos() {
		return cntAdjuntos;
	}

	public void setCntAdjuntos(Integer cntAdjuntos) {
		this.cntAdjuntos = cntAdjuntos;
	}

}