package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.main.config;

import pe.gob.sunat.tecnologia.arquitectura.framework.mongodb.config.MongoDBConfig;
import pe.gob.sunat.tecnologiams.arquitectura.framework.microservices.config.MicroserviceConfig;

public class ConsultaDpmnConfig extends MicroserviceConfig {

	private static ConsultaDpmnConfig config;
	private MongoDBConfig mongodb;

	public static ConsultaDpmnConfig getConfig() {
		return config;
	}

	public static void loadConfig(ConsultaDpmnConfig newInstance) {
		ConsultaDpmnConfig.config = newInstance;
	}

	public MongoDBConfig getMongodb() {
		return mongodb;
	}

	public void setMongodb(MongoDBConfig mongodb) {
		this.mongodb = mongodb;
	}
}
