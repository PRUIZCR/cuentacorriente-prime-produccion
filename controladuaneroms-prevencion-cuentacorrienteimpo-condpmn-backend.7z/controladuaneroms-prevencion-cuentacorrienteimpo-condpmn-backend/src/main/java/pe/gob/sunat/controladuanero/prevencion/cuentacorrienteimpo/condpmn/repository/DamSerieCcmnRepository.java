/***********************************************************************
 * Module:  DamSerieCcmnRepository.java
 * Author:  anoriega
 * Purpose: Defines the Interface DamSerieCcmnRepository
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.repository;

import java.util.List;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.DamSerieCcmn;

public interface DamSerieCcmnRepository {
	/** @param numCorreCcmn */
	List<DamSerieCcmn> buscarPorNumCorreCcmn(Long numCorreCcmn);

}