/***********************************************************************
 * Module:  ConsultaDeDpmnService.java
 * Author:  anoriega
 * Purpose: Defines the Interface ConsultaDeDpmnService
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.services;

import java.util.*;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.ConsultaDpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.Dpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.DpmnResumen;
import pe.gob.sunat.tecnologiams.arquitectura.framework.microservices.model.bean.MensajeBean;

public interface ConsultaDeDpmnService {
	/**
	 * Devuelve un listado de DPMN de acuerdo a los parámetros
	 * 
	 * @param parametros
	 */
	List<DpmnResumen> listarDPMNs(ConsultaDpmn parametros);

	/** @param parametros */
	Byte[] exportarListaDPMNsAExcel(ConsultaDpmn parametros) throws Exception;

	/** @param parametros */
	Byte[] exportarListaDPMNsAPdf(ConsultaDpmn parametros) throws Exception;

	/** @param parametro */
	Dpmn consultarDmpn(Long idDpmn);

	/** @param parametros */
	List<MensajeBean> validarParametrosDeConsulta(ConsultaDpmn parametros);

}