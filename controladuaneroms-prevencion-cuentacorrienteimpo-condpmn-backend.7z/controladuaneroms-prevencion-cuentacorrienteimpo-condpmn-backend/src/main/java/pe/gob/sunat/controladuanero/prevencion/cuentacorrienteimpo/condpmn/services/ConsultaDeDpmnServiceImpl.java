/***********************************************************************
 * Module:  ConsultaDeDpmnServiceImpl.java
 * Author:  anoriega
 * Purpose: Defines the Class ConsultaDeDpmnServiceImpl
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.services;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.repository.DpmnRepository;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.util.MensajeUtil;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.util.ReporteUtil;
import pe.gob.sunat.tecnologiams.arquitectura.framework.microservices.model.bean.MensajeBean;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.ConsultaDpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.Dpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.DpmnResumen;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.inject.Inject;
import javax.ws.rs.core.StreamingOutput;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;

public class ConsultaDeDpmnServiceImpl implements ConsultaDeDpmnService {

	@Inject
	public DpmnRepository respositorioDpmn;
	
	@Inject
	private ReporteUtil reporteUtil;

	
	/**
	 * Setea a null los parametros que no correspondan
	 * @param parametros
	 * @return
	 */
	private ConsultaDpmn limpiarParametrosDeConsulta(ConsultaDpmn parametros) {
		if(!BooleanUtils.isTrue(parametros.getIndicadorPorDeclaracion())) {
			parametros.setAduanaDeDeclaracion(null);
			parametros.setAnoDeDeclaracion(null);
			parametros.setRegimenDeDeclaracion(null);
			parametros.setNumeroDeDeclaracion(null);
		}			
			
		if(!BooleanUtils.isTrue(parametros.getIndicadorPorDocumento())) {
			parametros.setAduanaDeDescarga(null);
			parametros.setPuestoDeControlDescarga(null);
			parametros.setAnoDeDescarga(null);
			parametros.setNumeroDeDescarga(null);
		}
			
		if(!BooleanUtils.isTrue(parametros.getIndicadorPorFecha())) {
			parametros.setFechaDeInicioConsulta(null);
			parametros.setFechaFinConsulta(null);
		}
		
		return parametros;
	}


	/**
	 * Servicio que obtiene la coleccion DPMN con los parametros enviados
	 */
	public List<DpmnResumen> listarDPMNs(ConsultaDpmn parametros) {
		this.limpiarParametrosDeConsulta(parametros);
		return respositorioDpmn.listarDPMNs(parametros);
	}

	/** @param parametros */
	public List<MensajeBean> validarParametrosDeConsulta(ConsultaDpmn parametros) {
		List<MensajeBean> lstMsj = new ArrayList<MensajeBean>();
		MensajeBean msj = new MensajeBean();
		
		/*Valida que solo se envie un indicador con valor true*/
		if(!this.cumpleValidacionIndicadores(parametros)) {
			msj = MensajeUtil.addError("Debe ingresar un solo criterio de consulta");
			lstMsj.add(msj);
			return lstMsj;
		}else {
			if(BooleanUtils.isTrue(parametros.getIndicadorPorDocumento()) && !this.cumpleDatosIndicadorPorDocumento(parametros)) {
				msj = MensajeUtil.addError("Debe ingresar los datos del documento de descarga a consultar");
				lstMsj.add(msj);
				return lstMsj;
			}
			
			if(BooleanUtils.isTrue(parametros.getIndicadorPorDeclaracion()) && !this.cumpleDatosIndicadorPorDeclaracion(parametros)) {
				msj = MensajeUtil.addError("Debe ingresar todos los datos de la declaraci\u00F3n");
				lstMsj.add(msj);
				return lstMsj;
			}
		
			if(BooleanUtils.isTrue(parametros.getIndicadorPorFecha())) {
				msj = this.cumpleDatosIndicadorPorFecha(parametros);
				if(msj!=null)
					lstMsj.add(msj);
			}			
		}
		
		return lstMsj;
	}

	/**
	 * Valida que si es indicador por Fecha, se envien los datos fecha de inicio y fin, y ademas que no superen los 30 dias
	 * @param parametros
	 * @return
	 */
	private MensajeBean cumpleDatosIndicadorPorFecha(ConsultaDpmn parametros) {
		
		if(parametros.getFechaDeInicioConsulta()==null || parametros.getFechaFinConsulta()==null)
			return MensajeUtil.addError("Debe ingresar el rango de fechas a consultar");
		
		long diffInMillies = Math.abs(parametros.getFechaFinConsulta().getTime() - parametros.getFechaDeInicioConsulta().getTime());		
	    long days = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
	    
	    if(days>30)
	    	return MensajeUtil.addError("Rango de Fecha a consultar no puede ser mayor a 30 d\u00EDas");
	
		return null;
	}

	/**
	 * Valida que si es indicador por declaracion, se env�e los datos de la aduana, a�o, r�gimen y n�mero de declaraci�n
	 * @param parametros
	 * @return
	 */
	private boolean cumpleDatosIndicadorPorDeclaracion(ConsultaDpmn parametros) {
		if(parametros.getAduanaDeDeclaracion()==null || !StringUtils.isNotBlank(parametros.getAduanaDeDeclaracion().getCodDatacat()))
			return false;
		
		if(parametros.getAnoDeDeclaracion()==null || parametros.getAnoDeDeclaracion()==0)
			return false;
		
		if(parametros.getRegimenDeDeclaracion()==null || !StringUtils.isNotBlank(parametros.getRegimenDeDeclaracion().getCodDatacat()))
			return false;
		
		if(parametros.getNumeroDeDeclaracion()==null || parametros.getNumeroDeDeclaracion() == 0)
			return false;
		
		return true;
	}

	/**
	 * Valida que si es indicador por documento, se env�e los datos de la aduana, a�o y numero de documento de descarga
	 * @param parametros
	 * @return
	 */
	private boolean cumpleDatosIndicadorPorDocumento(ConsultaDpmn parametros) {
		if(parametros.getAduanaDeDescarga()==null || !StringUtils.isNotBlank(parametros.getAduanaDeDescarga().getCodDatacat()))
			return false;
		
		if(parametros.getAnoDeDescarga()==null || parametros.getAnoDeDescarga()==0)
			return false;
		
		if(parametros.getNumeroDeDescarga()==null || parametros.getNumeroDeDescarga()==0)
			return false;
		
		return true;
	}

	/**
	 * Verifica si hay mas de un indicador de busqueda habilitado
	 * @param parametros
	 * @return
	 */
	private boolean cumpleValidacionIndicadores(ConsultaDpmn parametros) {
		int i = 0;
		
		if (BooleanUtils.isTrue(parametros.getIndicadorPorDeclaracion()))
			i++;
		
		if (BooleanUtils.isTrue(parametros.getIndicadorPorDocumento()))
			i++;
		
		if (BooleanUtils.isTrue(parametros.getIndicadorPorFecha()))
			i++;
		
		if(i!=1)
			return false;
		
		return true;
	}

	/**
	 * Genera el archivo excel con la lista de dpmns
	 */
	public Byte[] exportarListaDPMNsAExcel(ConsultaDpmn parametros) throws Exception {
		List<DpmnResumen> lstDpmns = this.listarDPMNs(parametros);
		
		if(lstDpmns==null || lstDpmns.isEmpty())
			return null;

		StreamingOutput output = reporteUtil.generaReporteXls(lstDpmns);
		
		ByteArrayOutputStream byteOutput = new ByteArrayOutputStream();
		output.write(byteOutput);
		
		byte[] bytes = byteOutput.toByteArray();

		return ArrayUtils.toObject(bytes);
	}

	/**
	 * Genera el archivo pdf con la lista de dpmns
	 */
	public Byte[] exportarListaDPMNsAPdf(ConsultaDpmn parametros) throws Exception {
		List<DpmnResumen> lstDpmns = this.listarDPMNs(parametros);
		
		if(lstDpmns==null || lstDpmns.isEmpty())
			return null;
		
		byte[] bytes = reporteUtil.generaReportePDF(lstDpmns);
		
		return ArrayUtils.toObject(bytes);
	}

	/**
	 * Consulta la DPMN por numero de correlativo
	 */
	public Dpmn consultarDmpn(Long idDpmn) {
		return respositorioDpmn.consultarDpmn(idDpmn);
	}

	/** @pdGenerated default parent getter */
	public DpmnRepository getRespositorioDpmn() {
		return respositorioDpmn;
	}

	/**
	 * @pdGenerated default parent setter
	 * @param newDpmnRepository
	 */
	public void setRespositorioDpmn(DpmnRepository newDpmnRepository) {
		this.respositorioDpmn = newDpmnRepository;
	}

}