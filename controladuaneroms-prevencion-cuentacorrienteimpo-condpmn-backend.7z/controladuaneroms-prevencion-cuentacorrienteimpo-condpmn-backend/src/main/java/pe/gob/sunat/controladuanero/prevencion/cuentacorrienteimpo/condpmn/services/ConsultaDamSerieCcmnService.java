/***********************************************************************
 * Module:  ConsultaDamSerieCcmnService.java
 * Author:  anoriega
 * Purpose: Defines the Interface ConsultaDamSerieCcmnService
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.services;

import java.util.List;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.DamSerieCcmn;

public interface ConsultaDamSerieCcmnService {
	
	/** @param numCorreCcmn */
	List<DamSerieCcmn> buscarPorNumCorreCcmn(Long numCorreCcmn);

}