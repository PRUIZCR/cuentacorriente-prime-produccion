package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.util;

import java.sql.Timestamp;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class FechaBean {

	private static final long serialVersionUID = -8770487627374010757L;
	private Calendar cal;
	public static String FORMATO_DEFAULT = "dd/MM/yyyy";

	/**
	 * Constructor basico, utiliza directamente el Calendar para obtener la
	 * fecha del dia.
	 *
	 */
	public FechaBean() {
		cal = Calendar.getInstance();
	}

	/**
	 * Construye un Calendar con el objeto fecha
	 * 
	 * @param fecha
	 *            java.sql.Date
	 */
	public FechaBean(java.sql.Date fecha) {
		cal = Calendar.getInstance();
		setFecha(fecha);
	}

	/**
	 * Construye un Calendar con el objeto fecha
	 * 
	 * @param fecha
	 *            java.sql.Timestamp
	 */
	public FechaBean(Timestamp fecha) {
		cal = Calendar.getInstance();
		setFecha(fecha);
	}

	/**
	 * Construye un Calendar con el objeto fecha
	 * 
	 * @param fecha
	 *            String
	 */
	public FechaBean(String fecha) {
		cal = Calendar.getInstance();
		setFecha(fecha);
	}

	/**
	 * Construye un Calendar con el objeto fecha, el parametro fmt indica el
	 * formato de fecha en que viene la cadena fecha.
	 * 
	 * @param fecha
	 *            String
	 * @param fmt
	 *            String
	 */
	public FechaBean(String fecha, String fmt) {
		cal = Calendar.getInstance();
		setFecha(fecha, fmt);
	}

	/**
	 * Construye un Calendar con el objeto fecha, el parametro fmt indica el
	 * formato de fecha en que viene la cadena fecha.
	 * 
	 * @param fecha
	 *            String
	 * @param fmt
	 *            String
	 * @param lenient
	 *            boolean
	 */
	public FechaBean(String fecha, String fmt, boolean lenient) {
		cal = Calendar.getInstance();
		setFecha(fecha, fmt, lenient);
	}

	/**
	 * setter
	 * 
	 * @param fecha
	 *            java.sql.Date
	 */
	public void setFecha(java.sql.Date fecha) {
		this.cal.setTime(fecha);
	}

	/**
	 * setter
	 * 
	 * @param fecha
	 *            java.util.Date
	 */
	public void setFecha(java.util.Date fecha) {
		this.cal.setTime(fecha);
	}

	/**
	 * setter
	 * 
	 * @param fecha
	 *            java.sql.Timestamp
	 */
	public void setFecha(Timestamp fecha) {
		this.cal.setTime(fecha);
	}

	/**
	 * setter asume el formato fecha como dd/MM/yyyy
	 * 
	 * @param fecha
	 *            String
	 */
	public void setFecha(String fecha) {
		setFecha(fecha, FORMATO_DEFAULT);
	}

	/**
	 * setter
	 * 
	 * @param fecha
	 *            String
	 * @param formato
	 *            String
	 */
	public void setFecha(String fecha, String formato) {
		setFecha(fecha, formato, true);
	}

	/**
	 * setter, el parametro lenient me permite validar que el valor contenido en
	 * el parametro fecha pueda ser convertido segun el parametro formato. Si el
	 * valor es true intentara convertirlo a fecha de todas maneras, en caso de
	 * ser false, si no cumple el formato lanza la exception
	 * NullPointerException.
	 * 
	 * @param fecha
	 *            String
	 * @param formato
	 *            String
	 * @param lenient
	 *            boolean
	 */
	public void setFecha(String fecha, String formato, boolean lenient) {
		SimpleDateFormat formatter = new SimpleDateFormat(formato);
		formatter.setLenient(lenient);
		ParsePosition pos = new ParsePosition(0);
		setFecha(formatter.parse(fecha, pos));
	}

	/**
	 * obtiene el dia del mes de la fecha en formato de dos digitos
	 * 
	 * @return String
	 */
	public String getDia() {
		return ((cal.get(Calendar.DAY_OF_MONTH)) < 10 ? "0" : "")
				+ new Integer(cal.get(Calendar.DAY_OF_MONTH)).toString();
	}

	/**
	 * obtiene el numero de mes de la fecha en formato de dos digitos
	 * 
	 * @return String
	 */
	public String getMes() {
		return ((cal.get(Calendar.MONTH) + 1) < 10 ? "0" : "") + new Integer(cal.get(Calendar.MONTH) + 1).toString();
	}

	/**
	 * obtiene el a&ntilde;o de la fecha en formato de cuatro digitos
	 * 
	 * @return String
	 */
	public String getAnho() {
		return new Integer(cal.get(Calendar.YEAR)).toString();
	}

	/**
	 * retorna la hora de la fecha en formato de 24 hras
	 * 
	 * @return String
	 */
	public String getHora24() {
		return new Integer(cal.get(Calendar.HOUR_OF_DAY)).toString();
	}

	/**
	 * retorna la hora en formato de 12hras
	 * 
	 * @return String
	 */
	public String getHora() {
		return new Integer(cal.get(Calendar.HOUR)).toString();
	}

	/**
	 * retorna los minutos
	 * 
	 * @return String
	 */
	public String getMinuto() {
		return new Integer(cal.get(Calendar.MINUTE)).toString();
	}

	/**
	 * retorna los segundos
	 * 
	 * @return String
	 */
	public String getSegundo() {
		return new Integer(cal.get(Calendar.SECOND)).toString();
	}

	/**
	 * retorna los milisegundos
	 * 
	 * @return String
	 */
	public String getMiliSegundo() {
		return new Integer(cal.get(Calendar.MILLISECOND)).toString();
	}

	/**
	 * retorna el mes de la fecha del Calendar en letras
	 * 
	 * @return String
	 */
	public String getMesletras() {
		return getMesletras(cal.get(Calendar.MONTH));
	}

	/**
	 * retorna el mes en letras segun el parametro mes
	 * 
	 * @param mes
	 *            int
	 * @return String
	 */
	public String getMesletras(int mes) {
		String dmes = "---";
		switch (mes) {
		case 0:
			dmes = "Enero";
			break;
		case 1:
			dmes = "Febrero";
			break;
		case 2:
			dmes = "Marzo";
			break;
		case 3:
			dmes = "Abril";
			break;
		case 4:
			dmes = "Mayo";
			break;
		case 5:
			dmes = "Junio";
			break;
		case 6:
			dmes = "Julio";
			break;
		case 7:
			dmes = "Agosto";
			break;
		case 8:
			dmes = "Setiembre";
			break;
		case 9:
			dmes = "Octubre";
			break;
		case 10:
			dmes = "Noviembre";
			break;
		case 11:
			dmes = "Diciembre";
			break;
		}
		return dmes;
	}

	/**
	 * retorna los tres primeros caracteres del nombre del mes de la fecha en
	 * Calendar
	 * 
	 * @return String
	 */
	public String getMesletrasabr() {
		return getMesletras().substring(0, 3);
	}

	/**
	 * retorna los tres primeros caracteres del nombre del mes segun el valor
	 * del parametro mes.
	 * 
	 * @param mes
	 *            int
	 * @return String
	 */
	public String getMesletrasabr(int mes) {
		return getMesletras(mes).substring(0, 3);
	}

	/**
	 * retorna el dia de la semana en letras segun la fecha en Calendar
	 * 
	 * @return String
	 */
	public String getDiasemana() {
		return getDiasemana(cal.get(Calendar.DAY_OF_WEEK));
	}

	/**
	 * retorna el dia de la semana en letras segun el valor del parametro dia
	 * 
	 * @param dia
	 *            int
	 * @return String
	 */
	public String getDiasemana(int dia) {
		String diasemana = "---";
		switch (dia) {
		case Calendar.SUNDAY:
			diasemana = "Domingo";
			break;
		case Calendar.MONDAY:
			diasemana = "Lunes";
			break;
		case Calendar.TUESDAY:
			diasemana = "Martes";
			break;
		case Calendar.WEDNESDAY:
			diasemana = "Miercoles";
			break;
		case Calendar.THURSDAY:
			diasemana = "Jueves";
			break;
		case Calendar.FRIDAY:
			diasemana = "Viernes";
			break;
		case Calendar.SATURDAY:
			diasemana = "Sabado";
			break;
		}
		return diasemana;
	}

	/**
	 * retorna los tres primeros caracteres del dia de la semana
	 * 
	 * @return String
	 */
	public String getDiasemanaabr() {
		return getDiasemana().substring(0, 3);
	}

	/**
	 * Obtiene el maximo valor del campo Ejemplo:
	 * 
	 * <pre>
	 * 
	 * FechaBean f = new FechaBean();
	 * f.getMaximo(Calendar.DAY_OF_MONTH);
	 * </pre>
	 * 
	 * Para la fecha 01/02/2001 el maximo es 28
	 */
	public int getMaximo(int campo) {
		return cal.getActualMaximum(campo);
	}

	/**
	 * Retorna la fecha en formato java.sql.Date
	 * 
	 * @return java.sql.Date
	 */
	public java.sql.Date getSQLDate() {
		return new java.sql.Date(cal.getTime().getTime());
	}

	/**
	 * Retorna la fecha segun el formato dado. Symbol Meaning Presentation
	 * Example ------ ------- ------------ ------- G era designator (Text) AD y
	 * year (Number) 1996 M month in year (Text & Number) July & 07 (En Ingles)
	 * d day in month (Number) 10 h hour in am/pm (1~12) (Number) 12 H hour in
	 * day (0~23) (Number) 0 m minute in hour (Number) 30 s second in minute
	 * (Number) 55 S millisecond (Number) 978 E day in week (Text) Tuesday (En
	 * Ingles) D day in year (Number) 189 F day of week in month (Number) 2 (2nd
	 * Wed in July) w week in year (Number) 27 W week in month (Number) 2 a
	 * am/pm marker (Text) PM k hour in day (1~24) (Number) 24 K hour in am/pm
	 * (0~11) (Number) 0 z time zone (Text) Pacific Standard Time ' escape for
	 * text (Delimiter) '' single quote (Literal) ' caps -> Capitalize, es decir
	 * la primera letra en mayusculas y el resto en minusculas, esto se aplica
	 * para los dias y los meses may -> Mayusculas, es decir toda la palabra en
	 * mayusculas, esto se aplica para los dias y los meses Ejemplo
	 * BeanFechaHora f = new BeanFechaHora(); f.getFormatDate("dd/MM/yyyy")
	 * f.getFormatDate("dd-MM-yyyy") f.getFormatDate(
	 * "yyyy.MM.dd G 'at' hh:mm:ss z") f.getFormatDate(
	 * "yyyyy.MMMMM.dd GGG hh:mm aaa") f.getFormatDate("dd.MM.yyyy hh:mm")
	 * f.getFormatDate("EEEE.MM.yyyy hh:mm")
	 * 
	 */
	public String getFormatDate(String formato) {
		return getFormatDate(formato, false, false);
	}

	/**
	 * 
	 * @param formato
	 *            String
	 * @param caps
	 *            boolean
	 * @return String
	 */
	public String getFormatDate(String formato, boolean caps) {
		return getFormatDate(formato, caps, false);
	}

	/**
	 * Si may es true, Convierte a espanol las palabras en ingles del mes y de
	 * los dias de la semana. Si caps es true, pasa la primera letra de la
	 * palabra a mayusculas.
	 * 
	 * @param formato
	 *            String
	 * @param caps
	 *            boolean
	 * @param may
	 *            boolean
	 * @return String
	 */
	public String getFormatDate(String formato, boolean caps, boolean may) {
		// Format the current time.
		SimpleDateFormat formatter = new SimpleDateFormat(formato);
		java.util.Date fecha = cal.getTime();
		return aEspanhol(formatter.format(fecha), caps, may);
	}

	/**
	 * Devuelve la fecha convertida a la clase Calendar
	 * 
	 * @return Calendar
	 */
	public Calendar getCalendar() {
		return cal;
	}

	/**
	 * Si may es true, Convierte a espanol las palabras en ingles del mes y de
	 * los dias de la semana. Si caps es true, pasa la primera letra de la
	 * palabra a mayusculas.
	 * 
	 * @param fecha
	 *            String
	 * @param caps
	 *            boolean capitaliza
	 * @param may
	 *            boolean mayusculas
	 * @return String
	 */
	private String aEspanhol(String fecha, boolean caps, boolean may) {
		String[] diaing = { "monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday" };
		String[] diaesp = { "lunes", "martes", "miercoles", "jueves", "viernes", "sabado", "domingo" };

		String[] mesing = { "january", "february", "march", "april", "may", "june", "july", "august", "september",
				"october", "november", "december" };
		String[] mesesp = { "enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "setiembre",
				"octubre", "noviembre", "diciembre" };

		for (int i = 0; i < diaing.length; i++) {
			int p = fecha.toLowerCase().indexOf(diaing[i]);
			if (p != -1) {
				String s = caps ? capitalize(diaesp[i]) : diaesp[i];
				s = may ? s.toUpperCase() : s;
				fecha = new StringBuffer(fecha).replace(p, diaing[i].length(), s).toString();
				break;
			}
		}
		for (int i = 0; i < mesing.length; i++) {
			int p = fecha.toLowerCase().indexOf(mesing[i]);
			if (p != -1) {
				String s = caps ? capitalize(mesesp[i]) : mesesp[i];
				s = may ? s.toUpperCase() : s;
				fecha = new StringBuffer(fecha).replace(p, p + mesing[i].length(), s).toString();
				break;
			}
		}
		return fecha;
	}

	/**
	 * Pone en mayusculas la cadena.
	 * 
	 * @param cad
	 * @return String
	 */
	private String capitalize(String cad) {
		return cad.length() > 1 ? cad.substring(0, 1).toUpperCase() + cad.substring(1).toLowerCase()
				: cad.substring(0).toUpperCase();
	}

	/**
	 * Retorna un objeto Timestamp de la hora actual
	 * 
	 * @return Timestamp
	 */
	public Timestamp getTimestamp() {
		return new Timestamp(this.getSQLDate().getTime());
	}

	/**
	 * formatos validables:
	 * 
	 * dd MM yy yyyy
	 * 
	 * @param fecha
	 * @param fmt
	 * @return boolean true de ser cumplir con el formato o false en caso
	 *         contrario
	 */
	public static boolean validaFormato(String fecha, String fmt) {
		boolean ok = true;
		int m = 0, a = 0, d = 0, p = 0;
		if (fecha.length() != fmt.length())
			return false;

		if (fecha.length() == 10) {
			p = fmt.indexOf("yyyy");
		} else {
			p = fmt.indexOf("yy");
		}
		if (p != -1) {
			String yy = fecha.substring(p, p + (fecha.length() == 10 ? "yyyy" : "yy").length());
			try {
				a = Integer.parseInt(yy);
			} catch (NumberFormatException e) {
				ok = false;
			}
		}
		if (ok) {
			p = fmt.indexOf("MM");
			if (p != -1) {
				String mm = fecha.substring(p, p + "MM".length());
				try {
					m = Integer.parseInt(mm);
					if (m < 1 || m > 12)
						ok = false;
				} catch (NumberFormatException e) {
					ok = false;
				}
			}
			if (ok) {
				p = fmt.indexOf("dd");
				if (p != -1) {
					String dd = fecha.substring(p, p + "dd".length());
					try {
						d = Integer.parseInt(dd);
						if (m == 4 || m == 6 || m == 9 || m == 11) {
							if (d == 31)
								ok = false;
						}
						if (m == 2) {
							int g = a % 4;
							if (d > 29)
								ok = false;
							if (d == 29 && g != 0)
								ok = false;
						}
					} catch (NumberFormatException e) {
						ok = false;
					}
				}
			}
		}
		return ok;
	}

	/**
	 * Obtiene una nueva fecha para adelante o atras, segun el valor positivo o
	 * negativo de tiempo. Y el tipo de incremento lo da el parametro
	 * tipotiempo, pudiendo avanzar en dias, minutos, meses, etc.
	 * 
	 * @param fecha
	 *            String
	 * @param tiempo
	 *            int numero de unidades a incrementar (si es negativo
	 *            decrementa)
	 * @param tipotiempo
	 *            int (ver Calendar)
	 * @return String , fecha formateada en dd/MM/yyyy
	 */
	public String getOtraFecha(String fecha, int tiempo, int tipotiempo) {
		return getOtraFecha(fecha, FORMATO_DEFAULT, tiempo, tipotiempo);
	}

	/**
	 * Obtiene una nueva fecha para adelante o atras, segun el valor positivo o
	 * negativo de tiempo. Y el tipo de incremento lo da el parametro
	 * tipotiempo, pudiendo avanzar en dias, minutos, meses, etc.
	 * 
	 * @param fecha
	 *            String
	 * @param formatosalida
	 *            String (ver getFormatDate)
	 * @param tiempo
	 *            int numero de unidades a incrementar (si es negativo
	 *            decrementa)
	 * @param tipotiempo
	 *            int (ver Calendar)
	 * @return String , fecha formateada segun el valor en formatosalida
	 */
	public String getOtraFecha(String fecha, String formatosalida, int tiempo, int tipotiempo) {
		setFecha(fecha);
		cal.add(tipotiempo, tiempo);
		return getFormatDate(formatosalida);
	}

	/**
	 * Obtiene la diferencia entre 2 fechas (f1-f2), retornando el valor basado
	 * en las unidades dadas por tipotiempo. En la diferencia de meses se asume
	 * que el mes tiene 30 dias.
	 * 
	 * @param f1
	 *            Calendar fecha mayor
	 * @param f2
	 *            Calendar fecha menor
	 * @param tipotiempo
	 *            int, vease en las unidades de Calendar: YEAR, MONTH, DATE,
	 *            HOUR, MINUTE, SECOND y MILLISECOND
	 * @return long
	 */
	public static long getDiferencia(Calendar f1, Calendar f2, int tipotiempo) {
		long msecs = f1.getTime().getTime() - f2.getTime().getTime();

		if (tipotiempo == Calendar.YEAR)
			return calcAnhos(f1, f2);
		else if (tipotiempo == Calendar.MONTH)
			return calcMeses(f1, f2);
		else if (tipotiempo == Calendar.DATE)
			return calcDias(msecs);
		else if (tipotiempo == Calendar.HOUR)
			return calcHoras(msecs);
		else if (tipotiempo == Calendar.MINUTE)
			return calcMinutos(msecs);
		else if (tipotiempo == Calendar.SECOND)
			return calcSegundos(msecs);
		else if (tipotiempo == Calendar.MILLISECOND)
			return calcMilisegundos(msecs);
		return msecs;
	}

	/**
	 * Devuelve verdadero si la fecha f3 esta entre f1 y f2, en caso contrario
	 * devuelve falso.
	 * 
	 * @param f1
	 *            Calendar, fecha inicio
	 * @param f2
	 *            Calendar, fecha final
	 * @param f3
	 *            Calendar, fecha que se quiere saber si esta entre f1 y f2
	 * @return boolean
	 */
	public static boolean estaEntre(Calendar f1, Calendar f2, Calendar f3) {
		return (f3.after(f1) && f3.before(f2));
	}

	private static long calcMilisegundos(long val) {
		return val;
	}

	private static long calcSegundos(long val) {
		return calcMilisegundos(val) / 1000;
	}

	private static long calcMinutos(long val) {
		return calcSegundos(val) / 60;
	}

	private static long calcHoras(long val) {
		return calcMinutos(val) / 60;
	}

	private static long calcDias(long val) {
		return calcHoras(val) / 24;
	}

	private static long calcMeses(Calendar f1, Calendar f2) {
		Calendar f3 = Calendar.getInstance();
		f3.setTimeInMillis(f2.getTimeInMillis());
		int a = 0;

		f3.add(Calendar.MONTH, 1);
		while (f3.before(f1) || f3.equals(f1)) {
			a++;
			f3.add(Calendar.MONTH, 1);
		}

		return a;
	}

	private static long calcAnhos(Calendar f1, Calendar f2) {
		return calcMeses(f1, f2) / 12;
	}
}
