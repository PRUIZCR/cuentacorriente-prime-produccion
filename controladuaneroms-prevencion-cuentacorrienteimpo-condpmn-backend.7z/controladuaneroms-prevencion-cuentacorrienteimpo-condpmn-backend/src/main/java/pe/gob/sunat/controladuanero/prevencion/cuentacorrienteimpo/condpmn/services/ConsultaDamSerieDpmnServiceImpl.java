package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.services;

import java.util.List;

import javax.inject.Inject;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.DamSerieDpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.repository.DamSerieDpmnRepository;

public class ConsultaDamSerieDpmnServiceImpl implements ConsultaDamSerieDpmnService {
	
	@Inject
	DamSerieDpmnRepository serieDpmnRepository;

	@Override
	public List<DamSerieDpmn> buscarPorNumCorreDpmn(Long numCorreDpmn) {
		return serieDpmnRepository.buscarPorNumCorreDpmn(numCorreDpmn) ;
	}

}
