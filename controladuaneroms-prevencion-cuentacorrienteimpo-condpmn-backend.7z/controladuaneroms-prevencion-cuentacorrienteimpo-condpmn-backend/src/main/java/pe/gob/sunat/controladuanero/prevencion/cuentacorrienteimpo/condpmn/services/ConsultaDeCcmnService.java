/***********************************************************************
 * Module:  ConsultaDeCCMNService.java
 * Author:  anoriega
 * Purpose: Defines the Interface ConsultaDeCCMNService
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.services;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.Ccmn;

public interface ConsultaDeCcmnService {
	
	/** @param numCorrelativo */
	public Ccmn consultarCcmn(Long numCorrelativo);
}