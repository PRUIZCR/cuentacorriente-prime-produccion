/***********************************************************************
 * Module:  DpmnMongoDBImpl.java
 * Author:  anoriega
 * Purpose: Defines the Class DpmnMongoDBImpl
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.repository.mongodb;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.ComprobanteDpmnResumen;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.ConsultaDpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.Dpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.DpmnResumen;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.common.DataCatalogo;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.common.Ubigeo;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.repository.DpmnRepository;
import pe.gob.sunat.tecnologia.arquitectura.framework.mongodb.client.MongoDBClient;

import static com.mongodb.client.model.Filters.and;
import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Filters.gte;
import static com.mongodb.client.model.Filters.lt;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.bson.Document;
import org.bson.conversions.Bson;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Projections;

public class DpmnMongoDBImpl implements DpmnRepository {
	
	public static final String DC_CUENTA_CORRIENTE = "dcctecorrienteimpo";

	/** @param parametros */
	public List<DpmnResumen> listarDPMNs(ConsultaDpmn parametros) {
		
		List<DpmnResumen> lstDpmnResumen = new ArrayList<DpmnResumen>();
		List <Document> lstDocumentoDpmns = new ArrayList<Document>();
		MongoCollection<Document> collection;
		
		if(BooleanUtils.isTrue(parametros.getIndicadorPorDeclaracion())) {
			/*Cuando la busqueda es por Declaracion, solo se obtiene el atributo numCorreDpmn. 
			 * Con esto, se busca el documento en la coleccion Dpmns
			 */
			collection = MongoDBClient.getCollection(DC_CUENTA_CORRIENTE, "damSeriesDpmn", Document.class);			
			Bson filterDpmn = buildFilterDpmn(parametros, false, null);
			
			List <Document> lstDamSerieDpmn = collection.find(filterDpmn).projection(Projections.include("numCorreDpmn")).into(new ArrayList<Document>());
			
			//Por cada documento encontrado en la coleccion damSeriesDpmn, se obtiene su documento dpmns
			/* cambios para la visualizacion de las dpmn duplicadas*/
			for (Document document : lstDamSerieDpmn) {
				Long numCorreDpmn = Long.parseLong(document.get("numCorreDpmn").toString());
				Bson filter = buildFilterDpmn(parametros, true, numCorreDpmn);				
				collection = MongoDBClient.getCollection(DC_CUENTA_CORRIENTE, "dpmns", Document.class);
				
				//Si ya existe la dpmn en el arreglo, NO debe volver a agregarse
				boolean existeCorrelativoDpmn = lstDocumentoDpmns.stream().anyMatch(c->c.get("numCorrelativo").toString().equals(numCorreDpmn.toString()));
				
				if(existeCorrelativoDpmn)
					continue;
				
				lstDocumentoDpmns.addAll(collection.find(and(filter)).into(new ArrayList<Document>()));
			}	
		}else {
			collection = MongoDBClient.getCollection(DC_CUENTA_CORRIENTE, "dpmns", Document.class);			
			Bson filterDpmn = buildFilterDpmn(parametros, true, null);			
			lstDocumentoDpmns = collection.find(filterDpmn).into(new ArrayList<Document>());
		}
		
		lstDpmnResumen = this.buildDpmnResumen(lstDocumentoDpmns);
		
		return lstDpmnResumen;
	}

	/**
	 * Construye el Objeto DpmnResumen
	 * @param lstDocumentoDpmns
	 * @return
	 */
	private List<DpmnResumen> buildDpmnResumen(List<Document> lstDocumentoDpmns) {
		List<DpmnResumen> lstDpmnResumen = new ArrayList<DpmnResumen>();
		
		for (Document documento : lstDocumentoDpmns) {
			DpmnResumen resumen = new DpmnResumen();
			
			Document aduanaDescarga = (Document) documento.get("aduanaDescarga");
			//Document puestoControlDescarga = (Document) documento.get("puestoControlDescarga");			
			String nroDocumento = aduanaDescarga.getString("codDatacat") + "-" + documento.getInteger("annDpmn") +  "-" + documento.getInteger("numDpmn");			
			
			String strNumCorreDpmn = documento.get("numCorrelativo").toString();
			Long longNumeCorreDpmn = Long.parseLong(strNumCorreDpmn);
			resumen.setNumCorrelativo(longNumeCorreDpmn);

			//resumen.setNumCorrelativo(documento.getLong("numCorrelativo"));
			
			
			
			resumen.setNumeroDeDocumentoDescarga(nroDocumento);			
			resumen.setEstado(new DataCatalogo((Document)documento.get("estado")));
			
			Document empresaTransporte = (Document)documento.get("empresaTransporte");		
			resumen.setPlaca(empresaTransporte.getString("nomPlaca"));
			resumen.setPaisPlaca(new DataCatalogo((Document)empresaTransporte.get("paisPlaca")));
			resumen.setPlacaCarreta(empresaTransporte.getString("nomPlacaCarreta"));
			if(empresaTransporte.get("paisPlacaCarreta")!=null)
				resumen.setPaisPlacaCarreta(new DataCatalogo((Document)empresaTransporte.get("paisPlacaCarreta")));
			resumen.setFlujoVehiculo(new DataCatalogo((Document)empresaTransporte.get("flujoVehiculo")));
			
			resumen.setFechaDeRegistro(documento.getDate("fecDpmn"));
			
			List<Document> lstComprobante = documento.getList("comprobantePago", Document.class);
			
			List<ComprobanteDpmnResumen> lstComprobanteDpmnResumen = new ArrayList<ComprobanteDpmnResumen>();
			String numRucRemitente = "";
			for (Document comprobante : lstComprobante) {
				boolean esEliminado = comprobante.getBoolean("indEliminado");
				DataCatalogo tipoComprobante = new DataCatalogo((Document)comprobante.get("tipoComprobante"));
				
				//Si se encuentra eliminado, no se toma en cuenta
				if(esEliminado)
					continue;
							
				ComprobanteDpmnResumen comprobanteDpmnResumen = new ComprobanteDpmnResumen();
				
				String strNumCorreComprob = comprobante.get("numCorrelativo").toString();
				Long longNumCorreComprob = Long.parseLong(strNumCorreComprob);
				
				comprobanteDpmnResumen.setNumCorrelativo(longNumCorreComprob);
				//comprobanteDpmnResumen.setNumCorrelativo(comprobante.getLong("numCorrelativo"));
				comprobanteDpmnResumen.setTipoComprobante(tipoComprobante);
				comprobanteDpmnResumen.setNumRucDestinatario(comprobante.getString("numRucDestinatario"));
				comprobanteDpmnResumen.setDesRazonSocialDestinatario(comprobante.getString("desRazonSocialDestinatario"));
				comprobanteDpmnResumen.setMotivoDeTraslado(new DataCatalogo((Document)comprobante.get("motivoDeTraslado")));
				comprobanteDpmnResumen.setUbigeoDestino(new Ubigeo((Document)comprobante.get("ubigeoDestino")));
				
				//Es guia de remision
				if(tipoComprobante.getCodDatacat().equals("01")) {
					comprobanteDpmnResumen.setNumSerie(comprobante.getString("numSerie"));
					comprobanteDpmnResumen.setNumGuia(comprobante.getString("numGuia"));
					comprobanteDpmnResumen.setNumRucRemitente(comprobante.getString("numRucRemitente"));
					comprobanteDpmnResumen.setDesRazonSocialRemitente(comprobante.getString("desRazonSocialRemitente"));
					
					if(StringUtils.isEmpty(numRucRemitente)) {
						numRucRemitente = comprobante.getString("numRucRemitente");
						resumen.setRucDelRemitente(numRucRemitente);
					}
				}
				
				//Es carta porte
				if(tipoComprobante.getCodDatacat().equals("03")) {
					comprobanteDpmnResumen.setNumCartaPorte(comprobante.getString("numCartaPorte"));
					comprobanteDpmnResumen.setNomEmpresa(comprobante.getString("nomEmpresa"));
				}
			
				lstComprobanteDpmnResumen.add(comprobanteDpmnResumen);
				
			}
			resumen.setLstComprobante(lstComprobanteDpmnResumen);					
			resumen.setCantidadDeSeries(this.obtieneCantidadSeries(longNumeCorreDpmn));
			//resumen.setCantidadDeSeries(this.obtieneCantidadSeries(documento.getLong("numCorrelativo")));
			
			/*Los siguientes datos se obtienen de control de pasos*/
			resumen.setCantidadDeControles(0);
			resumen.setFechaDelUltimoControl(null);		
			resumen.setCanalDelUltimoControl(new DataCatalogo(" "));
			resumen.setFuncionarioAduanero("");
			
			lstDpmnResumen.add(resumen);
		}
		
		return lstDpmnResumen;
	}

	/**
	 * Obtiene la cantidad de Series por dpmn
	 * @param numCorreDpmn
	 * @return
	 */
	private Integer obtieneCantidadSeries(Long numCorreDpmn) {
        MongoCollection collection = MongoDBClient.getCollection(DC_CUENTA_CORRIENTE, "damSeriesDpmn");	      
        Integer count = (int) collection.count(Filters.and(Filters.eq("numCorreDpmn",numCorreDpmn)));
        return count;
	}

	/**
	 * Construye el filtro de busqueda
	 * @param parametros
	 * @return
	 */
	private Bson buildFilterDpmn(ConsultaDpmn parametros, boolean esConsultaDpmnCollection, Long numCorreDpmn) {
		List<Bson> filterDpmn = new ArrayList<>();
		
		if(BooleanUtils.isTrue(parametros.getIndicadorPorDeclaracion())) {
			if(!esConsultaDpmnCollection) {
				filterDpmn.add(eq("aduanaDam.codDatacat", parametros.getAduanaDeDeclaracion().getCodDatacat()));
				filterDpmn.add(eq("annDam", parametros.getAnoDeDeclaracion()));
				filterDpmn.add(eq("regimenDam.codDatacat", parametros.getRegimenDeDeclaracion().getCodDatacat()));
				filterDpmn.add(eq("numDam", parametros.getNumeroDeDeclaracion()));	

			}else {
				filterDpmn.add(eq("numCorrelativo", numCorreDpmn));
			}
		}else {
			if(BooleanUtils.isTrue(parametros.getIndicadorPorDocumento())) {
				filterDpmn.add(eq("aduanaDescarga.codDatacat", parametros.getAduanaDeDescarga().getCodDatacat()));
				filterDpmn.add(eq("annDpmn", parametros.getAnoDeDescarga()));
				//filterDpmn.add(eq("puestoControlDescarga.codDatacat", parametros.getPuestoDeControlDescarga().getCodDatacat())); Si es Dpmn, no tiene puesto control
				filterDpmn.add(eq("numDpmn", parametros.getNumeroDeDescarga()));
			}
				
			if(BooleanUtils.isTrue(parametros.getIndicadorPorFecha())) {
				filterDpmn.add(gte("fecDpmn", parametros.getFechaDeInicioConsulta()));
				//A la fecha fin se le agrega 1 dia para que consulte hasta las 23:59:59 del dia anter				
				Calendar c = Calendar.getInstance(); 
				c.setTime(parametros.getFechaFinConsulta()); 
				c.add(Calendar.DATE, 1);
				filterDpmn.add(lt("fecDpmn", c.getTime()));
			}
			
		}
		
		if(esConsultaDpmnCollection) {
			if(!StringUtils.isEmpty(parametros.getRucTransportista()))
				filterDpmn.add(eq("empresaTransporte.numDocIdentidad", parametros.getRucTransportista()));
			
			//El tipo de control aun no se implementa
			//if(!StringUtils.isEmpty(parametros.getTipoDeControl().getCodDatacat()))
			//	filterDpmn.add(eq("annDpmn", parametros.getRucTransportista()));
			
			if(parametros.getEstadoDelDocumentoDeDescarga()!=null && !StringUtils.isEmpty(parametros.getEstadoDelDocumentoDeDescarga().getCodDatacat()))
				filterDpmn.add(eq("estado.codDatacat", parametros.getEstadoDelDocumentoDeDescarga().getCodDatacat()));
			
			if(parametros.getPaisPlacaDelVehiculo()!=null && !StringUtils.isEmpty(parametros.getPaisPlacaDelVehiculo().getCodDatacat()))
				filterDpmn.add(eq("empresaTransporte.paisPlaca.codDatacat", parametros.getPaisPlacaDelVehiculo().getCodDatacat()));
			
			if(!StringUtils.isEmpty(parametros.getPlacaDelVehiculo()))
				filterDpmn.add(eq("empresaTransporte.nomPlaca", parametros.getPlacaDelVehiculo()));
			
			if(!StringUtils.isEmpty(parametros.getRucDelRemitente()))
				filterDpmn.add(eq("comprobantePago.numRucRemitente", parametros.getRucDelRemitente()));
		}
		
		
		return and(filterDpmn);
	}


	/**
	 * Obtiene la DPMN por numeroCorrelativo
	 */
	public Dpmn consultarDpmn(Long idDpmn) {
		MongoCollection<Dpmn> collection = MongoDBClient.getCollection(DC_CUENTA_CORRIENTE, "dpmns", Dpmn.class);		
		Dpmn dpmn = collection.find(Filters.and(Filters.eq("numCorrelativo",idDpmn))).first();
		return dpmn;
	}

}