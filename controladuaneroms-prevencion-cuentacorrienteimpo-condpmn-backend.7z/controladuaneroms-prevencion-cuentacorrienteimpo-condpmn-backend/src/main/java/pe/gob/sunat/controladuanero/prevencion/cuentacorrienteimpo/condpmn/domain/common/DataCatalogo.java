/***********************************************************************
 * Module:  DataCatalogo.java
 * Author:  rcontreras
 * Purpose: Defines the Class DataCatalogo
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.common;

import org.bson.Document;

public class DataCatalogo implements java.io.Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 7427462226640113004L;
	private String codDatacat;
	private String desDataCat;
	
	public DataCatalogo() {
		
	}
	
	public DataCatalogo(Document bson) {
		this.codDatacat = bson.getString("codDatacat");
		this.desDataCat = bson.getString("desDataCat");
	}
	
	public DataCatalogo(String codDatacat) {
		this.codDatacat = codDatacat;
	}

	public String getCodDatacat() {
		return codDatacat;
	}

	/** @param newCodDatacat */
	public void setCodDatacat(String newCodDatacat) {
		codDatacat = newCodDatacat;
	}

	public String getDesDataCat() {
		return desDataCat;
	}

	/** @param newDesDataCat */
	public void setDesDataCat(String newDesDataCat) {
		desDataCat = newDesDataCat;
	}

}