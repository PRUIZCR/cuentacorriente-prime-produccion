/***********************************************************************
 * Module:  CcmnMongoDBImpl.java
 * Author:  anoriega
 * Purpose: Defines the Class CcmnMongoDBImpl
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.repository.mongodb;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.Ccmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.repository.CcmnRepository;
import pe.gob.sunat.tecnologia.arquitectura.framework.mongodb.client.MongoDBClient;

import static com.mongodb.client.model.Filters.and;
import static com.mongodb.client.model.Filters.eq;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Filters;

public class CcmnMongoDBImpl implements CcmnRepository {

	public static final String DC_CUENTA_CORRIENTE = "dcctecorrienteimpo";

	/**
	 * Obtiene la DPMN por numeroCorrelativo * @param idCcmn
	 **/
	public Ccmn consultarCcmn(Long idCcmn) {
		MongoCollection<Ccmn> collection = MongoDBClient.getCollection(DC_CUENTA_CORRIENTE, "ccmns", Ccmn.class);
			Ccmn ccmn = collection.find(and(eq("numCorrelativo", idCcmn), Filters.ne("estado.codDatacat", "03"))).first();
		return ccmn;
	}

}