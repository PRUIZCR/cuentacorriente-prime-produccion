/***********************************************************************
 * Module:  EmpresaTransporte.java
 * Author:  rcontreras
 * Purpose: Defines the Class EmpresaTransporte
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.common.DataCatalogo;

public class EmpresaTransporte implements java.io.Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -197706797202958022L;
	private DataCatalogo tipoNacionalidad;
	private String codEmpTransporte;
	/**
	 * Tipo de documento con el que se identifica el transportista que será 4 si se
	 * identifica con RUC o 14 si se identifica con su código de 4 dígitos de
	 * transportista terrestre internacional
	 */
	private DataCatalogo tipoDocIdentidad;
	/**
	 * Corresponde al número de RUC con al código de 4 dígitos con el que se
	 * identifica el transportista
	 */
	private String numDocIdentidad;
	private DataCatalogo paisEmpresa;
	private String nomEmpresa;
	private DataCatalogo flujoVehiculo;
	private DataCatalogo paisPlaca;
	private String nomPlaca;
	private String valEmail;
	private DataCatalogo paisPlacaCarreta;
	private String nomPlacaCarreta;
	private String numTelefono;

	public DataCatalogo getTipoNacionalidad() {
		return tipoNacionalidad;
	}

	/** @param newTipoNacionalidad */
	public void setTipoNacionalidad(DataCatalogo newTipoNacionalidad) {
		tipoNacionalidad = newTipoNacionalidad;
	}

	public String getCodEmpTransporte() {
		return codEmpTransporte;
	}

	/** @param newCodEmpTransporte */
	public void setCodEmpTransporte(String newCodEmpTransporte) {
		codEmpTransporte = newCodEmpTransporte;
	}

	public DataCatalogo getTipoDocIdentidad() {
		return tipoDocIdentidad;
	}

	/** @param newTipoDocIdentidad */
	public void setTipoDocIdentidad(DataCatalogo newTipoDocIdentidad) {
		tipoDocIdentidad = newTipoDocIdentidad;
	}

	public String getNumDocIdentidad() {
		return numDocIdentidad;
	}

	/** @param newNumDocIdentidad */
	public void setNumDocIdentidad(String newNumDocIdentidad) {
		numDocIdentidad = newNumDocIdentidad;
	}

	public DataCatalogo getPaisEmpresa() {
		return paisEmpresa;
	}

	/** @param newPaisEmpresa */
	public void setPaisEmpresa(DataCatalogo newPaisEmpresa) {
		paisEmpresa = newPaisEmpresa;
	}

	public String getNomEmpresa() {
		return nomEmpresa;
	}

	/** @param newNomEmpresa */
	public void setNomEmpresa(String newNomEmpresa) {
		nomEmpresa = newNomEmpresa;
	}

	public DataCatalogo getFlujoVehiculo() {
		return flujoVehiculo;
	}

	/** @param newFlujoVehiculo */
	public void setFlujoVehiculo(DataCatalogo newFlujoVehiculo) {
		flujoVehiculo = newFlujoVehiculo;
	}

	public DataCatalogo getPaisPlaca() {
		return paisPlaca;
	}

	/** @param newPaisPlaca */
	public void setPaisPlaca(DataCatalogo newPaisPlaca) {
		paisPlaca = newPaisPlaca;
	}

	public String getNomPlaca() {
		return nomPlaca;
	}

	/** @param newNomPlaca */
	public void setNomPlaca(String newNomPlaca) {
		nomPlaca = newNomPlaca;
	}

	public String getValEmail() {
		return valEmail;
	}

	/** @param newValEmail */
	public void setValEmail(String newValEmail) {
		valEmail = newValEmail;
	}

	public DataCatalogo getPaisPlacaCarreta() {
		return paisPlacaCarreta;
	}

	/** @param newPaisPlacaCarreta */
	public void setPaisPlacaCarreta(DataCatalogo newPaisPlacaCarreta) {
		paisPlacaCarreta = newPaisPlacaCarreta;
	}

	public String getNomPlacaCarreta() {
		return nomPlacaCarreta;
	}

	/** @param newNomPlacaCarreta */
	public void setNomPlacaCarreta(String newNomPlacaCarreta) {
		nomPlacaCarreta = newNomPlacaCarreta;
	}

	public String getNumTelefono() {
		return numTelefono;
	}

	/** @param newNumTelefono */
	public void setNumTelefono(String newNumTelefono) {
		numTelefono = newNumTelefono;
	}

}