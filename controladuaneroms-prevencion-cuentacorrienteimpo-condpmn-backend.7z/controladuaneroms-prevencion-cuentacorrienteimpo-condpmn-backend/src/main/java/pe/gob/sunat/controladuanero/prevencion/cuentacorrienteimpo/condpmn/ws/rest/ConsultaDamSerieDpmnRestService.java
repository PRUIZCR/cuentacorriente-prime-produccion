/***********************************************************************
 * Module:  ConsultaDeDpmnRestService.java
 * Author:  anoriega
 * Purpose: Defines the Class ConsultaDeDpmnRestService
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.ws.rest;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.DamSerieDpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.services.ConsultaDeDpmnService;
import pe.gob.sunat.tecnologiams.arquitectura.framework.microservices.model.bean.MensajeBean;
import pe.gob.sunat.tecnologiams.arquitectura.framework.microservices.util.ConstantesUtils;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/v1/controladuanero/prevencion/cuentacorrienteimpo")
public class ConsultaDamSerieDpmnRestService extends DpmnCcmnAbstractRest {

	@GET
	@Path("/e/dpmns/{numCorreDpmn}/damseriesdpmn")
	@Produces({ MediaType.APPLICATION_JSON })
	public Response buscarPorNumCorreDpmn(@PathParam("numCorreDpmn") Long numCorreDpmn) {
		MensajeBean msjBean = new MensajeBean();
		try {

			List<DamSerieDpmn> lstSerieDpmn = this.consultaDamSerieDpmnService.buscarPorNumCorreDpmn(numCorreDpmn);

			if (lstSerieDpmn == null || lstSerieDpmn.isEmpty()) {
				msjBean = new MensajeBean();
				msjBean.setCod(1);
				msjBean.setMsg("No se ha encontrado series con los par\u00E1metros ingresados");
				return Response.status(COD_ERROR_VALIDACION).entity(msjBean)
						.type(MediaType.APPLICATION_JSON_TYPE.withCharset("utf-8")).build();
			} else {
				return Response.ok(lstSerieDpmn).build();
			}
		} catch (java.lang.Exception ex) {
			utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, "Ha ocurrido un error al buscar los dpmn",
					ex.getStackTrace());
			msjBean = new MensajeBean();
			msjBean.setCod(1);
			msjBean.setMsg("Ha ocurrido un error al buscar los dpmn");
			return Response.status(COD_ERROR_VALIDACION).entity(msjBean)
					.type(MediaType.APPLICATION_JSON_TYPE.withCharset("utf-8")).build();
		}
	}

	/**
	 * @pdGenerated default parent setter
	 * @param newConsultaDeDpmnService
	 */
	public void setConsultaDeDpmnService(ConsultaDeDpmnService newConsultaDeDpmnService) {
		this.consultaDeDpmnService = newConsultaDeDpmnService;
	}

}