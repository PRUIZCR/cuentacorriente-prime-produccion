package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.ws.rest;

import javax.inject.Inject;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.services.ConsultaDamSerieCcmnService;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.services.ConsultaDamSerieDpmnService;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.services.ConsultaDeCcmnService;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.services.ConsultaDeDpmnService;
import pe.gob.sunat.tecnologiams.arquitectura.framework.microservices.util.UtilLog;

public abstract class DpmnCcmnAbstractRest {
	@Inject
	protected UtilLog utilLog;

	protected static final Integer COD_ERROR_VALIDACION = 422;

	@Inject
	protected ConsultaDeDpmnService consultaDeDpmnService;
	
	@Inject
	protected ConsultaDamSerieDpmnService consultaDamSerieDpmnService;
	
	@Inject
	protected ConsultaDeCcmnService consultaDeCcmnService;
	
	@Inject
	protected ConsultaDamSerieCcmnService consultaDamSerieCcmnService;

}
