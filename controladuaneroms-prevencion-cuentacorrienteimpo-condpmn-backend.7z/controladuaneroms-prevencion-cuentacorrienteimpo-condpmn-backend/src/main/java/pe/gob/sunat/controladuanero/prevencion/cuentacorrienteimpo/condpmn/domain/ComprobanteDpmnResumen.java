package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain;

import java.io.Serializable;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.common.DataCatalogo;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.common.Ubigeo;

public class ComprobanteDpmnResumen implements Serializable {
	
	private static final long serialVersionUID = -4748835727133541254L;
	
	private Long numCorrelativo;
	private DataCatalogo tipoComprobante;
	private String numRucDestinatario;
	private String desRazonSocialDestinatario;
	private DataCatalogo motivoDeTraslado;
	private Ubigeo ubigeoDestino;

	/* Para guia de remision */
	private String numSerie;
	private String numGuia;
	private String numRucRemitente;
	private String desRazonSocialRemitente;

	/* Para carta porte */
	private String numCartaPorte;
	private String nomEmpresa;

	public Long getNumCorrelativo() {
		return numCorrelativo;
	}

	public void setNumCorrelativo(Long numCorrelativo) {
		this.numCorrelativo = numCorrelativo;
	}

	public DataCatalogo getTipoComprobante() {
		return tipoComprobante;
	}

	public void setTipoComprobante(DataCatalogo tipoComprobante) {
		this.tipoComprobante = tipoComprobante;
	}

	public String getNumRucDestinatario() {
		return numRucDestinatario;
	}

	public void setNumRucDestinatario(String numRucDestinatario) {
		this.numRucDestinatario = numRucDestinatario;
	}

	public String getDesRazonSocialDestinatario() {
		return desRazonSocialDestinatario;
	}

	public void setDesRazonSocialDestinatario(String desRazonSocialDestinatario) {
		this.desRazonSocialDestinatario = desRazonSocialDestinatario;
	}

	public DataCatalogo getMotivoDeTraslado() {
		return motivoDeTraslado;
	}

	public void setMotivoDeTraslado(DataCatalogo motivoDeTraslado) {
		this.motivoDeTraslado = motivoDeTraslado;
	}

	public Ubigeo getUbigeoDestino() {
		return ubigeoDestino;
	}

	public void setUbigeoDestino(Ubigeo ubigeoDestino) {
		this.ubigeoDestino = ubigeoDestino;
	}

	public String getNumSerie() {
		return numSerie;
	}

	public void setNumSerie(String numSerie) {
		this.numSerie = numSerie;
	}

	public String getNumGuia() {
		return numGuia;
	}

	public void setNumGuia(String numGuia) {
		this.numGuia = numGuia;
	}

	public String getNumRucRemitente() {
		return numRucRemitente;
	}

	public void setNumRucRemitente(String numRucRemitente) {
		this.numRucRemitente = numRucRemitente;
	}

	public String getDesRazonSocialRemitente() {
		return desRazonSocialRemitente;
	}

	public void setDesRazonSocialRemitente(String desRazonSocialRemitente) {
		this.desRazonSocialRemitente = desRazonSocialRemitente;
	}

	public String getNumCartaPorte() {
		return numCartaPorte;
	}

	public void setNumCartaPorte(String numCartaPorte) {
		this.numCartaPorte = numCartaPorte;
	}

	public String getNomEmpresa() {
		return nomEmpresa;
	}

	public void setNomEmpresa(String nomEmpresa) {
		this.nomEmpresa = nomEmpresa;
	}

}
