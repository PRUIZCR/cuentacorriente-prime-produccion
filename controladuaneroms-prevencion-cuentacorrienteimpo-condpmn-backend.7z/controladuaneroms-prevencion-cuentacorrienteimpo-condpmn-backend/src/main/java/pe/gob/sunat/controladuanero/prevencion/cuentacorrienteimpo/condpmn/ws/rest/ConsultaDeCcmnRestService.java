/***********************************************************************
 * Module:  ConsultaDeCcmnRestService.java
 * Author:  anoriega
 * Purpose: Defines the Class ConsultaDeCcmnRestService
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.ws.rest;

import javax.ws.rs.core.Response;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.services.ConsultaDeCcmnService;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.Ccmn;
import pe.gob.sunat.tecnologiams.arquitectura.framework.microservices.model.bean.MensajeBean;
import pe.gob.sunat.tecnologiams.arquitectura.framework.microservices.util.ConstantesUtils;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/v1/controladuanero/prevencion/cuentacorrienteimpo")
public class ConsultaDeCcmnRestService extends DpmnCcmnAbstractRest {
	public ConsultaDeCcmnService consultaDeCCMNService;

	/** @param numCorrelativo */
	@GET
	@Path("/e/ccmns/{numCorrelativo}")
	@Produces({ MediaType.APPLICATION_JSON })
	public Response consultarCcmn(@PathParam("numCorrelativo") Long numCorrelativo) {
		MensajeBean msjBean = new MensajeBean();
		try {

			Ccmn ccmn = this.consultaDeCcmnService.consultarCcmn(numCorrelativo);

			if (ccmn == null) {
				msjBean = new MensajeBean();
				msjBean.setCod(1);
				msjBean.setMsg("No se ha encontrado CCMN con el correlativo ingresado");
				return Response.status(COD_ERROR_VALIDACION).entity(msjBean)
						.type(MediaType.APPLICATION_JSON_TYPE.withCharset("utf-8")).build();
			} 
			
			return Response.ok(ccmn).build();
			
		} catch (java.lang.Exception ex) {
			utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, "Error al consultar consultarCcmn", ex.getStackTrace());
			msjBean = new MensajeBean();
			msjBean.setCod(1);
			msjBean.setMsg("Ha ocurrido un error al buscar la CCMN");
			return Response.status(COD_ERROR_VALIDACION).entity(msjBean)
					.type(MediaType.APPLICATION_JSON_TYPE.withCharset("utf-8")).build();
		}
	}
	

	/** @pdGenerated default parent getter */
	public ConsultaDeCcmnService getConsultaDeCCMNService() {
		return consultaDeCCMNService;
	}

	/**
	 * @pdGenerated default parent setter
	 * @param newConsultaDeCCMNService
	 */
	public void setConsultaDeCCMNService(ConsultaDeCcmnService newConsultaDeCCMNService) {
		this.consultaDeCCMNService = newConsultaDeCCMNService;
	}

}