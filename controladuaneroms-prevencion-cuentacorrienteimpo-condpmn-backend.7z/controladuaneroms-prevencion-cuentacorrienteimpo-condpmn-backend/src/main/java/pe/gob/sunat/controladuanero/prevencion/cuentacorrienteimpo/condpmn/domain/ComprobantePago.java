/***********************************************************************
 * Module:  ComprobantePago.java
 * Author:  rcontreras
 * Purpose: Defines the Class ComprobantePago
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.common.Auditoria;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.common.DataCatalogo;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.common.Ubigeo;

public class ComprobantePago implements java.io.Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -5504468939628612261L;
	private Long numCorrelativo;
	private DataCatalogo tipoComprobante;
	private String numRucDestinatario;
	private String desRazonSocialDestinatario;
	private DataCatalogo motivoDeTraslado;
	private Ubigeo ubigeoDestino;
	private boolean indEliminado;
	private Auditoria auditoria;
	
	private String numSerie;
	private String numGuia;
	private String numRucRemitente;
	private String desRazonSocialRemitente;
	private String numCartaPorte;
	private String nomEmpresa;

	
	public Long getNumCorrelativo() {
		return numCorrelativo;
	}

	/** @param newNumCorrelativo */
	public void setNumCorrelativo(Long newNumCorrelativo) {
		numCorrelativo = newNumCorrelativo;
	}

	public DataCatalogo getTipoComprobante() {
		return tipoComprobante;
	}

	/** @param newTipoComprobante */
	public void setTipoComprobante(DataCatalogo newTipoComprobante) {
		tipoComprobante = newTipoComprobante;
	}

	public String getNumRucDestinatario() {
		return numRucDestinatario;
	}

	/** @param newNumRucDestinatario */
	public void setNumRucDestinatario(String newNumRucDestinatario) {
		numRucDestinatario = newNumRucDestinatario;
	}

	public String getDesRazonSocialDestinatario() {
		return desRazonSocialDestinatario;
	}

	/** @param newDesRazonSocialDestinatario */
	public void setDesRazonSocialDestinatario(String newDesRazonSocialDestinatario) {
		desRazonSocialDestinatario = newDesRazonSocialDestinatario;
	}

	public DataCatalogo getMotivoDeTraslado() {
		return motivoDeTraslado;
	}

	/** @param newMotivoDeTraslado */
	public void setMotivoDeTraslado(DataCatalogo newMotivoDeTraslado) {
		motivoDeTraslado = newMotivoDeTraslado;
	}

	public Ubigeo getUbigeoDestino() {
		return ubigeoDestino;
	}

	/** @param newUbigeoDestino */
	public void setUbigeoDestino(Ubigeo newUbigeoDestino) {
		ubigeoDestino = newUbigeoDestino;
	}

	public boolean getIndEliminado() {
		return indEliminado;
	}

	/** @param newIndEliminado */
	public void setIndEliminado(boolean newIndEliminado) {
		indEliminado = newIndEliminado;
	}

	public Auditoria getAuditoria() {
		return auditoria;
	}

	/** @param newAuditoria */
	public void setAuditoria(Auditoria newAuditoria) {
		auditoria = newAuditoria;
	}

	public String getNumSerie() {
		return numSerie;
	}

	public void setNumSerie(String numSerie) {
		this.numSerie = numSerie;
	}

	public String getNumGuia() {
		return numGuia;
	}

	public void setNumGuia(String numGuia) {
		this.numGuia = numGuia;
	}

	public String getNumRucRemitente() {
		return numRucRemitente;
	}

	public void setNumRucRemitente(String numRucRemitente) {
		this.numRucRemitente = numRucRemitente;
	}

	public String getDesRazonSocialRemitente() {
		return desRazonSocialRemitente;
	}

	public void setDesRazonSocialRemitente(String desRazonSocialRemitente) {
		this.desRazonSocialRemitente = desRazonSocialRemitente;
	}

	public String getNumCartaPorte() {
		return numCartaPorte;
	}

	public void setNumCartaPorte(String numCartaPorte) {
		this.numCartaPorte = numCartaPorte;
	}

	public String getNomEmpresa() {
		return nomEmpresa;
	}

	public void setNomEmpresa(String nomEmpresa) {
		this.nomEmpresa = nomEmpresa;
	}

	
}