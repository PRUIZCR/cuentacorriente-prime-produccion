/***********************************************************************
 * Module:  ConsultaDamSerieCcmnServiceImplement.java
 * Author:  anoriega
 * Purpose: Defines the Class ConsultaDamSerieCcmnServiceImplement
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.services;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.DamSerieCcmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.repository.DamSerieCcmnRepository;
import java.util.*;

import javax.inject.Inject;

public class ConsultaDamSerieCcmnServiceImpl implements ConsultaDamSerieCcmnService {

	@Inject
	DamSerieCcmnRepository damSerieCcmnRepository;

	/** @param numCorreCcmn */
	public List<DamSerieCcmn> buscarPorNumCorreCcmn(Long numCorreCcmn) {
		return damSerieCcmnRepository.buscarPorNumCorreCcmn(numCorreCcmn);
	}

	/** @pdGenerated default parent getter */
	public DamSerieCcmnRepository getDamSerieCcmnRepository() {
		return damSerieCcmnRepository;
	}

	/**
	 * @pdGenerated default parent setter
	 * @param newDamSerieCcmnRepository
	 */
	public void setDamSerieCcmnRepository(DamSerieCcmnRepository newDamSerieCcmnRepository) {
		this.damSerieCcmnRepository = newDamSerieCcmnRepository;
	}

}