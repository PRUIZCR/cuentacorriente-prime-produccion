package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.FontCharset;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.DpmnResumen;
import pe.gob.sunat.tecnologiams.arquitectura.framework.microservices.util.ConstantesUtils;
import pe.gob.sunat.tecnologiams.arquitectura.framework.microservices.util.UtilLog;

import javax.inject.Inject;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.StreamingOutput;

public class ReporteUtil {
	
	@Inject
	private UtilLog utilLog;
	
	public final static String jasperDirectory = "/jaspers/";
	public final static String jasperReportName = "PLANTILLADPMN";


	public StreamingOutput generaReporteXls(List<DpmnResumen> lstDpmns) throws IOException {

		String nombrePantilla = "/xlsx/CONSULTA_DPMNS.xlsx";

		InputStream inputStream = getClass().getResourceAsStream(nombrePantilla);
		
		XSSFWorkbook wbPlantilla = new XSSFWorkbook(inputStream);
		XSSFSheet sheet = wbPlantilla.getSheetAt(0); 
		List<XSSFCellStyle> estilos = new ArrayList<XSSFCellStyle>();
		
		this.getEstilosReporteCasosXls(2, sheet, estilos, wbPlantilla);			
		this.seteaDatos(sheet, estilos, nombrePantilla, lstDpmns);
		
		return new StreamingOutput() {
			@Override
			public void write(OutputStream output) throws IOException, WebApplicationException {
				try {
					wbPlantilla.write(output);
					inputStream.close();
					
					
					output.flush();
					output.close();
				} catch (Exception e) {
					output.flush();
					output.close();
					utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, UtilLog.getStackTraceFromException(e), e.getStackTrace());
				}
				
			}
		};
	}
	
	
	public byte[] generaReportePDF(List<DpmnResumen> lstDpmns) throws Exception {
		
		List<Reporte> lstReporte = new ArrayList<Reporte>();
		SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy HH:mm");
		
		for (DpmnResumen dpmn : lstDpmns) {
			Reporte reporte = new Reporte();
			reporte.setNumeroDeDocumentoDescarga(dpmn.getNumeroDeDocumentoDescarga());
			reporte.setEstado(dpmn.getEstado().getDesDataCat());
			reporte.setPaisPlaca(dpmn.getPaisPlaca().getCodDatacat() + "-" + dpmn.getPlaca());
			
			if(dpmn.getPaisPlacaCarreta()!=null && !StringUtils.isEmpty(dpmn.getPaisPlacaCarreta().getCodDatacat())) {
				reporte.setPlacaCarreta(dpmn.getPaisPlacaCarreta().getCodDatacat() + "-" + dpmn.getPlacaCarreta());
			}else {
				reporte.setPlacaCarreta(" ");
			}
			
			reporte.setFlujoVehiculo(dpmn.getFlujoVehiculo().getDesDataCat());
			reporte.setFechaDeRegistro(formato.format(dpmn.getFechaDeRegistro()));
			reporte.setRucDelRemitente(dpmn.getRucDelRemitente());
			reporte.setCantidadDeSeries(dpmn.getCantidadDeSeries());
			reporte.setCantidadDeControles(dpmn.getCantidadDeControles());
			reporte.setFechaDelUltimoControl(dpmn.getFechaDelUltimoControl()==null?null:formato.format(dpmn.getFechaDelUltimoControl()));
			reporte.setCanalDelUltimoControl(dpmn.getCanalDelUltimoControl().getCodDatacat());
			reporte.setFuncionarioAduanero(dpmn.getFuncionarioAduanero());
			lstReporte.add(reporte);			
		}
		
		Map<String,Object> parametrosPdf = prepararParametrosPdf(lstReporte);
		
		byte[] output = generarPDF(jasperReportName, parametrosPdf);
		
		return output;
	}
	
	public static Map<String,Object> prepararParametrosPdf(List<Reporte> lstReporte) throws Exception{
		Map<String,Object> parametrosPdf = new HashMap<String,Object>();
		
		Timestamp fechaActual_param = new FechaBean().getTimestamp();
		SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		String fecha_par = formato.format(fechaActual_param);
		
		parametrosPdf.put("P_FECHA", fecha_par);
		parametrosPdf.put("REPORT_LOCALE", new java.util.Locale("en", "US"));
		parametrosPdf.put("datos", lstReporte);
		
		parametrosPdf.put("SUBREPORT_DIR", jasperDirectory);
		
		parametrosPdf.put("metadata_asunto","Consultas de CCMN / DPMN");
		parametrosPdf.put("metadata_titulo","Consultas de CCMN / DPMN");
		parametrosPdf.put("net.sf.jasperreports.engine.export.JRPdfExporterParameter.METADATA_AUTHOR", "sunat.gob.pe");
		parametrosPdf.put("net.sf.jasperreports.engine.export.JRPdfExporterParameter.METADATA_CREATOR", "SUNAT Java GenDoc derechos reservados");
				
		return parametrosPdf;
	}
	
	public byte[] generarPDF(String jasperName, Map parametrosPdf) throws Exception{
		String jasperFile = jasperDirectory + jasperName + ".jasper";
				
		InputStream input1 = getClass().getResourceAsStream(jasperFile);
		JasperPrint jasperPrint = null;
		jasperPrint = JasperFillManager.fillReport(input1, parametrosPdf, new JREmptyDataSource(1));
				
		
		byte[] output = JasperExportManager.exportReportToPdf(jasperPrint);
		return output;
	}
	
	private void seteaDatos(XSSFSheet sheet, List<XSSFCellStyle> estilos, String nombrePantilla,
			List<DpmnResumen> lstDpmns) throws UnsupportedEncodingException {
		
		Timestamp fechaActual_param = new FechaBean().getTimestamp();
		SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		SimpleDateFormat formatoSinSegundos = new SimpleDateFormat("dd/MM/yyyy HH:mm");
		String fecha_par = formato.format(fechaActual_param);
		this.createCell((String) fecha_par, sheet.getRow(2), 1, estilos.get(1));
				
		int rowNum = 6;
		for(DpmnResumen dpmnResumen : lstDpmns) {
			XSSFRow row = null;
			if (rowNum == 6){
				row = sheet.getRow(rowNum);
			} else {
				row = sheet.createRow(rowNum);
			}			
			this.createCell(dpmnResumen.getNumeroDeDocumentoDescarga(), row, 0, estilos.get(1));
			this.createCell(dpmnResumen.getEstado().getDesDataCat(), row, 1, estilos.get(1));
			this.createCell(dpmnResumen.getPaisPlaca().getCodDatacat() + "-" + dpmnResumen.getPlaca(), row, 2, estilos.get(1));
			
			if(dpmnResumen.getPaisPlacaCarreta()!=null && !StringUtils.isEmpty(dpmnResumen.getPaisPlacaCarreta().getCodDatacat())) {
				this.createCell(dpmnResumen.getPaisPlacaCarreta().getCodDatacat() + "-" + dpmnResumen.getPlacaCarreta(), row, 3, estilos.get(1));
			}else {
				this.createCell(" ", row, 3, estilos.get(1));
			}
			this.createCell(dpmnResumen.getFlujoVehiculo().getDesDataCat(),  row, 4, estilos.get(estilos.size()-1));
			this.createCell(formatoSinSegundos.format(dpmnResumen.getFechaDeRegistro()), row, 5, estilos.get(1));
			this.createCell(dpmnResumen.getRucDelRemitente(), row, 6, estilos.get(1));
			this.createCell(String.valueOf(dpmnResumen.getCantidadDeSeries()), row, 7, estilos.get(1));
			this.createCell(String.valueOf(dpmnResumen.getCantidadDeControles()), row, 8, estilos.get(1));
			this.createCell(dpmnResumen.getFechaDelUltimoControl()==null?null:formato.format(dpmnResumen.getFechaDelUltimoControl()), row, 9, estilos.get(1));
			this.createCell(dpmnResumen.getCanalDelUltimoControl().getCodDatacat(), row, 10, estilos.get(1));
			this.createCell(dpmnResumen.getFuncionarioAduanero(), row, 11, estilos.get(1));
			rowNum++;
		}
		
	}
	
	private void createCell(Object valor, XSSFRow row, int column, XSSFCellStyle style) {
		XSSFCell cell = row.getCell(column);
		if(cell == null) {
			cell = row.createCell(column);
		}
		
		this.setCellValue(cell, style, valor);
	}
	
	private void setCellValue(XSSFCell cell, XSSFCellStyle style, Object valor){
		cell.setCellStyle(style);
		this.setCellValue(cell, valor);
	}
	
	private void setCellValue(XSSFCell cell, Object valor){
		if (valor == null) {
			cell.setCellType(XSSFCell.CELL_TYPE_BLANK);
		} else if (valor instanceof String) {
			cell.setCellType(XSSFCell.CELL_TYPE_STRING);
			cell.setCellValue((String) valor);
		} else if (valor instanceof Integer) {
			cell.setCellType(XSSFCell.CELL_TYPE_STRING);
			cell.setCellValue((Integer) valor);
		} else if (valor instanceof Boolean) {
			cell.setCellType(XSSFCell.CELL_TYPE_BOOLEAN);
			cell.setCellValue((Boolean) valor);
		} else if (valor instanceof Double) {
			cell.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
			cell.setCellValue((Double) valor);
		} else if (valor instanceof BigDecimal) {
			cell.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
			cell.setCellValue(((BigDecimal) valor).doubleValue());
		} else {
			// case XSSFCell.CELL_TYPE_FORMULA:
		}
	}
	
	private void getEstilosReporteCasosXls(int numRow, XSSFSheet sheet, List<XSSFCellStyle> estilos, XSSFWorkbook wbPlantilla) {
		XSSFRow row = sheet.getRow(numRow);
		Iterator<Cell> cellIterator = row.cellIterator();
		while (cellIterator.hasNext()) {
			XSSFCellStyle estilo = ((XSSFCellStyle) cellIterator.next().getCellStyle());
			XSSFFont fuente = estilo.getFont();
			fuente.setCharSet(FontCharset.ANSI.getValue());
			estilo.setFont(fuente);
			
			estilos.add(estilo);
		}
		XSSFCellStyle style = wbPlantilla.createCellStyle();
		style.setAlignment(XSSFCellStyle.ALIGN_RIGHT);
		estilos.add(style);
	}

}
