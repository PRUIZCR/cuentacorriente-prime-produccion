/***********************************************************************
 * Module:  Dpmn.java
 * Author:  rcontreras
 * Purpose: Defines the Class Dpmn
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.common.Auditoria;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.common.DataCatalogo;


public class Dpmn implements java.io.Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 3100156818232208497L;
	/**
	 * <p>
	 * N&uacute;mero correlativo &uacute;nico
	 * </p>
	 */
	private Long numCorrelativo;
	/**
	 * <p>
	 * Aduana, con el valor de la aduana de descarga
	 * </p>
	 */
	private DataCatalogo aduana;
	/**
	 * <p>
	 * A&ntilde;o, con el valor del a&ntilde;o actual
	 * </p>
	 */
	private Integer annDpmn;
	/**
	 * <p>
	 * N&uacute;mero de DPMN
	 * </p>
	 */
	private Integer numDpmn;
	private Date fecDpmn;
	private DataCatalogo estado;
	private DataCatalogo aduanaDescarga;
	private DataCatalogo puestoControlDescarga;
	private DataCatalogo actorRegistro;
	private String codVariableControl;
	private DataCatalogo tipoAnulacion;
	private Auditoria auditoria;

	private DatoComplementario datoComplementario;
	private EmpresaTransporte empresaTransporte;
	private Conductor conductor;
	private java.util.List<ComprobantePago> comprobantePago;

	/** @pdGenerated default parent getter */
	public DatoComplementario getDatoComplementario() {
		return datoComplementario;
	}

	/**
	 * @pdGenerated default parent setter
	 * @param newDatoComplementario
	 */
	public void setDatoComplementario(DatoComplementario newDatoComplementario) {
		this.datoComplementario = newDatoComplementario;
	}

	/** @pdGenerated default parent getter */
	public EmpresaTransporte getEmpresaTransporte() {
		return empresaTransporte;
	}

	/**
	 * @pdGenerated default parent setter
	 * @param newEmpresaTransporte
	 */
	public void setEmpresaTransporte(EmpresaTransporte newEmpresaTransporte) {
		this.empresaTransporte = newEmpresaTransporte;
	}

	/** @pdGenerated default parent getter */
	public Conductor getConductor() {
		return conductor;
	}

	/**
	 * @pdGenerated default parent setter
	 * @param newConductor
	 */
	public void setConductor(Conductor newConductor) {
		this.conductor = newConductor;
	}

	/** @pdGenerated default getter */
	public java.util.List<ComprobantePago> getComprobantePago() {
		if (comprobantePago == null)
			comprobantePago = new java.util.ArrayList<>();
		return comprobantePago;
	}

	/** @pdGenerated default iterator getter */
	@JsonIgnore
	public java.util.Iterator<ComprobantePago> getIteratorComprobantePago() {
		if (comprobantePago == null)
			comprobantePago = new java.util.ArrayList<>();
		return comprobantePago.iterator();
	}

	/**
	 * @pdGenerated default setter
	 * @param newComprobantePago
	 */
	public void setComprobantePago(java.util.List<ComprobantePago> newComprobantePago) {
		removeAllComprobantePago();
		for (java.util.Iterator<ComprobantePago> iter = newComprobantePago.iterator(); iter.hasNext();)
			addComprobantePago(iter.next());
	}

	/**
	 * @pdGenerated default add
	 * @param newComprobantePago
	 */
	public void addComprobantePago(ComprobantePago newComprobantePago) {
		if (newComprobantePago == null)
			return;
		if (this.comprobantePago == null)
			this.comprobantePago = new java.util.ArrayList<>();
		if (!this.comprobantePago.contains(newComprobantePago))
			this.comprobantePago.add(newComprobantePago);
	}

	/**
	 * @pdGenerated default remove
	 * @param oldComprobantePago
	 */
	public void removeComprobantePago(ComprobantePago oldComprobantePago) {
		if (oldComprobantePago == null)
			return;
		if (this.comprobantePago != null && this.comprobantePago.contains(oldComprobantePago))
			this.comprobantePago.remove(oldComprobantePago);
	}

	/** @pdGenerated default removeAll */
	public void removeAllComprobantePago() {
		if (comprobantePago != null)
			comprobantePago.clear();
	}

	public Long getNumCorrelativo() {
		return numCorrelativo;
	}

	/** @param newNumCorrelativo */
	public void setNumCorrelativo(Long newNumCorrelativo) {
		numCorrelativo = newNumCorrelativo;
	}

	public DataCatalogo getAduana() {
		return aduana;
	}

	/** @param newAduana */
	public void setAduana(DataCatalogo newAduana) {
		aduana = newAduana;
	}

	public Integer getAnnDpmn() {
		return annDpmn;
	}

	/** @param newAnnDpmn */
	public void setAnnDpmn(Integer newAnnDpmn) {
		annDpmn = newAnnDpmn;
	}

	public Integer getNumDpmn() {
		return numDpmn;
	}

	/** @param newNumDpmn */
	public void setNumDpmn(Integer newNumDpmn) {
		numDpmn = newNumDpmn;
	}

	public Date getFecDpmn() {
		return fecDpmn;
	}

	/** @param newFecDpmn */
	public void setFecDpmn(Date newFecDpmn) {
		fecDpmn = newFecDpmn;
	}

	public DataCatalogo getEstado() {
		return estado;
	}

	/** @param newEstado */
	public void setEstado(DataCatalogo newEstado) {
		estado = newEstado;
	}

	public DataCatalogo getAduanaDescarga() {
		return aduanaDescarga;
	}

	/** @param newAduanaDescarga */
	public void setAduanaDescarga(DataCatalogo newAduanaDescarga) {
		aduanaDescarga = newAduanaDescarga;
	}

	public DataCatalogo getPuestoControlDescarga() {
		return puestoControlDescarga;
	}

	/** @param newPuestoControlDescarga */
	public void setPuestoControlDescarga(DataCatalogo newPuestoControlDescarga) {
		puestoControlDescarga = newPuestoControlDescarga;
	}

	public DataCatalogo getActorRegistro() {
		return actorRegistro;
	}

	/** @param newActorRegistro */
	public void setActorRegistro(DataCatalogo newActorRegistro) {
		actorRegistro = newActorRegistro;
	}

	public String getCodVariableControl() {
		return codVariableControl;
	}

	/** @param newCodVariableControl */
	public void setCodVariableControl(String newCodVariableControl) {
		codVariableControl = newCodVariableControl;
	}

	public DataCatalogo getTipoAnulacion() {
		return tipoAnulacion;
	}

	/** @param newTipoAnulacion */
	public void setTipoAnulacion(DataCatalogo newTipoAnulacion) {
		tipoAnulacion = newTipoAnulacion;
	}

	public Auditoria getAuditoria() {
		return auditoria;
	}

	/** @param newAuditoria */
	public void setAuditoria(Auditoria newAuditoria) {
		auditoria = newAuditoria;
	}

}