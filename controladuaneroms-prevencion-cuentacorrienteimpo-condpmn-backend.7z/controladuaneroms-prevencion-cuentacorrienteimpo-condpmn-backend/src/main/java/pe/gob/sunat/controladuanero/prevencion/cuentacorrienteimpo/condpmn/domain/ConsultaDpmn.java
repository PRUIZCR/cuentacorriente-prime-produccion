/***********************************************************************
 * Module:  ConsultaDpmn.java
 * Author:  anoriega
 * Purpose: Defines the Class ConsultaDpmn
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.common.DataCatalogo;

public class ConsultaDpmn implements java.io.Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -8798011405364689713L;
	private java.lang.String codigoTransportista;
	private java.lang.String rucTransportista;
	private java.lang.String razonSocialTransportista;
	private DataCatalogo tipoDocumentoDescarga;
	private DataCatalogo estadoDelDocumentoDeDescarga;
	private DataCatalogo tipoDeControl;
	private DataCatalogo paisPlacaDelVehiculo;
	private String placaDelVehiculo;
	private Boolean indicadorPorDocumento;
	private Long numeroDeDescarga;
	private DataCatalogo aduanaDeDescarga;
	private DataCatalogo puestoDeControlDescarga;
	private Integer anoDeDescarga;
	private java.lang.String rucDelRemitente;
	private java.lang.String razonSocialDelRemitente;
	private Boolean indicadorPorDeclaracion;
	private DataCatalogo aduanaDeDeclaracion;
	private Integer anoDeDeclaracion;
	private DataCatalogo regimenDeDeclaracion;
	private Integer numeroDeDeclaracion;
	private Boolean indicadorPorFecha;
	
	@JsonFormat(locale="es_PE", timezone="GMT-5", shape = JsonFormat.Shape.STRING, pattern="dd/MM/yyyy")
	private Date fechaDeInicioConsulta;
	@JsonFormat(locale="es_PE", timezone="GMT-5", shape = JsonFormat.Shape.STRING, pattern="dd/MM/yyyy")
	private Date fechaFinConsulta;

	public java.lang.String getCodigoTransportista() {
		return codigoTransportista;
	}

	/** @param newCodigoTransportista */
	public void setCodigoTransportista(java.lang.String newCodigoTransportista) {
		codigoTransportista = newCodigoTransportista;
	}

	public java.lang.String getRucTransportista() {
		return rucTransportista;
	}

	/** @param newRucTransportista */
	public void setRucTransportista(java.lang.String newRucTransportista) {
		rucTransportista = newRucTransportista;
	}

	public java.lang.String getRazonSocialTransportista() {
		return razonSocialTransportista;
	}

	/** @param newRazonSocialTransportista */
	public void setRazonSocialTransportista(java.lang.String newRazonSocialTransportista) {
		razonSocialTransportista = newRazonSocialTransportista;
	}

	public DataCatalogo getTipoDocumentoDescarga() {
		return tipoDocumentoDescarga;
	}

	/** @param newTipoDocumentoDescarga */
	public void setTipoDocumentoDescarga(DataCatalogo newTipoDocumentoDescarga) {
		tipoDocumentoDescarga = newTipoDocumentoDescarga;
	}

	public DataCatalogo getEstadoDelDocumentoDeDescarga() {
		return estadoDelDocumentoDeDescarga;
	}

	/** @param newEstadoDelDocumentoDeDescarga */
	public void setEstadoDelDocumentoDeDescarga(DataCatalogo newEstadoDelDocumentoDeDescarga) {
		estadoDelDocumentoDeDescarga = newEstadoDelDocumentoDeDescarga;
	}

	public DataCatalogo getTipoDeControl() {
		return tipoDeControl;
	}

	/** @param newTipoDeControl */
	public void setTipoDeControl(DataCatalogo newTipoDeControl) {
		tipoDeControl = newTipoDeControl;
	}

	public DataCatalogo getPaisPlacaDelVehiculo() {
		return paisPlacaDelVehiculo;
	}

	/** @param newPaisPlacaDelVehiculo */
	public void setPaisPlacaDelVehiculo(DataCatalogo newPaisPlacaDelVehiculo) {
		paisPlacaDelVehiculo = newPaisPlacaDelVehiculo;
	}

	public String getPlacaDelVehiculo() {
		return placaDelVehiculo;
	}

	/** @param newPlacaDelVehiculo */
	public void setPlacaDelVehiculo(String newPlacaDelVehiculo) {
		placaDelVehiculo = newPlacaDelVehiculo;
	}

	public Boolean getIndicadorPorDocumento() {
		return indicadorPorDocumento;
	}

	/** @param newIndicadorPorDocumento */
	public void setIndicadorPorDocumento(Boolean newIndicadorPorDocumento) {
		indicadorPorDocumento = newIndicadorPorDocumento;
	}

	public Long getNumeroDeDescarga() {
		return numeroDeDescarga;
	}

	/** @param newNumeroDeDescarga */
	public void setNumeroDeDescarga(Long newNumeroDeDescarga) {
		numeroDeDescarga = newNumeroDeDescarga;
	}

	public DataCatalogo getAduanaDeDescarga() {
		return aduanaDeDescarga;
	}

	/** @param newAduanaDeDescarga */
	public void setAduanaDeDescarga(DataCatalogo newAduanaDeDescarga) {
		aduanaDeDescarga = newAduanaDeDescarga;
	}

	public DataCatalogo getPuestoDeControlDescarga() {
		return puestoDeControlDescarga;
	}

	/** @param newPuestoDeControlDescarga */
	public void setPuestoDeControlDescarga(DataCatalogo newPuestoDeControlDescarga) {
		puestoDeControlDescarga = newPuestoDeControlDescarga;
	}

	public Integer getAnoDeDescarga() {
		return anoDeDescarga;
	}

	/** @param newAnoDeDescarga */
	public void setAnoDeDescarga(Integer newAnoDeDescarga) {
		anoDeDescarga = newAnoDeDescarga;
	}

	public java.lang.String getRucDelRemitente() {
		return rucDelRemitente;
	}

	/** @param newRucDelRemitente */
	public void setRucDelRemitente(java.lang.String newRucDelRemitente) {
		rucDelRemitente = newRucDelRemitente;
	}

	public java.lang.String getRazonSocialDelRemitente() {
		return razonSocialDelRemitente;
	}

	/** @param newRazonSocialDelRemitente */
	public void setRazonSocialDelRemitente(java.lang.String newRazonSocialDelRemitente) {
		razonSocialDelRemitente = newRazonSocialDelRemitente;
	}

	public Boolean getIndicadorPorDeclaracion() {
		return indicadorPorDeclaracion;
	}

	/** @param newIndicadorPorDeclaracion */
	public void setIndicadorPorDeclaracion(Boolean newIndicadorPorDeclaracion) {
		indicadorPorDeclaracion = newIndicadorPorDeclaracion;
	}

	public DataCatalogo getAduanaDeDeclaracion() {
		return aduanaDeDeclaracion;
	}

	/** @param newAduanaDeDeclaracion */
	public void setAduanaDeDeclaracion(DataCatalogo newAduanaDeDeclaracion) {
		aduanaDeDeclaracion = newAduanaDeDeclaracion;
	}

	public Integer getAnoDeDeclaracion() {
		return anoDeDeclaracion;
	}

	/** @param newAnoDeDeclaracion */
	public void setAnoDeDeclaracion(Integer newAnoDeDeclaracion) {
		anoDeDeclaracion = newAnoDeDeclaracion;
	}

	public DataCatalogo getRegimenDeDeclaracion() {
		return regimenDeDeclaracion;
	}

	/** @param newRegimenDeDeclaracion */
	public void setRegimenDeDeclaracion(DataCatalogo newRegimenDeDeclaracion) {
		regimenDeDeclaracion = newRegimenDeDeclaracion;
	}

	public Integer getNumeroDeDeclaracion() {
		return numeroDeDeclaracion;
	}

	/** @param newNumeroDeDeclaracion */
	public void setNumeroDeDeclaracion(Integer newNumeroDeDeclaracion) {
		numeroDeDeclaracion = newNumeroDeDeclaracion;
	}

	public Boolean getIndicadorPorFecha() {
		return indicadorPorFecha;
	}

	/** @param newIndicadorPorFecha */
	public void setIndicadorPorFecha(Boolean newIndicadorPorFecha) {
		indicadorPorFecha = newIndicadorPorFecha;
	}

	public Date getFechaDeInicioConsulta() {
		return fechaDeInicioConsulta;
	}

	/** @param newFechaDeInicioConsulta */
	public void setFechaDeInicioConsulta(Date newFechaDeInicioConsulta) {
		fechaDeInicioConsulta = newFechaDeInicioConsulta;
	}

	public Date getFechaFinConsulta() {
		return fechaFinConsulta;
	}

	/** @param newFechaFinConsulta */
	public void setFechaFinConsulta(Date newFechaFinConsulta) {
		fechaFinConsulta = newFechaFinConsulta;
	}

}