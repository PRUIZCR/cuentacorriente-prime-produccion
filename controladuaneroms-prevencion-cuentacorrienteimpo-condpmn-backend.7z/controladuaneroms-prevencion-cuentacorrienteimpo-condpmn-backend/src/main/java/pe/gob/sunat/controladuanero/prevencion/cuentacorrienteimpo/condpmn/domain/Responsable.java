/***********************************************************************
 * Module:  Responsable.java
 * Author:  anoriega
 * Purpose: Defines the Class Responsable
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain;

import java.io.Serializable;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.common.DataCatalogo;

public class Responsable implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4582815072878063924L;
	private DataCatalogo tipoDocumentoRes;
	private String numDocumentoRes;
	private String nomResponsable;
	private String apeResponsable;
	private String valEmail;
	private String numTelefono;

	public DataCatalogo getTipoDocumentoRes() {
		return tipoDocumentoRes;
	}

	public void setTipoDocumentoRes(DataCatalogo tipoDocumentoRes) {
		this.tipoDocumentoRes = tipoDocumentoRes;
	}

	public String getNumDocumentoRes() {
		return numDocumentoRes;
	}

	public void setNumDocumentoRes(String numDocumentoRes) {
		this.numDocumentoRes = numDocumentoRes;
	}

	public String getNomResponsable() {
		return nomResponsable;
	}

	public void setNomResponsable(String nomResponsable) {
		this.nomResponsable = nomResponsable;
	}

	public String getApeResponsable() {
		return apeResponsable;
	}

	public void setApeResponsable(String apeResponsable) {
		this.apeResponsable = apeResponsable;
	}

	public String getNumTelefono() {
		return numTelefono;
	}

	public void setNumTelefono(String numTelefono) {
		this.numTelefono = numTelefono;
	}

	public String getValEmail() {
		return valEmail;
	}

	/** @param newValEmail */
	public void setValEmail(String newValEmail) {
		valEmail = newValEmail;
	}

}