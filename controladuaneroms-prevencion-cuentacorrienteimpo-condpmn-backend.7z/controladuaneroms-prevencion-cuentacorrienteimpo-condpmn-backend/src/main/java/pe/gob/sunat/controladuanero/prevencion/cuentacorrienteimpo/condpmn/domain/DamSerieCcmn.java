/***********************************************************************
 * Module:  DamSerieCcmn.java
 * Author:  anoriega
 * Purpose: Defines the Class DamSerieCcmn
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain;

import java.math.BigDecimal;
import java.util.*;

import com.fasterxml.jackson.annotation.JsonFormat;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.common.Auditoria;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.common.DataCatalogo;

public class DamSerieCcmn implements java.io.Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -661168487204758386L;

	private Long numCorreCcmn;
	private Long numCorreCompCcmn;
	private Long numCorrelativo;
	private DataCatalogo aduanaDam;
	private DataCatalogo regimenDam;
	private Integer annDam;
	private Integer numDam;
	private Integer numSerie;
	private String codSubPartida;
	private String desComercial;
	private BigDecimal mtoPesoBruto;
	private BigDecimal mtoPesoNeto;
	private DataCatalogo unidadFisica;
	private BigDecimal cntUnidadFisica;
	private BigDecimal cntRetirada;
	private Integer numSecDescarga;
	private BigDecimal cntSaldo;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy HH:mm:ss", locale="es_PE", timezone="GMT-5")
	private Date fecRegistro;
	private boolean indEliminado;
	private Auditoria auditoria;

	public Long getNumCorreCcmn() {
		return numCorreCcmn;
	}

	/** @param newNumCorreCcmn */
	public void setNumCorreCcmn(Long newNumCorreCcmn) {
		numCorreCcmn = newNumCorreCcmn;
	}

	public Long getNumCorreCompCcmn() {
		return numCorreCompCcmn;
	}

	/** @param newNumCorreCompCcmn */
	public void setNumCorreCompCcmn(Long newNumCorreCompCcmn) {
		numCorreCompCcmn = newNumCorreCompCcmn;
	}

	public Long getNumCorrelativo() {
		return numCorrelativo;
	}

	/** @param newNumCorrelativo */
	public void setNumCorrelativo(Long newNumCorrelativo) {
		numCorrelativo = newNumCorrelativo;
	}

	public DataCatalogo getAduanaDam() {
		return aduanaDam;
	}

	/** @param newAduanaDam */
	public void setAduanaDam(DataCatalogo newAduanaDam) {
		aduanaDam = newAduanaDam;
	}

	public DataCatalogo getRegimenDam() {
		return regimenDam;
	}

	/** @param newRegimenDam */
	public void setRegimenDam(DataCatalogo newRegimenDam) {
		regimenDam = newRegimenDam;
	}

	public Integer getAnnDam() {
		return annDam;
	}

	/** @param newAnnDam */
	public void setAnnDam(Integer newAnnDam) {
		annDam = newAnnDam;
	}

	public Integer getNumDam() {
		return numDam;
	}

	/** @param newNumDam */
	public void setNumDam(Integer newNumDam) {
		numDam = newNumDam;
	}

	public Integer getNumSerie() {
		return numSerie;
	}

	/** @param newNumSerie */
	public void setNumSerie(Integer newNumSerie) {
		numSerie = newNumSerie;
	}

	public String getCodSubPartida() {
		return codSubPartida;
	}

	/** @param newCodSubPartida */
	public void setCodSubPartida(String newCodSubPartida) {
		codSubPartida = newCodSubPartida;
	}

	public String getDesComercial() {
		return desComercial;
	}

	/** @param newDesComercial */
	public void setDesComercial(String newDesComercial) {
		desComercial = newDesComercial;
	}

	public java.math.BigDecimal getMtoPesoBruto() {
		return mtoPesoBruto;
	}

	/** @param newMtoPesoBruto */
	public void setMtoPesoBruto(java.math.BigDecimal newMtoPesoBruto) {
		mtoPesoBruto = newMtoPesoBruto;
	}

	public java.math.BigDecimal getMtoPesoNeto() {
		return mtoPesoNeto;
	}

	/** @param newMtoPesoNeto */
	public void setMtoPesoNeto(java.math.BigDecimal newMtoPesoNeto) {
		mtoPesoNeto = newMtoPesoNeto;
	}

	public DataCatalogo getUnidadFisica() {
		return unidadFisica;
	}

	/** @param newUnidadFisica */
	public void setUnidadFisica(DataCatalogo newUnidadFisica) {
		unidadFisica = newUnidadFisica;
	}

	public java.math.BigDecimal getCntUnidadFisica() {
		return cntUnidadFisica;
	}

	/** @param newCntUnidadFisica */
	public void setCntUnidadFisica(java.math.BigDecimal newCntUnidadFisica) {
		cntUnidadFisica = newCntUnidadFisica;
	}

	public java.math.BigDecimal getCntRetirada() {
		return cntRetirada;
	}

	/** @param newCntRetirada */
	public void setCntRetirada(java.math.BigDecimal newCntRetirada) {
		cntRetirada = newCntRetirada;
	}

	public Date getFecRegistro() {
		return fecRegistro;
	}

	/** @param newFecRegistro */
	public void setFecRegistro(Date newFecRegistro) {
		fecRegistro = newFecRegistro;
	}

	public boolean getIndEliminado() {
		return indEliminado;
	}

	/** @param newIndEliminado */
	public void setIndEliminado(boolean newIndEliminado) {
		indEliminado = newIndEliminado;
	}

	public Auditoria getAuditoria() {
		return auditoria;
	}

	/** @param newAuditoria */
	public void setAuditoria(Auditoria newAuditoria) {
		auditoria = newAuditoria;
	}

	public Integer getNumSecDescarga() {
		return numSecDescarga;
	}

	public void setNumSecDescarga(Integer numSecDescarga) {
		this.numSecDescarga = numSecDescarga;
	}

	public BigDecimal getCntSaldo() {
		return cntSaldo;
	}

	public void setCntSaldo(BigDecimal cntSaldo) {
		this.cntSaldo = cntSaldo;
	}
}