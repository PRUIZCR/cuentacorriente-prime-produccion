/***********************************************************************
 * Module:  CartaPorte.java
 * Author:  rcontreras
 * Purpose: Defines the Class CartaPorte
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain;

public class CartaPorte extends ComprobantePago implements java.io.Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 5929967318506193162L;
	private String numCartaPorte;
	private String nomEmpresa;

	public String getNumCartaPorte() {
		return numCartaPorte;
	}

	/** @param newNumCartaPorte */
	public void setNumCartaPorte(String newNumCartaPorte) {
		numCartaPorte = newNumCartaPorte;
	}

	public String getNomEmpresa() {
		return nomEmpresa;
	}

	/** @param newNomEmpresa */
	public void setNomEmpresa(String newNomEmpresa) {
		nomEmpresa = newNomEmpresa;
	}

}