/***********************************************************************
 * Module:  DpmnRepository.java
 * Author:  anoriega
 * Purpose: Defines the Interface DpmnRepository
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.repository;

import java.util.List;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.ConsultaDpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.Dpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.DpmnResumen;

public interface DpmnRepository {
	/** @param parametros */
	List<DpmnResumen> listarDPMNs(ConsultaDpmn parametros);

	/** @param idDpmn */
	Dpmn consultarDpmn(Long idDpmn);

}