/***********************************************************************
 * Module:  Conductor.java
 * Author:  rcontreras
 * Purpose: Defines the Class Conductor
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.common.DataCatalogo;

public class Conductor implements java.io.Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 5863882389718416922L;
	private DataCatalogo pais;
	private DataCatalogo tipoDocIdentidad;
	private String numDocIdentidad;
	private String nomConductor;
	private String apeConductor;
	private String numLicencia;

	public DataCatalogo getPais() {
		return pais;
	}

	/** @param newPais */
	public void setPais(DataCatalogo newPais) {
		pais = newPais;
	}

	public DataCatalogo getTipoDocIdentidad() {
		return tipoDocIdentidad;
	}

	/** @param newTipoDocIdentidad */
	public void setTipoDocIdentidad(DataCatalogo newTipoDocIdentidad) {
		tipoDocIdentidad = newTipoDocIdentidad;
	}

	public String getNumDocIdentidad() {
		return numDocIdentidad;
	}

	/** @param newNumDocIdentidad */
	public void setNumDocIdentidad(String newNumDocIdentidad) {
		numDocIdentidad = newNumDocIdentidad;
	}

	public String getNomConductor() {
		return nomConductor;
	}

	/** @param newNomConductor */
	public void setNomConductor(String newNomConductor) {
		nomConductor = newNomConductor;
	}

	public String getApeConductor() {
		return apeConductor;
	}

	/** @param newApeConductor */
	public void setApeConductor(String newApeConductor) {
		apeConductor = newApeConductor;
	}

	public String getNumLicencia() {
		return numLicencia;
	}

	/** @param newNumLicencia */
	public void setNumLicencia(String newNumLicencia) {
		numLicencia = newNumLicencia;
	}

}