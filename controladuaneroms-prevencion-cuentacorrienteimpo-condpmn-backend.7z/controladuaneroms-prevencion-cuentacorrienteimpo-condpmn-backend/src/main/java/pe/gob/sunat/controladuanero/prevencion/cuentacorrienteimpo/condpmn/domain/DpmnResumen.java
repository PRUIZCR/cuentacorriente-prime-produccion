/***********************************************************************
 * Module:  DpmnResumen.java
 * Author:  anoriega
 * Purpose: Defines the Class DpmnResumen
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.common.DataCatalogo;

public class DpmnResumen implements java.io.Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1656354836385889153L;
	private Long numCorrelativo;
	private String numeroDeDocumentoDescarga;
	private DataCatalogo estado;
	private DataCatalogo paisPlaca;
	private String placa;
	private DataCatalogo paisPlacaCarreta;
	private String placaCarreta;
	private DataCatalogo flujoVehiculo;

	/** Corresponde a la fecha del documento de descarga */
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy HH:mm", locale="es_PE", timezone="GMT-5")
	private Date fechaDeRegistro;

	/** Corresponde al primer RUC del remitente */
	private String rucDelRemitente;
	private Integer cantidadDeSeries;
	private Integer cantidadDeControles;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy HH:mm", locale="es_PE", timezone = "GMT-5")
	private Date fechaDelUltimoControl;
	private DataCatalogo canalDelUltimoControl;
	private String funcionarioAduanero;

	private List<ComprobanteDpmnResumen> lstComprobante;

	public Long getNumCorrelativo() {
		return numCorrelativo;
	}

	public void setNumCorrelativo(Long numCorrelativo) {
		this.numCorrelativo = numCorrelativo;
	}

	public java.lang.String getNumeroDeDocumentoDescarga() {
		return numeroDeDocumentoDescarga;
	}

	/** @param newNumeroDeDocumentoDescarga */
	public void setNumeroDeDocumentoDescarga(java.lang.String newNumeroDeDocumentoDescarga) {
		numeroDeDocumentoDescarga = newNumeroDeDocumentoDescarga;
	}

	public DataCatalogo getEstado() {
		return estado;
	}

	/** @param newEstado */
	public void setEstado(DataCatalogo newEstado) {
		estado = newEstado;
	}

	public DataCatalogo getPaisPlaca() {
		return paisPlaca;
	}

	/** @param newPaisPlaca */
	public void setPaisPlaca(DataCatalogo newPaisPlaca) {
		paisPlaca = newPaisPlaca;
	}

	public java.lang.String getPlaca() {
		return placa;
	}

	/** @param newPlaca */
	public void setPlaca(java.lang.String newPlaca) {
		placa = newPlaca;
	}

	public DataCatalogo getPaisPlacaCarreta() {
		return paisPlacaCarreta;
	}

	public void setPaisPlacaCarreta(DataCatalogo paisPlacaCarreta) {
		this.paisPlacaCarreta = paisPlacaCarreta;
	}

	public java.lang.String getPlacaCarreta() {
		return placaCarreta;
	}

	/** @param newPlacaCarreta */
	public void setPlacaCarreta(java.lang.String newPlacaCarreta) {
		placaCarreta = newPlacaCarreta;
	}

	public DataCatalogo getFlujoVehiculo() {
		return flujoVehiculo;
	}

	/** @param newFlujoVehiculo */
	public void setFlujoVehiculo(DataCatalogo newFlujoVehiculo) {
		flujoVehiculo = newFlujoVehiculo;
	}

	public Date getFechaDeRegistro() {
		return fechaDeRegistro;
	}

	/** @param newFechaDeRegistro */
	public void setFechaDeRegistro(Date newFechaDeRegistro) {
		fechaDeRegistro = newFechaDeRegistro;
	}

	public java.lang.String getRucDelRemitente() {
		return rucDelRemitente;
	}

	/** @param newRucDelRemitente */
	public void setRucDelRemitente(java.lang.String newRucDelRemitente) {
		rucDelRemitente = newRucDelRemitente;
	}

	public Integer getCantidadDeSeries() {
		return cantidadDeSeries;
	}

	/** @param newCantidadDeSeries */
	public void setCantidadDeSeries(Integer newCantidadDeSeries) {
		cantidadDeSeries = newCantidadDeSeries;
	}

	public Integer getCantidadDeControles() {
		return cantidadDeControles;
	}

	/** @param newCantidadDeControles */
	public void setCantidadDeControles(Integer newCantidadDeControles) {
		cantidadDeControles = newCantidadDeControles;
	}

	public Date getFechaDelUltimoControl() {
		return fechaDelUltimoControl;
	}

	/** @param newFechaDelUltimoControl */
	public void setFechaDelUltimoControl(Date newFechaDelUltimoControl) {
		fechaDelUltimoControl = newFechaDelUltimoControl;
	}

	public DataCatalogo getCanalDelUltimoControl() {
		return canalDelUltimoControl;
	}

	/** @param newCanalDelUltimoControl */
	public void setCanalDelUltimoControl(DataCatalogo newCanalDelUltimoControl) {
		canalDelUltimoControl = newCanalDelUltimoControl;
	}

	public String getFuncionarioAduanero() {
		return funcionarioAduanero;
	}

	public void setFuncionarioAduanero(String funcionarioAduanero) {
		this.funcionarioAduanero = funcionarioAduanero;
	}

	public List<ComprobanteDpmnResumen> getLstComprobante() {
		return lstComprobante;
	}

	public void setLstComprobante(List<ComprobanteDpmnResumen> lstComprobante) {
		this.lstComprobante = lstComprobante;
	}

}