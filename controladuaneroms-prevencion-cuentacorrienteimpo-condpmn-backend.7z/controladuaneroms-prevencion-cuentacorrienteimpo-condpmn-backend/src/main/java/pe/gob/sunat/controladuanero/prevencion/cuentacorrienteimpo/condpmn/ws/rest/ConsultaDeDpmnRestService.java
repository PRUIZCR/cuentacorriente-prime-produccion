/***********************************************************************
 * Module:  ConsultaDeDpmnRestService.java
 * Author:  anoriega
 * Purpose: Defines the Class ConsultaDeDpmnRestService
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.ws.rest;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.ConsultaDpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.Dpmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.DpmnResumen;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.services.ConsultaDeDpmnService;
import pe.gob.sunat.tecnologiams.arquitectura.framework.microservices.model.bean.MensajeBean;
import pe.gob.sunat.tecnologiams.arquitectura.framework.microservices.util.ConstantesUtils;

import java.io.ByteArrayInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.lang3.ArrayUtils;

@Path("/v1/controladuanero/prevencion/cuentacorrienteimpo")
public class ConsultaDeDpmnRestService extends DpmnCcmnAbstractRest {

	@POST
	@Path("/t/consultadpmn/generarreporte")
	@Produces({ MediaType.APPLICATION_JSON })
	public Response listarDPMNs(ConsultaDpmn parametros) {

		List<MensajeBean> lstMsjBean = new ArrayList<MensajeBean>();
		MensajeBean error = new MensajeBean();
		try {

			lstMsjBean = this.consultaDeDpmnService.validarParametrosDeConsulta(parametros);

			if (lstMsjBean != null && !lstMsjBean.isEmpty()) {
				return Response.status(COD_ERROR_VALIDACION).entity(lstMsjBean)
						.type(MediaType.APPLICATION_JSON_TYPE.withCharset("utf-8")).build();
			} else {
				List<DpmnResumen> lstDpmn = this.consultaDeDpmnService.listarDPMNs(parametros);

				if (lstDpmn != null && !lstDpmn.isEmpty()) {
					return Response.ok(lstDpmn).build();
				} else {
					error = new MensajeBean();
					error.setCod(1);
					error.setMsg("No existen DPMNs que cumplan la(s) condici\u00f3n(es) de b\u00fasqueda ingresada");
					lstMsjBean.add(error);
					return Response.status(COD_ERROR_VALIDACION).entity(lstMsjBean)
							.type(MediaType.APPLICATION_JSON_TYPE.withCharset("utf-8")).build();
				}
			}
		} catch (java.lang.Exception ex) {
			utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, "Error al consultar listarDPMNs", ex.getStackTrace());
			error = new MensajeBean();
			error.setCod(1);
			error.setMsg("Ha ocurrido un error al buscar los dpmn");
			lstMsjBean.add(error);
			return Response.status(COD_ERROR_VALIDACION).entity(lstMsjBean)
					.type(MediaType.APPLICATION_JSON_TYPE.withCharset("utf-8")).build();
		}
	}

	@POST
	@Path("/t/consultadpmn/exportarexcel")
	@Produces({ MediaType.APPLICATION_OCTET_STREAM })
	public Response exportarListaDPMNsAExcel(ConsultaDpmn parametros) {
		MensajeBean msjBean = new MensajeBean();

		try {
			Byte[] archivoEXcel = this.consultaDeDpmnService.exportarListaDPMNsAExcel(parametros);

			if (archivoEXcel == null) {
				msjBean.setCod(1);
				msjBean.setMsg("No se han encontrado DPMNs con los par\u00E1metros ingresados");
				return Response.status(COD_ERROR_VALIDACION).entity(msjBean)
						.type(MediaType.APPLICATION_JSON_TYPE.withCharset("utf-8")).build();
			} else {
				InputStream inputStream = new ByteArrayInputStream(ArrayUtils.toPrimitive(archivoEXcel));

				
				//  Para pruebas 
				/* try (FileOutputStream fos = new
				  FileOutputStream("D:\\tmp\\ms\\prueba.xlsx")) {
				  
				  fos.write(ArrayUtils.toPrimitive(archivoEXcel)); }
				 */

				return Response.ok(inputStream, MediaType.APPLICATION_OCTET_STREAM)
						.header("Content-Disposition", "attachment; filename=\"" + "reporteDpmns.xlsx" + "\"").build();

			}
		} catch (Exception ex) {
			utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, "Error en exportarListaDPMNsAExcel", ex.getStackTrace());
			msjBean.setCod(1);
			msjBean.setMsg("Ha ocurrido un error al buscar los dpmn");

			return Response.status(COD_ERROR_VALIDACION).entity(msjBean)
					.type(MediaType.APPLICATION_JSON_TYPE.withCharset("utf-8")).build();
		}
	}

	@POST
	@Path("/t/consultadpmn/exportarpdf")
	@Produces({ MediaType.APPLICATION_OCTET_STREAM })
	public Response exportarListaDPMNsAPdf(ConsultaDpmn parametros) {
		MensajeBean msjBean = new MensajeBean();

		try {
			Byte[] archivoPdf = this.consultaDeDpmnService.exportarListaDPMNsAPdf(parametros);

			if (archivoPdf == null) {
				msjBean.setCod(1);
				msjBean.setMsg("No se han encontrado DPMNs con los par\u00E1metros ingresados");
				return Response.status(COD_ERROR_VALIDACION).entity(msjBean)
						.type(MediaType.APPLICATION_JSON_TYPE.withCharset("utf-8")).build();
			} else {
				InputStream inputStream = new ByteArrayInputStream(ArrayUtils.toPrimitive(archivoPdf));

				
				  //Para pruebas 
				  /*try (FileOutputStream fos = new
				  FileOutputStream("D:\\tmp\\ms\\prueba.pdf")) {
				  fos.write(ArrayUtils.toPrimitive(archivoPdf)); }
				  */
				 
				return Response.ok(inputStream, MediaType.APPLICATION_OCTET_STREAM)
						.header("Content-Disposition", "attachment; filename=\"" + "reporteDpmns.pdf" + "\"").build();

			}
		} catch (Exception ex) {
			utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, "Error en exportarListaDPMNsAPdf", ex.getStackTrace());
			msjBean.setCod(1);
			msjBean.setMsg("Ha ocurrido un error al buscar los dpmn");

			return Response.status(COD_ERROR_VALIDACION).entity(msjBean)
					.type(MediaType.APPLICATION_JSON_TYPE.withCharset("utf-8")).build();
		}
	}

	/** @param parametro */
	public Response listarInformacionResumida(ConsultaDpmn parametro) {
		// TODO: implement
		// invoca al metodo ConsultaDeDpmnService.listarInformacionResumida
		return null;
	}

	@GET
	@Path("/e/dpmns/{numCorrelativo}")
	@Produces({ MediaType.APPLICATION_JSON })
	public Response consultarDpmn(@PathParam("numCorrelativo") Long idDpmn) {
		MensajeBean msjBean = new MensajeBean();
		try {

			Dpmn dpmn = this.consultaDeDpmnService.consultarDmpn(idDpmn);

			if (dpmn == null) {
				msjBean = new MensajeBean();
				msjBean.setCod(1);
				msjBean.setMsg("No se ha encontrado DPMN con el correlativo ingresado");
				return Response.status(COD_ERROR_VALIDACION).entity(msjBean)
						.type(MediaType.APPLICATION_JSON_TYPE.withCharset("utf-8")).build();
			} else {
				return Response.ok(dpmn).build();
			}
		} catch (java.lang.Exception ex) {
			utilLog.imprimirLog(ConstantesUtils.LEVEL_ERROR, "Error al consultar consultarDpmn", ex.getStackTrace());
			msjBean = new MensajeBean();
			msjBean.setCod(1);
			msjBean.setMsg("Ha ocurrido un error al buscar la DPMN");
			return Response.status(COD_ERROR_VALIDACION).entity(msjBean)
					.type(MediaType.APPLICATION_JSON_TYPE.withCharset("utf-8")).build();
		}
	}

	/** @pdGenerated default parent getter */
	public ConsultaDeDpmnService getConsultaDeDpmnService() {
		return consultaDeDpmnService;
	}

	/**
	 * @pdGenerated default parent setter
	 * @param newConsultaDeDpmnService
	 */
	public void setConsultaDeDpmnService(ConsultaDeDpmnService newConsultaDeDpmnService) {
		this.consultaDeDpmnService = newConsultaDeDpmnService;
	}

}