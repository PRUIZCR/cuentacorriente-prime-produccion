/***********************************************************************
 * Module:  ConsultaDeCCMNServiceImpl.java
 * Author:  anoriega
 * Purpose: Defines the Class ConsultaDeCCMNServiceImpl
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.services;

import javax.inject.Inject;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.Ccmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.repository.CcmnRepository;

public class ConsultaDeCcmnServiceImpl implements ConsultaDeCcmnService {
	
	@Inject
	public CcmnRepository ccmnRepository;

	/** @param numCorrelativo */
	public Ccmn consultarCcmn(Long numCorrelativo) {
		return ccmnRepository.consultarCcmn(numCorrelativo);
	}

	/** @pdGenerated default parent getter */
	public CcmnRepository getCcmnRepository() {
		return ccmnRepository;
	}

	/**
	 * @pdGenerated default parent setter
	 * @param newCcmnRepository
	 */
	public void setCcmnRepository(CcmnRepository newCcmnRepository) {
		this.ccmnRepository = newCcmnRepository;
	}

}