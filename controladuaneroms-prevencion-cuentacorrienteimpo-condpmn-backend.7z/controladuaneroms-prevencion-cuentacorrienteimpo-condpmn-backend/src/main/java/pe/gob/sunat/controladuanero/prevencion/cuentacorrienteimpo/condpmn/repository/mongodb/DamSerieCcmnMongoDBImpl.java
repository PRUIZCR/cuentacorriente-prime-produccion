/***********************************************************************
 * Module:  DamSerieCcmnMongoDBImpl.java
 * Author:  anoriega
 * Purpose: Defines the Class DamSerieCcmnMongoDBImpl
 ***********************************************************************/

package pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.repository.mongodb;

import java.util.ArrayList;
import java.util.List;

import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Filters;

import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.domain.DamSerieCcmn;
import pe.gob.sunat.controladuanero.prevencion.cuentacorrienteimpo.condpmn.repository.DamSerieCcmnRepository;
import pe.gob.sunat.tecnologia.arquitectura.framework.mongodb.client.MongoDBClient;

public class DamSerieCcmnMongoDBImpl implements DamSerieCcmnRepository{
	
	public static final String DC_CUENTA_CORRIENTE = "dcctecorrienteimpo";

	public List<DamSerieCcmn> buscarPorNumCorreCcmn(Long numCorreCcmn) {
		List<DamSerieCcmn> lstDamSerieCcmn = new ArrayList<DamSerieCcmn>();
		MongoCollection<DamSerieCcmn> collection = MongoDBClient.getCollection(DC_CUENTA_CORRIENTE, "damSeriesCcmn", DamSerieCcmn.class);
		FindIterable<DamSerieCcmn> findIterable = collection.find(Filters.and(Filters.eq("numCorreCcmn", numCorreCcmn), Filters.not(Filters.eq("indEliminado", true))));
		for (DamSerieCcmn damSerieCcmn : findIterable) {
			lstDamSerieCcmn.add(damSerieCcmn);
		}
		
		return lstDamSerieCcmn;
	}

}