import { Component, OnInit, Output, ViewChild } from '@angular/core';

/** Constants used to fill up our data base. */
import { MessageService } from 'primeng/api';
import { Table } from 'primeng/table';

import { HttpClient } from '@angular/common/http';
import { DocumentodescargaService } from 'src/app/services/documentodescarga.service';
import 'rxjs/add/operator/toPromise';
import { DocumentoDescarga } from 'src/app/model/domain/DocumentoDescarga';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { EventEmitter } from '@angular/core';
import { saveAs } from 'file-saver';
import { DocumentoAdjuntoDpmn } from 'src/app/model/domain/adjunto-dpmn.model';
import { jsPDF } from "jspdf";
import { DatePipe } from '@angular/common'
import { ConsultaDpmnService } from 'src/app/services/consulta.dpmn'
import { ConsultaDpmn } from 'src/app/model/bean/param-busqueda'
import { DpmnResumen } from 'src/app/model/domain/dpmn-resumen';

@Component({
  selector: 'app-lista',
  templateUrl: './lista.component.html',
  styleUrls: ['./lista.component.css'],
  providers: [MessageService]
})
export class ListaComponent implements OnInit {

  numCorrelativo: number = 0;

  jsonConsulta: ConsultaDpmn = new ConsultaDpmn;


  @Output() valorsalida: EventEmitter<number> = new EventEmitter();


  respuestaData: any;
  loading = true;
  statuses: any[] = [];
  table!: Table;
  documentos: DocumentoDescarga[] = new Array();
  documentosAdjuntos: DocumentoAdjuntoDpmn[] = new Array();
  date: Date;

  public lstDpmn: any[] = new Array();

  constructor(private router: Router,
    private http: HttpClient, private documentodescargaService: DocumentodescargaService,
    private rutaActiva: ActivatedRoute, public datepipe: DatePipe,
    private myService: ConsultaDpmnService
  ) {
  }
  @ViewChild('dt') dt: Table | undefined;
  filterGlobal($event: any, stringVal: any) {
    this.dt!.filterGlobal(($event.target as HTMLInputElement).value, 'documentos.placaCarreta');
  }


  @ViewChild('dt') tabla: Table;
  ngOnInit(): void {

    this.myService.rptDpmnResumen$.subscribe((data: any) => {
      this.lstDpmn = data;
    });

    this.loading = false;
  }
  get(numCorrelativoOk: string | null) {
    this.http.get<any>('v1/controladuanero/prevencion/cuentacorrienteimpo/e/dpmns/' + 44444 + '/adjuntosdpmn')
      .subscribe(data => {
        this.documentosAdjuntos = data;
      });
  }

  getListadeDocumentos(numCorrelativoOk: string | null) { ///{correlativodpmn}/adjuntosdpmn{correlativodpmn}
    this.http.get<any>('/v1/controladuanero/prevencion/cuentacorrienteimpo/e/dpmns/' + 44444 + '/adjuntosdpmn')
      .subscribe(async data => {
        this.documentosAdjuntos = data; console.log('adjunto :' + JSON.stringify(data));
      });
  }



  onLoadServer(id: number,id2: number) {
    this.numCorrelativo = id;
    sessionStorage.setItem("numCorrelativo", id.toString());
    sessionStorage.setItem("numeroDeDocumentoDescarga", id2.toString());
    this.valorsalida.emit(this.numCorrelativo);
  }

  exportExcel() {
    import("xlsx").then(xlsx => {
      const worksheet = xlsx.utils.json_to_sheet(this.documentos);
      const workbook = { Sheets: { 'data': worksheet }, SheetNames: ['data'] };
      const excelBuffer: any = xlsx.write(workbook, { bookType: 'xlsx', type: 'array' });
      this.saveAsExcelFile(excelBuffer, "documentos");
    });
  }

  saveAsExcelFile(buffer: any, fileName: string): void {
    import("file-saver").then(FileSaver => {
      let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
      let EXCEL_EXTENSION = '.xlsx';
      const data: Blob = new Blob([buffer], {
        type: EXCEL_TYPE
      });
       FileSaver.saveAs(data, fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION);
      //FileSaver.saveAs("https://httpbin.org/image", "image.jpg");
    });
  }

  downloadPDFExcel(idECM: string): void {
    const doc = new jsPDF();

    this.http.get('/v1/controladuanero/prevencion/cuentacorrienteimpo/e/archivosadjuntodpmn/' + idECM, { responseType: 'blob' })
      .subscribe(async data => {
      });
  }
  myFunction() {
    this.date = new Date();
    let latest_date = this.datepipe.transform(this.date, 'yyyy-MM-dd');
  }

  exportarpdf(nomArch: string) {
    this.documentos = new Array();
    this.myService.consultaJsonSession$.subscribe(datos => this.jsonConsulta = datos);
    this.documentodescargaService.getDocumentoDescargaPdf(nomArch, this.jsonConsulta);
  }

  exportarexcel(nomArch: string) {
    this.documentos = new Array();
    this.myService.consultaJsonSession$.subscribe(datos => this.jsonConsulta = datos);
    this.documentodescargaService.getDocumentoDescargaEXcel(nomArch, this.jsonConsulta);
  }

  valPlacaCarreta(data: DpmnResumen): string {
    let error = ' ';
    const control = data.paisPlacaCarreta;
    if (control != null) {
      error =control.codDatacat +'-'+data.placaCarreta;
      }
    return error;
 }
}


