export class ConstantesApp {



  static readonly RESOURCE_RUC : string = "/v1/controladuanero/ruc/";
  static readonly RESOURCE_PUESTO_CONTROL: string = "/v1/controladuanero/puestoscontrol/";
  static readonly RESOURCE_EMPRESA_TRANS: string = "/v1/controladuanero/empresasdetranspinter/";
  static readonly RESOURCE_CONSULTA_DPMN: string = "/v1/controladuanero/consultadpmn/generarreporte";

  static readonly RESOURCE_ARCHIVOS_ADJUNTOS : string = "/v1/controladuanero/archivosadjuntodpmn/";
  static readonly RESOURCE_DATOS_DECLARACION : string = "/v1/controladuanero/dpmns/";
  static readonly RESOURCE_DATOS_DECLARACION_EXPORT_PDF : string = "/v1/controladuanero/consultadpmn/exportarpdf";
  static readonly RESOURCE_DATOS_DECLARACION_EXPORT_EXCEL : string = "/v1/controladuanero/consultadpmn/exportarexcel";

  

  /**
   * Nombre del key, almacenado en sessionstorage,
   * donde se guarda el Token de session
   */
  static readonly KEY_SESSION_TOKEN : string = "token-app-ctacorriente-impo-condpmn";

  /**
   * Nombre del key, almacenado en sessionstorage,
   * donde se guarda el valor userdata del token de session
   */
  static readonly KEY_SESSION_USER_DATA : string = "user-data-ctacorriente-impo-condpmn";

  /**
   * Nombre del key, almacenado en sessionstorage,
   * donde se guarda el RUC vinculado al token de session
   */
  static readonly KEY_SESSION_USER_RUC : string = "ruc-ctacorriente-impo-condpmn";

  static readonly KEY_SESSION_LOGIN : string = "login-ctacorriente-impo-condpmn";

  static readonly KEY_SESSION_ORIGEN : string = "origen-ctacorriente-impo-condpmn";



}
