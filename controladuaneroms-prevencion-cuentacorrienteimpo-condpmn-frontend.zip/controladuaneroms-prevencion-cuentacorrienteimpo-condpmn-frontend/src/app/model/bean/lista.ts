export class ListaCombo {
  codigo: string;
  descripcion: string;
}