export class Ubigeo {
  codUbigeo!: string;
  nomDepartamento!: string;
  nomProvincia!: string;
  nomDistrito!: string;
}
